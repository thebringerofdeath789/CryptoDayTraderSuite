namespace CryptoDayTraderSuite.UI
{
    partial class KeysForm
    {
        private void InitializeComponent() { }
    }
}