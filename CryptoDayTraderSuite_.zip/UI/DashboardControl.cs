using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Services;

namespace CryptoDayTraderSuite.UI
{
    public class DashboardControl : UserControl
    {
        private Label lblAccounts, lblAutoMode, lblPnL, lblWinRate, lblDrawdown, lblSharpe, lblTradeCount, lblBest, lblWorst;
        private DataGridView gridRecentTrades;
        private Button btnAccounts, btnKeys, btnPlanner, btnAutoMode, btnStatus, btnRefresh;
        private TableLayoutPanel main;
        private Control chartEquity;
        private List<TradeRecord> _recentTrades;
        private List<string> _notifications;
        private ListBox lstNotifications;

        public DashboardControl()
        {
            this.Dock = DockStyle.Fill;
            BuildUi();
            LoadData();
        }

        private void BuildUi()
        {
            main = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 4, Padding = new Padding(24) };
            main.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55f));
            main.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45f));
            main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            main.RowStyles.Add(new RowStyle(SizeType.Percent, 60f));
            main.RowStyles.Add(new RowStyle(SizeType.Percent, 40f));
            this.Controls.Add(main);

            // Top: Welcome and quick actions
            var welcome = new Label
            {
                Text = "Welcome to Crypto Day-Trader Suite",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(0, 0, 0, 8)
            };
            main.Controls.Add(welcome, 0, 0);

            var quick = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(0, 0, 0, 8) };
            btnAccounts = new Button { Text = "Accounts", Width = 100 };
            btnKeys = new Button { Text = "API Keys", Width = 100 };
            btnPlanner = new Button { Text = "Planner", Width = 100 };
            btnAutoMode = new Button { Text = "Auto Mode", Width = 100 };
            btnStatus = new Button { Text = "Status", Width = 100 };
            btnRefresh = new Button { Text = "Refresh", Width = 100 };
            quick.Controls.AddRange(new Control[] { btnAccounts, btnKeys, btnPlanner, btnAutoMode, btnStatus, btnRefresh });
            main.Controls.Add(quick, 1, 0);

            // Middle: Account/AutoMode/Performance summary + analytics
            var summary = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 8, Padding = new Padding(0, 12, 0, 12) };
            summary.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            summary.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            summary.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            summary.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            summary.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            summary.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            summary.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            summary.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            lblAccounts = new Label { Text = "Accounts: --", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Regular) };
            lblAutoMode = new Label { Text = "Auto Mode: --", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Regular) };
            lblPnL = new Label { Text = "PnL: --", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Regular) };
            lblWinRate = new Label { Text = "Win Rate: --", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Regular) };
            lblDrawdown = new Label { Text = "Max Drawdown: --", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Regular) };
            lblSharpe = new Label { Text = "Sharpe Ratio: --", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Regular) };
            lblTradeCount = new Label { Text = "Trades: --", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Regular) };
            lblBest = new Label { Text = "Best/Worst: --", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Regular) };
            summary.Controls.Add(lblAccounts);
            summary.Controls.Add(lblAutoMode);
            summary.Controls.Add(lblPnL);
            summary.Controls.Add(lblWinRate);
            summary.Controls.Add(lblDrawdown);
            summary.Controls.Add(lblSharpe);
            summary.Controls.Add(lblTradeCount);
            summary.Controls.Add(lblBest);
            main.Controls.Add(summary, 0, 1);

            // Middle right: Recent trades
            var tradesLabel = new Label
            {
                Text = "Recent Trades",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(0, 0, 0, 8)
            };
            main.Controls.Add(tradesLabel, 1, 1);

            gridRecentTrades = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AutoGenerateColumns = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                Height = 220
            };
            gridRecentTrades.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "AtUtc", HeaderText = "Time", Width = 120 });
            gridRecentTrades.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "ProductId", HeaderText = "Product", Width = 80 });
            gridRecentTrades.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Strategy", HeaderText = "Strategy", Width = 80 });
            gridRecentTrades.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Side", HeaderText = "Side", Width = 60 });
            gridRecentTrades.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Quantity", HeaderText = "Qty", Width = 60 });
            gridRecentTrades.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Price", HeaderText = "Price", Width = 80 });
            gridRecentTrades.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "PnL", HeaderText = "PnL", Width = 80 });
            main.SetRowSpan(gridRecentTrades, 2);
            main.Controls.Add(gridRecentTrades, 1, 2);

            // Equity curve chart (bottom left)
#if NETFRAMEWORK
            var chart = new Chart { Dock = DockStyle.Fill, Height = 180 };
            var area = new ChartArea("Equity");
            chart.ChartAreas.Add(area);
            var series = new Series("Equity") { ChartType = SeriesChartType.Line, Color = Color.DodgerBlue, BorderWidth = 2 };
            chart.Series.Add(series);
            chartEquity = chart;
#else
			chartEquity = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(32, 34, 40), Height = 180 };
#endif
            main.Controls.Add(chartEquity, 0, 2);

            // Notifications area (bottom right)
            var notifLabel = new Label
            {
                Text = "Notifications",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(0, 0, 0, 4)
            };
            lstNotifications = new ListBox { Dock = DockStyle.Fill, Height = 120, Font = new Font("Segoe UI", 10, FontStyle.Regular) };
            var notifPanel = new Panel { Dock = DockStyle.Fill };
            notifPanel.Controls.Add(lstNotifications);
            notifPanel.Controls.Add(notifLabel);
            notifLabel.BringToFront();
            main.Controls.Add(notifPanel, 1, 3);

            // Filler for bottom left
            var filler = new Panel { Dock = DockStyle.Fill };
            main.Controls.Add(filler, 0, 3);

            // Wire up quick links (assumes MainForm tab control)
            btnAccounts.Click += (s, e) => OpenTab("Accounts");
            btnKeys.Click += (s, e) => OpenTab("API Keys");
            btnPlanner.Click += (s, e) => OpenTab("Planner");
            btnAutoMode.Click += (s, e) => OpenTab("Auto Mode");
            btnStatus.Click += (s, e) => OpenTab("Status");
            btnRefresh.Click += (s, e) => LoadData();
        }

        private void LoadData()
        {
            // Accounts summary
            var accounts = AccountRegistry.List();
            var enabled = accounts.Count(a => a.Enabled);
            var total = accounts.Count;
            lblAccounts.Text = $"Accounts: {enabled} enabled / {total} total";

            // Auto mode status (simple: show if any enabled account)
            lblAutoMode.Text = enabled > 0 ? "Auto Mode: Ready" : "Auto Mode: No enabled accounts";

            // Performance summary (last 30 days)
            var trades = HistoryStore.LoadTradeHistory() ?? new List<TradeRecord>();
            _recentTrades = trades.Where(t => t.AtUtc > DateTime.UtcNow.AddDays(-30)).OrderByDescending(t => t.AtUtc).ToList();
            decimal pnl = 0m, wins = 0, losses = 0, maxDrawdown = 0m, equity = 0m, peak = 0m, trough = 0m;
            var eqCurve = new List<decimal>();
            var returns = new List<decimal>();
            decimal? best = null, worst = null;
            foreach (var t in _recentTrades.OrderBy(x => x.AtUtc))
            {
                if (t.PnL.HasValue)
                {
                    pnl += t.PnL.Value;
                    returns.Add(t.PnL.Value);
                    if (!best.HasValue || t.PnL.Value > best.Value) best = t.PnL.Value;
                    if (!worst.HasValue || t.PnL.Value < worst.Value) worst = t.PnL.Value;
                }
                equity += t.PnL ?? 0m;
                eqCurve.Add(equity);
                if (t.PnL.HasValue)
                {
                    if (t.PnL.Value > 0) wins++;
                    else if (t.PnL.Value < 0) losses++;
                }
            }
            // Compute max drawdown
            peak = 0m; trough = 0m; maxDrawdown = 0m;
            foreach (var eq in eqCurve)
            {
                if (eq > peak) { peak = eq; trough = eq; }
                if (eq < trough) trough = eq;
                var dd = peak - trough;
                if (dd > maxDrawdown) maxDrawdown = dd;
            }
            var totalTrades = wins + losses;
            var winRate = totalTrades > 0 ? (wins / totalTrades) * 100m : 0m;

            // Sharpe ratio (simple, using mean/stddev of returns, risk-free = 0)
            double sharpe = 0;
            if (returns.Count > 1)
            {
                var mean = (double)returns.Average();
                var std = Math.Sqrt(returns.Select(x => Math.Pow((double)x - mean, 2)).Sum() / (returns.Count - 1));
                if (std > 0) sharpe = mean / std * Math.Sqrt(252); // annualized
            }

            lblPnL.Text = $"PnL (30d): {pnl:C2}";
            lblWinRate.Text = $"Win Rate: {winRate:0.0}%";
            lblDrawdown.Text = $"Max Drawdown: {maxDrawdown:C2}";
            lblSharpe.Text = $"Sharpe Ratio: {(sharpe == 0 ? "--" : sharpe.ToString("0.00"))}";
            lblTradeCount.Text = $"Trades: {totalTrades}";
            lblBest.Text = $"Best: {(best.HasValue ? best.Value.ToString("0.00") : "--")} / Worst: {(worst.HasValue ? worst.Value.ToString("0.00") : "--")}";

            // Recent trades grid (last 10)
            gridRecentTrades.DataSource = _recentTrades.Take(10).Select(t => new
            {
                AtUtc = t.AtUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm"),
                t.ProductId,
                t.Strategy,
                t.Side,
                t.Quantity,
                t.Price,
                PnL = t.PnL.HasValue ? t.PnL.Value.ToString("0.00") : ""
            }).ToList();

            // Equity curve chart
#if NETFRAMEWORK
            var chart = chartEquity as Chart;
            if (chart != null)
            {
                var series = chart.Series["Equity"];
                series.Points.Clear();
                int i = 0;
                foreach (var eq in eqCurve)
                    series.Points.AddXY(i++, eq);
                chart.ChartAreas[0].RecalculateAxesScale();
            }
#endif

            // Notifications (last 5 system messages, errors, or alerts)
            _notifications = new List<string>();
            if (total == 0)
                _notifications.Add("No accounts configured. Please add an account.");
            if (enabled == 0)
                _notifications.Add("No enabled accounts. Enable at least one account for trading.");
            if (_recentTrades.Count == 0)
                _notifications.Add("No trades in the last 30 days.");
            if (maxDrawdown > 0.2m * (eqCurve.Count > 0 ? eqCurve.Max() : 1m))
                _notifications.Add("Warning: Drawdown exceeds 20% of peak equity.");
            if (sharpe < 0.5 && totalTrades > 5)
                _notifications.Add("Sharpe ratio is low. Review your strategy performance.");
            lstNotifications.DataSource = _notifications;
        }

        private void OpenTab(string tabName)
        {
            // Try to find and select the tab in the parent form's TabControl
            var parent = this.FindForm();
            if (parent == null) return;
            var tabs = parent.Controls.OfType<TabControl>().FirstOrDefault();
            if (tabs == null) return;
            foreach (TabPage tab in tabs.TabPages)
            {
                if (tab.Text.Equals(tabName, StringComparison.OrdinalIgnoreCase))
                {
                    tabs.SelectedTab = tab;
                    break;
                }
            }
        }

        public class AutoModeControl : UserControl
        {
            private ComboBox cmbAccount, cmbProduct, cmbStrategy, cmbGran, cmbExecMode;
            private NumericUpDown numLookback, numEquity, numRisk, numMaxTrades, numEdgeMin, numWinRateMin;
            private Button btnScan, btnPropose, btnExecute, btnClearQueue, btnSchedule;
            private DataGridView gridQueue;
            private TextBox txtLog;
            private Timer autoTimer;
            private CheckBox chkAuto;
            private Panel pnlStrategyParams;
            private List<AccountProfile> _accounts = new List<AccountProfile>();
            private List<ProjectionRow> _lastScan;
            private List<TradePlan> _queue = new List<TradePlan>();

            public AutoModeControl()
            {
                this.Dock = DockStyle.Fill;
                BuildUi();
                LoadAccounts();
                LoadProducts();
            }

            private void BuildUi()
            {
                var main = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Padding = new Padding(8) };
                main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                main.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
                main.RowStyles.Add(new RowStyle(SizeType.Absolute, 120));
                this.Controls.Add(main);

                // Top controls
                var top = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(4) };
                cmbAccount = new ComboBox { Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
                cmbProduct = new ComboBox { Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
                cmbStrategy = new ComboBox { Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
                cmbStrategy.Items.AddRange(new object[] { "ORB", "VWAPTrend" });
                cmbStrategy.SelectedIndex = 0;
                cmbGran = new ComboBox { Width = 80, DropDownStyle = ComboBoxStyle.DropDownList };
                cmbGran.Items.AddRange(new object[] { "1", "5", "15", "30", "60", "240" });
                cmbGran.SelectedIndex = 2;
                numLookback = new NumericUpDown { Minimum = 5, Maximum = 120, Value = 30, Width = 60 };
                numEquity = new NumericUpDown { Minimum = 10, Maximum = 1000000, Value = 1000, Width = 80 };
                numRisk = new NumericUpDown { Minimum = 0.01M, Maximum = 100, DecimalPlaces = 2, Value = 2, Width = 60, Increment = 0.01M };
                numMaxTrades = new NumericUpDown { Minimum = 1, Maximum = 50, Value = 3, Width = 60 };
                cmbExecMode = new ComboBox { Width = 80, DropDownStyle = ComboBoxStyle.DropDownList };
                cmbExecMode.Items.AddRange(new object[] { "Paper", "Live" });
                cmbExecMode.SelectedIndex = 0;
                numEdgeMin = new NumericUpDown { Minimum = 0, Maximum = 100, DecimalPlaces = 2, Value = 0, Width = 60, Increment = 0.01M };
                numWinRateMin = new NumericUpDown { Minimum = 0, Maximum = 100, DecimalPlaces = 2, Value = 0, Width = 60, Increment = 0.01M };

                top.Controls.AddRange(new Control[] {
				new Label { Text = "Account", AutoSize = true, Padding = new Padding(0,6,8,0) }, cmbAccount,
				new Label { Text = "Product", AutoSize = true, Padding = new Padding(12,6,8,0) }, cmbProduct,
				new Label { Text = "Strategy", AutoSize = true, Padding = new Padding(12,6,8,0) }, cmbStrategy,
				new Label { Text = "Gran (min)", AutoSize = true, Padding = new Padding(12,6,8,0) }, cmbGran,
				new Label { Text = "Lookback", AutoSize = true, Padding = new Padding(12,6,8,0) }, numLookback,
				new Label { Text = "Equity $", AutoSize = true, Padding = new Padding(12,6,8,0) }, numEquity,
				new Label { Text = "Risk %", AutoSize = true, Padding = new Padding(12,6,8,0) }, numRisk,
				new Label { Text = "Max Trades", AutoSize = true, Padding = new Padding(12,6,8,0) }, numMaxTrades,
				new Label { Text = "Mode", AutoSize = true, Padding = new Padding(12,6,8,0) }, cmbExecMode,
				new Label { Text = "Min Edge", AutoSize = true, Padding = new Padding(12,6,8,0) }, numEdgeMin,
				new Label { Text = "Min Win%", AutoSize = true, Padding = new Padding(12,6,8,0) }, numWinRateMin
			});
                main.Controls.Add(top, 0, 0);

                // Strategy parameter panel (expandable)
                pnlStrategyParams = new Panel { Dock = DockStyle.Top, Height = 0, Visible = false };
                main.Controls.Add(pnlStrategyParams, 0, 1);

                // Action buttons
                var actions = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(4) };
                btnScan = new Button { Text = "Scan", Width = 80 };
                btnPropose = new Button { Text = "Propose", Width = 80 };
                btnExecute = new Button { Text = "Execute", Width = 80 };
                btnClearQueue = new Button { Text = "Clear Queue", Width = 100 };
                chkAuto = new CheckBox { Text = "Auto Mode", AutoSize = true, Padding = new Padding(12, 6, 0, 0) };
                btnSchedule = new Button { Text = "Schedule", Width = 90 };
                actions.Controls.AddRange(new Control[] { btnScan, btnPropose, btnExecute, btnClearQueue, chkAuto, btnSchedule });
                main.Controls.Add(actions, 0, 2);

                // Trade queue grid
                gridQueue = new DataGridView
                {
                    Dock = DockStyle.Fill,
                    ReadOnly = true,
                    AutoGenerateColumns = false,
                    AllowUserToAddRows = false,
                    AllowUserToDeleteRows = false,
                    SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                    MultiSelect = false
                };
                gridQueue.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Strategy", HeaderText = "Strategy", Width = 100 });
                gridQueue.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Symbol", HeaderText = "Product", Width = 80 });
                gridQueue.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Direction", HeaderText = "Dir", Width = 50 });
                gridQueue.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Entry", HeaderText = "Entry", Width = 80 });
                gridQueue.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Stop", HeaderText = "Stop", Width = 80 });
                gridQueue.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Target", HeaderText = "Target", Width = 80 });
                gridQueue.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Qty", HeaderText = "Qty", Width = 80 });
                gridQueue.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Note", HeaderText = "Note", Width = 120 });
                main.Controls.Add(gridQueue, 0, 3);

                // Log area
                txtLog = new TextBox { Multiline = true, Dock = DockStyle.Bottom, Height = 100, ScrollBars = ScrollBars.Vertical, Font = new Font("Consolas", 9f) };
                main.Controls.Add(txtLog, 0, 4);

                // Timer for auto mode
                autoTimer = new Timer { Interval = 60000 }; // 1 min default
                autoTimer.Tick += (s, e) => { if (chkAuto.Checked) RunAutoCycle(); };

                // Event handlers
                btnScan.Click += (s, e) => DoScan();
                btnPropose.Click += (s, e) => DoPropose();
                btnExecute.Click += (s, e) => DoExecute();
                btnClearQueue.Click += (s, e) => { _queue.Clear(); UpdateQueueGrid(); };
                chkAuto.CheckedChanged += (s, e) => { autoTimer.Enabled = chkAuto.Checked; Log("Auto mode " + (chkAuto.Checked ? "enabled" : "disabled")); };
                btnSchedule.Click += (s, e) => { /* show schedule dialog or config */ MessageBox.Show("Scheduling not implemented in this sample."); };
                cmbStrategy.SelectedIndexChanged += (s, e) => ShowStrategyParams();
            }

            private void LoadAccounts()
            {
                _accounts = AccountRegistry.List().Where(a => a.Enabled).ToList();
                cmbAccount.Items.Clear();
                foreach (var a in _accounts) cmbAccount.Items.Add(a.Label + " [" + a.Service + "]");
                if (cmbAccount.Items.Count > 0) cmbAccount.SelectedIndex = 0;
            }

            private void LoadProducts()
            {
                try
                {
                    var pub = new CryptoDayTraderSuite.Exchanges.CoinbasePublicClient();
                    var prods = pub.GetProducts();
                    cmbProduct.Items.Clear();
                    foreach (var p in prods) cmbProduct.Items.Add(p);
                    if (cmbProduct.Items.Count > 0) cmbProduct.SelectedIndex = 0;
                }
                catch (Exception ex)
                {
                    Log("Failed to load products: " + ex.Message);
                }
            }

            private void ShowStrategyParams()
            {
                // Example: show/hide parameter controls for each strategy
                pnlStrategyParams.Controls.Clear();
                pnlStrategyParams.Visible = false;
                if (cmbStrategy.SelectedItem?.ToString() == "ORB")
                {
                    var lbl = new Label { Text = "ORB Params: OpeningRange (min), BufferATR, StopATR, TakeProfitATR, ATR Period", AutoSize = true };
                    pnlStrategyParams.Controls.Add(lbl);
                    pnlStrategyParams.Visible = true;
                }
                else if (cmbStrategy.SelectedItem?.ToString() == "VWAPTrend")
                {
                    var lbl = new Label { Text = "VWAPTrend Params: Lookback (min), PullbackATR, ATR Period", AutoSize = true };
                    pnlStrategyParams.Controls.Add(lbl);
                    pnlStrategyParams.Visible = true;
                }
            }

            private void DoScan()
            {
                if (cmbProduct.SelectedItem == null) { Log("Select product."); return; }
                var symbol = cmbProduct.SelectedItem.ToString();
                var gran = int.Parse(cmbGran.SelectedItem.ToString());
                var lookback = (int)numLookback.Value;
                // Use edge/winrate filters
                var edgeMin = (double)numEdgeMin.Value;
                var winMin = (double)numWinRateMin.Value;
                var rows = AutoPlanner.Project(symbol, gran, lookback, 0.006m, 0.004m);
                if (rows == null) { Log("Scan failed."); return; }
                _lastScan = rows.Where(r => r.Expectancy >= edgeMin && r.WinRate >= winMin).ToList();
                Log($"Scan complete: {(_lastScan?.Count ?? 0)} strategies found.");
                // Optionally show in a grid or summary
            }

            private void DoPropose()
            {
                if (_lastScan == null || _lastScan.Count == 0) { Log("Scan first."); return; }
                if (cmbAccount.SelectedIndex < 0) { Log("Select account."); return; }
                var acc = _accounts[cmbAccount.SelectedIndex];
                var symbol = cmbProduct.SelectedItem.ToString();
                var gran = int.Parse(cmbGran.SelectedItem.ToString());
                var equity = numEquity.Value;
                var risk = numRisk.Value;
                var maxTrades = (int)numMaxTrades.Value;
                var plans = AutoPlanner.Propose(acc.Id, symbol, gran, equity, risk, _lastScan);
                if (plans.Count == 0) { Log("No trades proposed."); return; }
                _queue = plans.Take(maxTrades).ToList();
                UpdateQueueGrid();
                Log($"{_queue.Count} trades proposed.");
            }

            private async void DoExecute()
            {
                if (_queue == null || _queue.Count == 0) { Log("Nothing to execute."); return; }
                if (cmbAccount.SelectedIndex < 0) { Log("Select account."); return; }
                var acc = _accounts[cmbAccount.SelectedIndex];
                var mode = cmbExecMode.SelectedItem?.ToString() ?? "Paper";
                CryptoDayTraderSuite.Brokers.IBroker broker;
                if (mode == "Paper" || acc.Service == "paper")
                    broker = new CryptoDayTraderSuite.Brokers.PaperBroker();
                else
                    broker = new CryptoDayTraderSuite.Brokers.CoinbaseExchangeBroker();

                foreach (var p in _queue)
                {
                    if (p.AccountId != acc.Id) continue;
                    var r = await broker.PlaceOrderAsync(p);
                    Log((r.ok ? "ok: " : "err: ") + r.message);
                }
                Log("Execution complete.");
            }

            private void UpdateQueueGrid()
            {
                gridQueue.DataSource = null;
                gridQueue.DataSource = _queue;
            }

            private void RunAutoCycle()
            {
                DoScan();
                DoPropose();
                DoExecute();
                Log("Auto cycle complete.");
            }

            private void Log(string msg)
            {
                txtLog.AppendText(DateTime.Now.ToString("HH:mm:ss") + " " + msg + Environment.NewLine);
            }
        }
        public class TradingControl : UserControl
        {
            private ComboBox cmbExchange, cmbProduct, cmbStrategy;
            private NumericUpDown numRisk, numEquity;
            private Button btnLoadProducts, btnFees, btnBacktest, btnPaper, btnLive;
            private Label lblProj100, lblProj1000;
            private TextBox txtLog;

            public TradingControl()
            {
                this.Dock = DockStyle.Fill;
                BuildUi();
            }

            private void BuildUi()
            {
                var tl = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3 };
                tl.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                tl.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
                tl.RowStyles.Add(new RowStyle(SizeType.Absolute, 120));
                this.Controls.Add(tl);

                // Top controls
                var top = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(8) };
                cmbExchange = new ComboBox { Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
                cmbExchange.Items.AddRange(new object[] { "Coinbase", "Kraken", "Bitstamp" });
                cmbExchange.SelectedIndex = 0;
                cmbProduct = new ComboBox { Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
                cmbStrategy = new ComboBox { Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
                cmbStrategy.Items.AddRange(new object[] { "ORB", "VWAPTrend" });
                cmbStrategy.SelectedIndex = 0;
                numRisk = new NumericUpDown { Minimum = 1, Maximum = 100, Value = 2, Width = 60 };
                numEquity = new NumericUpDown { Minimum = 10, Maximum = 1000000, Value = 1000, Width = 80 };
                btnLoadProducts = new Button { Text = "Load Products" };
                btnFees = new Button { Text = "Get Fees" };
                btnBacktest = new Button { Text = "Backtest" };
                btnPaper = new Button { Text = "Paper Trade" };
                btnLive = new Button { Text = "Live Trade" };
                lblProj100 = new Label { Text = "$100 projection: ", AutoSize = true, Padding = new Padding(8, 6, 0, 0) };
                lblProj1000 = new Label { Text = "$1000 projection: ", AutoSize = true, Padding = new Padding(8, 6, 0, 0) };

                top.Controls.AddRange(new Control[] {
				new Label { Text = "Exchange", AutoSize = true, Padding = new Padding(0,6,8,0) }, cmbExchange,
				new Label { Text = "Product", AutoSize = true, Padding = new Padding(12,6,8,0) }, cmbProduct,
				btnLoadProducts, btnFees,
				new Label { Text = "Strategy", AutoSize = true, Padding = new Padding(12,6,8,0) }, cmbStrategy,
				new Label { Text = "Risk %", AutoSize = true, Padding = new Padding(12,6,8,0) }, numRisk,
				new Label { Text = "Equity $", AutoSize = true, Padding = new Padding(12,6,8,0) }, numEquity,
				btnBacktest, btnPaper, btnLive, lblProj100, lblProj1000
			});
                tl.Controls.Add(top, 0, 0);

                // Chart area (placeholder)
                var chartPanel = new Panel { Dock = DockStyle.Fill, BackColor = System.Drawing.Color.FromArgb(32, 34, 40) };
                tl.Controls.Add(chartPanel, 0, 1);

                // Log area
                txtLog = new TextBox { Multiline = true, Dock = DockStyle.Fill, ScrollBars = ScrollBars.Vertical, Font = new System.Drawing.Font("Consolas", 9f) };
                tl.Controls.Add(txtLog, 0, 2);

                // Wire up events (you can connect these to your MainForm logic or refactor as needed)
                // Example: btnLoadProducts.Click += ...;
            }
        }
        public class StatusControl : UserControl
        {
            private Label lblPnL, lblWinRate, lblDrawdown, lblProj100, lblProj1000;
            private Button btnRefresh;
            private TableLayoutPanel main;

            public StatusControl()
            {
                this.Dock = DockStyle.Fill;
                BuildUi();
                LoadData();
            }

            private void BuildUi()
            {
                main = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 7, Padding = new Padding(24) };
                main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                main.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
                this.Controls.Add(main);

                var title = new Label
                {
                    Text = "Status / Performance",
                    Dock = DockStyle.Top,
                    Font = new Font("Segoe UI", 16, FontStyle.Bold),
                    TextAlign = ContentAlignment.MiddleLeft,
                    Padding = new Padding(0, 0, 0, 12)
                };
                main.Controls.Add(title);

                lblPnL = new Label { Text = "PnL: --", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Regular) };
                main.Controls.Add(lblPnL);

                lblWinRate = new Label { Text = "Win Rate: --", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Regular) };
                main.Controls.Add(lblWinRate);

                lblDrawdown = new Label { Text = "Max Drawdown: --", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Regular) };
                main.Controls.Add(lblDrawdown);

                lblProj100 = new Label { Text = "$100 projection: --", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Regular) };
                main.Controls.Add(lblProj100);

                lblProj1000 = new Label { Text = "$1000 projection: --", AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Regular) };
                main.Controls.Add(lblProj1000);

                btnRefresh = new Button { Text = "Refresh", Width = 120, Height = 36, Dock = DockStyle.Top };
                btnRefresh.Click += (s, e) => LoadData();
                main.Controls.Add(btnRefresh);
            }

            private void LoadData()
            {
                // Load trade history and compute stats
                var trades = HistoryStore.LoadTradeHistory() ?? new List<TradeRecord>();
                decimal pnl = 0m, wins = 0, losses = 0, maxDrawdown = 0m, equity = 0m, peak = 0m, trough = 0m;
                var eqCurve = new List<decimal>();
                foreach (var t in trades.OrderBy(x => x.AtUtc))
                {
                    if (t.PnL.HasValue)
                        pnl += t.PnL.Value;
                    equity += t.PnL ?? 0m;
                    eqCurve.Add(equity);
                    if (t.PnL.HasValue)
                    {
                        if (t.PnL.Value > 0) wins++;
                        else if (t.PnL.Value < 0) losses++;
                    }
                }
                // Compute max drawdown
                peak = 0m; trough = 0m; maxDrawdown = 0m;
                foreach (var eq in eqCurve)
                {
                    if (eq > peak) { peak = eq; trough = eq; }
                    if (eq < trough) trough = eq;
                    var dd = peak - trough;
                    if (dd > maxDrawdown) maxDrawdown = dd;
                }
                var total = wins + losses;
                var winRate = total > 0 ? (wins / total) * 100m : 0m;

                lblPnL.Text = $"PnL: {pnl:C2}";
                lblWinRate.Text = $"Win Rate: {winRate:0.0}%";
                lblDrawdown.Text = $"Max Drawdown: {maxDrawdown:C2}";

                // Projections (using last known win rate and avg PnL)
                decimal avgWinR = 1.1m, avgLossR = 1.0m, riskFrac = 0.02m, tradesPerDay = 10, netFee = 0.001m;
                if (trades.Any())
                {
                    var winPnls = trades.Where(t => t.PnL.HasValue && t.PnL.Value > 0).Select(t => t.PnL.Value).ToList();
                    var lossPnls = trades.Where(t => t.PnL.HasValue && t.PnL.Value < 0).Select(t => Math.Abs(t.PnL.Value)).ToList();
                    avgWinR = winPnls.Any() ? winPnls.Average() : avgWinR;
                    avgLossR = lossPnls.Any() ? lossPnls.Average() : avgLossR;
                }
                var projInput = new ProjectionInput
                {
                    StartingEquity = 100m,
                    TradesPerDay = tradesPerDay,
                    WinRate = total > 0 ? (decimal)winRate / 100m : 0.52m,
                    AvgWinR = avgWinR,
                    AvgLossR = avgLossR,
                    RiskPerTradeFraction = riskFrac,
                    NetFeeAndFrictionRate = netFee,
                    Days = 20
                };
                var proj100 = Projections.Compute(projInput);
                lblProj100.Text = $"$100 projection: {proj100.EndingEquity:0.00} (daily {proj100.DailyExpectedReturnPct:0.00}%)";
                projInput.StartingEquity = 1000m;
                var proj1000 = Projections.Compute(projInput);
                lblProj1000.Text = $"$1000 projection: {proj1000.EndingEquity:0.00}";
            }
        }
        public class KeysControl : UserControl
        {
            private DataGridView gridKeys;
            private Button btnAdd, btnEdit, btnDelete, btnRefresh;
            private BindingSource _bs = new BindingSource();
            private List<KeyEntry> _keys = new List<KeyEntry>();

            public KeysControl()
            {
                this.Dock = DockStyle.Fill;
                BuildUi();
                LoadData();
            }

            private void BuildUi()
            {
                var main = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
                main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                main.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
                this.Controls.Add(main);

                // Top bar
                var topBar = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(4) };
                btnAdd = new Button { Text = "Add" };
                btnEdit = new Button { Text = "Edit" };
                btnDelete = new Button { Text = "Delete" };
                btnRefresh = new Button { Text = "Refresh" };
                topBar.Controls.AddRange(new Control[] { btnAdd, btnEdit, btnDelete, btnRefresh });
                main.Controls.Add(topBar, 0, 0);

                // Keys grid
                gridKeys = new DataGridView
                {
                    Dock = DockStyle.Fill,
                    ReadOnly = true,
                    AutoGenerateColumns = false,
                    AllowUserToAddRows = false,
                    AllowUserToDeleteRows = false,
                    SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                    MultiSelect = false
                };
                gridKeys.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Label", HeaderText = "Label", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, FillWeight = 180 });
                gridKeys.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Service", HeaderText = "Service", Width = 120 });
                gridKeys.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "KeyId", HeaderText = "Key ID", Width = 180 });
                gridKeys.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "ApiKeyName", HeaderText = "API Key Name", Width = 120 });
                gridKeys.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "CreatedUtc", HeaderText = "Created", Width = 120 });
                gridKeys.Columns.Add(new DataGridViewCheckBoxColumn { DataPropertyName = "Enabled", HeaderText = "Enabled", Width = 60 });
                gridKeys.DoubleClick += (s, e) => EditSelected();
                main.Controls.Add(gridKeys, 0, 1);

                // Event handlers
                btnAdd.Click += (s, e) => AddKey();
                btnEdit.Click += (s, e) => EditSelected();
                btnDelete.Click += (s, e) => DeleteSelected();
                btnRefresh.Click += (s, e) => LoadData();
            }

            private void LoadData()
            {
                _keys = KeyRegistry.List();
                _bs.DataSource = _keys;
                gridKeys.DataSource = _bs;
            }

            private KeyEntry Selected()
            {
                return gridKeys.CurrentRow != null ? gridKeys.CurrentRow.DataBoundItem as KeyEntry : null;
            }

            private void AddKey()
            {
                var dlg = new KeyEditDialog(null);
                if (dlg.ShowDialog(this) == DialogResult.OK)
                    LoadData();
            }

            private void EditSelected()
            {
                var cur = Selected();
                if (cur == null) return;
                var dlg = new KeyEditDialog(cur.Id);
                if (dlg.ShowDialog(this) == DialogResult.OK)
                    LoadData();
            }

            private void DeleteSelected()
            {
                var cur = Selected();
                if (cur == null) return;
                if (MessageBox.Show("Delete API key " + cur.Label + "?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    KeyRegistry.Delete(cur.Id);
                    LoadData();
                }
            }
        }
        public class AccountsControl : UserControl
        {
            private DataGridView gridAccounts;
            private Button btnAdd, btnEdit, btnDelete, btnRefresh;
            private BindingSource _bs = new BindingSource();
            private List<AccountProfile> _accounts = new List<AccountProfile>();

            public AccountsControl()
            {
                this.Dock = DockStyle.Fill;
                BuildUi();
                LoadData();
            }

            private void BuildUi()
            {
                var main = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
                main.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                main.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
                this.Controls.Add(main);

                // Top bar
                var topBar = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(4) };
                btnAdd = new Button { Text = "Add" };
                btnEdit = new Button { Text = "Edit" };
                btnDelete = new Button { Text = "Delete" };
                btnRefresh = new Button { Text = "Refresh" };
                topBar.Controls.AddRange(new Control[] { btnAdd, btnEdit, btnDelete, btnRefresh });
                main.Controls.Add(topBar, 0, 0);

                // Accounts grid
                gridAccounts = new DataGridView
                {
                    Dock = DockStyle.Fill,
                    ReadOnly = true,
                    AutoGenerateColumns = false,
                    AllowUserToAddRows = false,
                    AllowUserToDeleteRows = false,
                    SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                    MultiSelect = false
                };
                gridAccounts.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Label", HeaderText = "Label", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, FillWeight = 220 });
                gridAccounts.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Service", HeaderText = "Service", Width = 180 });
                gridAccounts.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Mode", HeaderText = "Mode", Width = 80 });
                gridAccounts.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "RiskPerTradePct", HeaderText = "Risk %", Width = 80 });
                gridAccounts.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "MaxConcurrentTrades", HeaderText = "Max Open", Width = 90 });
                gridAccounts.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "KeyEntryId", HeaderText = "Key Id", Width = 280 });
                gridAccounts.Columns.Add(new DataGridViewCheckBoxColumn { DataPropertyName = "Enabled", HeaderText = "Enabled", Width = 60 });
                gridAccounts.DoubleClick += (s, e) => EditSelected();
                main.Controls.Add(gridAccounts, 0, 1);

                // Event handlers
                btnAdd.Click += (s, e) => AddAccount();
                btnEdit.Click += (s, e) => EditSelected();
                btnDelete.Click += (s, e) => DeleteSelected();
                btnRefresh.Click += (s, e) => LoadData();
            }

            private void LoadData()
            {
                _accounts = AccountRegistry.List();
                _bs.DataSource = _accounts;
                gridAccounts.DataSource = _bs;
            }

            private AccountProfile Selected()
            {
                return gridAccounts.CurrentRow != null ? gridAccounts.CurrentRow.DataBoundItem as AccountProfile : null;
            }

            private void AddAccount()
            {
                var dlg = new AccountEditDialog(null);
                if (dlg.ShowDialog(this) == DialogResult.OK)
                    LoadData();
            }

            private void EditSelected()
            {
                var cur = Selected();
                if (cur == null) return;
                var dlg = new AccountEditDialog(cur.Id);
                if (dlg.ShowDialog(this) == DialogResult.OK)
                    LoadData();
            }

            private void DeleteSelected()
            {
                var cur = Selected();
                if (cur == null) return;
                if (MessageBox.Show("Delete account " + cur.Label + "?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    AccountRegistry.Delete(cur.Id);
                    LoadData();
                }
            }
        }
        public class PlannerControl : UserControl
        {
            private DataGridView gridPlanned, gridPreds;
            private Button btnRefresh, btnSave, btnAdd;
            private ComboBox cmbFilterProduct, cmbFilterStrategy;
            private List<TradeRecord> _planned = new List<TradeRecord>();
            private List<PredictionRecord> _preds = new List<PredictionRecord>();

            public PlannerControl()
            {
                this.Dock = DockStyle.Fill;
                BuildUi();
                LoadData();
            }

            private void BuildUi()
            {
                var main = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
                main.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55f));
                main.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45f));
                this.Controls.Add(main);

                // Left: Planned Trades
                var leftPanel = new Panel { Dock = DockStyle.Fill };
                var topBar = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(4) };
                btnRefresh = new Button { Text = "Refresh" };
                btnSave = new Button { Text = "Save" };
                btnAdd = new Button { Text = "Add Trade" };
                cmbFilterProduct = new ComboBox { Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
                cmbFilterStrategy = new ComboBox { Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
                topBar.Controls.AddRange(new Control[] { btnRefresh, btnSave, btnAdd, new Label { Text = "Product:" }, cmbFilterProduct, new Label { Text = "Strategy:" }, cmbFilterStrategy });
                leftPanel.Controls.Add(topBar);

                gridPlanned = new DataGridView
                {
                    Dock = DockStyle.Fill,
                    AllowUserToAddRows = false,
                    AllowUserToDeleteRows = false,
                    SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                    AutoGenerateColumns = false,
                    ReadOnly = false,
                    MultiSelect = false
                };
                gridPlanned.Columns.Add(new DataGridViewCheckBoxColumn { DataPropertyName = "Enabled", HeaderText = "Enabled", Width = 60 });
                gridPlanned.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Exchange", HeaderText = "Exchange", Width = 80, ReadOnly = true });
                gridPlanned.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "ProductId", HeaderText = "Product", Width = 80, ReadOnly = true });
                gridPlanned.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Strategy", HeaderText = "Strategy", Width = 80, ReadOnly = true });
                gridPlanned.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Side", HeaderText = "Side", Width = 60, ReadOnly = true });
                gridPlanned.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Quantity", HeaderText = "Qty", Width = 60 });
                gridPlanned.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Price", HeaderText = "Price", Width = 80 });
                gridPlanned.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "EstEdge", HeaderText = "Est. Edge", Width = 80, ReadOnly = true });
                gridPlanned.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Notes", HeaderText = "Notes", Width = 120 });
                leftPanel.Controls.Add(gridPlanned);
                gridPlanned.BringToFront();

                // Context menu for planned trades
                var ctxMenu = new ContextMenuStrip();
                var miEdit = new ToolStripMenuItem("Edit", null, (s, e) => EditSelectedTrade());
                var miDelete = new ToolStripMenuItem("Delete", null, (s, e) => DeleteSelectedTrade());
                ctxMenu.Items.AddRange(new ToolStripItem[] { miEdit, miDelete });
                gridPlanned.ContextMenuStrip = ctxMenu;
                gridPlanned.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) EditSelectedTrade(); };

                // Right: Prediction History
                gridPreds = new DataGridView
                {
                    Dock = DockStyle.Fill,
                    AllowUserToAddRows = false,
                    AllowUserToDeleteRows = false,
                    SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                    AutoGenerateColumns = false,
                    ReadOnly = true
                };
                gridPreds.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "ProductId", HeaderText = "Product", Width = 80 });
                gridPreds.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "AtUtc", HeaderText = "Time", Width = 120 });
                gridPreds.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "HorizonMinutes", HeaderText = "Horizon", Width = 60 });
                gridPreds.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Direction", HeaderText = "Dir", Width = 40 });
                gridPreds.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Probability", HeaderText = "Prob", Width = 60 });
                gridPreds.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "ExpectedReturn", HeaderText = "ExpRet", Width = 60 });
                gridPreds.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "ExpectedVol", HeaderText = "ExpVol", Width = 60 });
                gridPreds.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "RealizedKnown", HeaderText = "Known", Width = 50 });
                gridPreds.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "RealizedDirection", HeaderText = "RDir", Width = 40 });
                gridPreds.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "RealizedReturn", HeaderText = "RRet", Width = 60 });

                // Add to main layout
                main.Controls.Add(leftPanel, 0, 0);
                main.Controls.Add(gridPreds, 1, 0);

                // Event handlers
                btnRefresh.Click += (s, e) => LoadData();
                btnSave.Click += (s, e) => SaveData();
                btnAdd.Click += (s, e) => AddTrade();
                cmbFilterProduct.SelectedIndexChanged += (s, e) => ApplyFilters();
                cmbFilterStrategy.SelectedIndexChanged += (s, e) => ApplyFilters();
            }

            private void LoadData()
            {
                _planned = HistoryStore.LoadPlannedTrades() ?? new List<TradeRecord>();
                _preds = HistoryStore.LoadPredictions() ?? new List<PredictionRecord>();

                // Populate filters
                var products = _planned.Select(p => p.ProductId).Distinct().OrderBy(x => x).ToList();
                cmbFilterProduct.Items.Clear();
                cmbFilterProduct.Items.Add("All");
                cmbFilterProduct.Items.AddRange(products.ToArray());
                cmbFilterProduct.SelectedIndex = 0;

                var strategies = _planned.Select(p => p.Strategy).Distinct().OrderBy(x => x).ToList();
                cmbFilterStrategy.Items.Clear();
                cmbFilterStrategy.Items.Add("All");
                cmbFilterStrategy.Items.AddRange(strategies.ToArray());
                cmbFilterStrategy.SelectedIndex = 0;

                ApplyFilters();

                gridPreds.Rows.Clear();
                foreach (var r in _preds.OrderByDescending(x => x.AtUtc).Take(500))
                {
                    gridPreds.Rows.Add(r.ProductId, r.AtUtc.ToLocalTime(), r.HorizonMinutes, r.Direction, r.Probability, r.ExpectedReturn, r.ExpectedVol, r.RealizedKnown, r.RealizedDirection, r.RealizedReturn);
                }
            }

            private void SaveData()
            {
                // Update enabled/notes/quantity/price from grid
                var filtered = GetFilteredPlanned();
                for (int i = 0; i < gridPlanned.Rows.Count; i++)
                {
                    var row = gridPlanned.Rows[i];
                    var p = filtered[i];
                    p.Enabled = Convert.ToBoolean(row.Cells[0].Value ?? false);
                    p.Quantity = Convert.ToDecimal(row.Cells[5].Value ?? 0m);
                    p.Price = Convert.ToDecimal(row.Cells[6].Value ?? 0m);
                    p.Notes = row.Cells[8].Value?.ToString();
                }
                HistoryStore.SavePlannedTrades(_planned);
                MessageBox.Show("Planner updated", "Planner", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            private void AddTrade()
            {
                var dlg = new TradeEditDialog();
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    _planned.Add(dlg.Result);
                    SaveData();
                    LoadData();
                }
            }

            private void EditSelectedTrade()
            {
                if (gridPlanned.SelectedRows.Count == 0) return;
                var idx = gridPlanned.SelectedRows[0].Index;
                var filtered = GetFilteredPlanned();
                if (idx < 0 || idx >= filtered.Count) return;
                var rec = filtered[idx];
                var dlg = new TradeEditDialog(rec);
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    // Update the original record in _planned
                    var orig = _planned.FirstOrDefault(x => x.AtUtc == rec.AtUtc && x.ProductId == rec.ProductId && x.Strategy == rec.Strategy);
                    if (orig != null)
                    {
                        orig.Enabled = dlg.Result.Enabled;
                        orig.Quantity = dlg.Result.Quantity;
                        orig.Price = dlg.Result.Price;
                        orig.Notes = dlg.Result.Notes;
                    }
                    SaveData();
                    LoadData();
                }
            }

            private void DeleteSelectedTrade()
            {
                if (gridPlanned.SelectedRows.Count == 0) return;
                var idx = gridPlanned.SelectedRows[0].Index;
                var filtered = GetFilteredPlanned();
                if (idx < 0 || idx >= filtered.Count) return;
                var rec = filtered[idx];
                if (MessageBox.Show($"Delete planned trade for {rec.ProductId} ({rec.Strategy})?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    _planned.Remove(rec);
                    SaveData();
                    LoadData();
                }
            }

            private void ApplyFilters()
            {
                string prod = cmbFilterProduct.SelectedItem?.ToString();
                string strat = cmbFilterStrategy.SelectedItem?.ToString();
                var filtered = _planned.Where(p =>
                    (prod == "All" || p.ProductId == prod) &&
                    (strat == "All" || p.Strategy == strat)).ToList();

                gridPlanned.Rows.Clear();
                foreach (var p in filtered)
                {
                    gridPlanned.Rows.Add(p.Enabled, p.Exchange, p.ProductId, p.Strategy, p.Side, p.Quantity, p.Price, p.EstEdge, p.Notes);
                }
            }

            private List<TradeRecord> GetFilteredPlanned()
            {
                string prod = cmbFilterProduct.SelectedItem?.ToString();
                string strat = cmbFilterStrategy.SelectedItem?.ToString();
                return _planned.Where(p =>
                    (prod == "All" || p.ProductId == prod) &&
                    (strat == "All" || p.Strategy == strat)).ToList();
            }
        }

        // TradeEditDialog: modal dialog for adding/editing a trade
        public class TradeEditDialog : Form
        {
            public TradeRecord Result { get; private set; }
            private TextBox txtExchange, txtProduct, txtStrategy, txtSide, txtQty, txtPrice, txtEdge, txtNotes;
            private CheckBox chkEnabled, chkExecuted;
            private DateTimePicker dtAtUtc;
            private TextBox txtFillPrice, txtPnL;
            private Button btnOK, btnCancel;

            public TradeEditDialog() : this(null) { }

            public TradeEditDialog(TradeRecord rec)
            {
                this.Text = rec == null ? "Add Planned Trade" : "Edit Planned Trade";
                this.StartPosition = FormStartPosition.CenterParent;
                this.Width = 480; this.Height = 520;
                this.FormBorderStyle = FormBorderStyle.FixedDialog; this.MaximizeBox = false;

                var tl = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 13, Padding = new Padding(12) };
                tl.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
                tl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
                this.Controls.Add(tl);

                int row = 0;

                tl.Controls.Add(new Label { Text = "Enabled", AutoSize = true }, 0, row);
                chkEnabled = new CheckBox(); tl.Controls.Add(chkEnabled, 1, row++);

                tl.Controls.Add(new Label { Text = "Exchange", AutoSize = true }, 0, row);
                txtExchange = new TextBox(); tl.Controls.Add(txtExchange, 1, row++);

                tl.Controls.Add(new Label { Text = "Product", AutoSize = true }, 0, row);
                txtProduct = new TextBox(); tl.Controls.Add(txtProduct, 1, row++);

                tl.Controls.Add(new Label { Text = "Strategy", AutoSize = true }, 0, row);
                txtStrategy = new TextBox(); tl.Controls.Add(txtStrategy, 1, row++);

                tl.Controls.Add(new Label { Text = "Side", AutoSize = true }, 0, row);
                txtSide = new TextBox(); tl.Controls.Add(txtSide, 1, row++);

                tl.Controls.Add(new Label { Text = "Quantity", AutoSize = true }, 0, row);
                txtQty = new TextBox(); tl.Controls.Add(txtQty, 1, row++);

                tl.Controls.Add(new Label { Text = "Price", AutoSize = true }, 0, row);
                txtPrice = new TextBox(); tl.Controls.Add(txtPrice, 1, row++);

                tl.Controls.Add(new Label { Text = "Est. Edge", AutoSize = true }, 0, row);
                txtEdge = new TextBox(); tl.Controls.Add(txtEdge, 1, row++);

                tl.Controls.Add(new Label { Text = "At (UTC)", AutoSize = true }, 0, row);
                dtAtUtc = new DateTimePicker { Format = DateTimePickerFormat.Custom, CustomFormat = "yyyy-MM-dd HH:mm:ss", Width = 160 };
                tl.Controls.Add(dtAtUtc, 1, row++);

                tl.Controls.Add(new Label { Text = "Executed", AutoSize = true }, 0, row);
                chkExecuted = new CheckBox(); tl.Controls.Add(chkExecuted, 1, row++);

                tl.Controls.Add(new Label { Text = "Fill Price", AutoSize = true }, 0, row);
                txtFillPrice = new TextBox(); tl.Controls.Add(txtFillPrice, 1, row++);

                tl.Controls.Add(new Label { Text = "PnL", AutoSize = true }, 0, row);
                txtPnL = new TextBox(); tl.Controls.Add(txtPnL, 1, row++);

                tl.Controls.Add(new Label { Text = "Notes", AutoSize = true }, 0, row);
                txtNotes = new TextBox(); tl.Controls.Add(txtNotes, 1, row++);

                var btnPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
                btnOK = new Button { Text = "OK", DialogResult = DialogResult.OK };
                btnCancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel };
                btnPanel.Controls.Add(btnOK); btnPanel.Controls.Add(btnCancel);
                tl.Controls.Add(btnPanel, 1, row);

                btnOK.Click += (s, e) => { if (ValidateAndSetResult()) this.DialogResult = DialogResult.OK; };
                btnCancel.Click += (s, e) => { this.DialogResult = DialogResult.Cancel; };

                if (rec != null)
                {
                    chkEnabled.Checked = rec.Enabled;
                    txtExchange.Text = rec.Exchange;
                    txtProduct.Text = rec.ProductId;
                    txtStrategy.Text = rec.Strategy;
                    txtSide.Text = rec.Side;
                    txtQty.Text = rec.Quantity.ToString();
                    txtPrice.Text = rec.Price.ToString();
                    txtEdge.Text = rec.EstEdge.ToString();
                    dtAtUtc.Value = rec.AtUtc == default(DateTime) ? DateTime.UtcNow : rec.AtUtc;
                    chkExecuted.Checked = rec.Executed;
                    txtFillPrice.Text = rec.FillPrice?.ToString() ?? "";
                    txtPnL.Text = rec.PnL?.ToString() ?? "";
                    txtNotes.Text = rec.Notes;
                }
                else
                {
                    chkEnabled.Checked = true;
                    txtExchange.Text = "";
                    txtProduct.Text = "";
                    txtStrategy.Text = "";
                    txtSide.Text = "";
                    txtQty.Text = "0";
                    txtPrice.Text = "0";
                    txtEdge.Text = "0";
                    dtAtUtc.Value = DateTime.UtcNow;
                    chkExecuted.Checked = false;
                    txtFillPrice.Text = "";
                    txtPnL.Text = "";
                    txtNotes.Text = "";
                }
            }

            private bool ValidateAndSetResult()
            {
                decimal qty, price, edge;
                decimal? fillPrice = null, pnl = null;
                if (!decimal.TryParse(txtQty.Text, out qty) || !decimal.TryParse(txtPrice.Text, out price) || !decimal.TryParse(txtEdge.Text, out edge))
                {
                    MessageBox.Show("Quantity, Price, and Est. Edge must be valid numbers.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                if (!string.IsNullOrWhiteSpace(txtFillPrice.Text))
                {
                    decimal tmp;
                    if (!decimal.TryParse(txtFillPrice.Text, out tmp))
                    {
                        MessageBox.Show("Fill Price must be a valid number.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                    fillPrice = tmp;
                }
                if (!string.IsNullOrWhiteSpace(txtPnL.Text))
                {
                    decimal tmp;
                    if (!decimal.TryParse(txtPnL.Text, out tmp))
                    {
                        MessageBox.Show("PnL must be a valid number.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                    pnl = tmp;
                }
                if (string.IsNullOrWhiteSpace(txtExchange.Text) || string.IsNullOrWhiteSpace(txtProduct.Text) || string.IsNullOrWhiteSpace(txtStrategy.Text) || string.IsNullOrWhiteSpace(txtSide.Text))
                {
                    MessageBox.Show("Exchange, Product, Strategy, and Side are required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                Result = new TradeRecord
                {
                    Enabled = chkEnabled.Checked,
                    Exchange = txtExchange.Text.Trim(),
                    ProductId = txtProduct.Text.Trim(),
                    Strategy = txtStrategy.Text.Trim(),
                    Side = txtSide.Text.Trim(),
                    Quantity = qty,
                    Price = price,
                    EstEdge = edge,
                    AtUtc = dtAtUtc.Value.ToUniversalTime(),
                    Executed = chkExecuted.Checked,
                    FillPrice = fillPrice,
                    PnL = pnl,
                    Notes = txtNotes.Text.Trim()
                };
                return true;
            }
        }
    }
}