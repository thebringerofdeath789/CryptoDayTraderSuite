using System;
using System.Drawing;
using System.Windows.Forms;

namespace CryptoDayTraderSuite.UI
{
    public partial class AutoModeForm : Form
    {





        private void InitializeComponent()
        {
            var root = new TableLayoutPanel();
            root.Dock = DockStyle.Fill;
            root.ColumnCount = 1;
            root.RowCount = 3;
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            this.Controls.Add(root);

            var top = new FlowLayoutPanel();
            top.Dock = DockStyle.Fill;
            top.AutoSize = true;
            top.Padding = new Padding(8);

            top.Controls.Add(new Label { Text = "Product", AutoSize = true, Padding = new Padding(0,6,8,0) });
            this.cmbProduct = this.cmbProduct ?? new ComboBox();
            this.cmbProduct.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbProduct.Width = 200;
            top.Controls.Add(this.cmbProduct);

            top.Controls.Add(new Label { Text = "Gran (min)", AutoSize = true, Padding = new Padding(12,6,8,0) });
            this.cmbGran = this.cmbGran ?? new ComboBox();
            this.cmbGran.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbGran.Items.AddRange(new object[] { "1", "5", "15", "30", "60", "240" });
            this.cmbGran.SelectedIndex = 2;
            this.cmbGran.Width = 80;
            top.Controls.Add(this.cmbGran);

            top.Controls.Add(new Label { Text = "Lookback (days)", AutoSize = true, Padding = new Padding(12,6,8,0) });
            this.numLookback = this.numLookback ?? new NumericUpDown();
            this.numLookback.Minimum = 7; this.numLookback.Maximum = 365; this.numLookback.Value = 30;
            this.numLookback.Width = 90;
            top.Controls.Add(this.numLookback);

            top.Controls.Add(new Label { Text = "Account", AutoSize = true, Padding = new Padding(12,6,8,0) });
            this.cmbAccount = this.cmbAccount ?? new ComboBox();
            this.cmbAccount.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbAccount.Width = 200;
            top.Controls.Add(this.cmbAccount);

            top.Controls.Add(new Label { Text = "Equity ($)", AutoSize = true, Padding = new Padding(12,6,8,0) });
            this.numEquity = this.numEquity ?? new NumericUpDown();
            this.numEquity.DecimalPlaces = 2; this.numEquity.Minimum = 10; this.numEquity.Maximum = 10000000; this.numEquity.Value = 1000;
            this.numEquity.Width = 110;
            top.Controls.Add(this.numEquity);

            this.btnScan = this.btnScan ?? new Button(); this.btnScan.Text = "Scan"; this.btnScan.Width = 90; this.btnScan.Height = 28; this.btnScan.Margin = new Padding(24,4,4,4);
            this.btnPropose = this.btnPropose ?? new Button(); this.btnPropose.Text = "Propose"; this.btnPropose.Width = 90; this.btnPropose.Height = 28; this.btnPropose.Margin = new Padding(4,4,4,4);
            this.btnExecute = this.btnExecute ?? new Button(); this.btnExecute.Text = "Execute"; this.btnExecute.Width = 90; this.btnExecute.Height = 28; this.btnExecute.Margin = new Padding(4,4,4,4);
            top.Controls.Add(this.btnScan);
            top.Controls.Add(this.btnPropose);
            top.Controls.Add(this.btnExecute);

            root.Controls.Add(top, 0, 0);

            this.grid = this.grid ?? new DataGridView();
            this.grid.Dock = DockStyle.Fill;
            this.grid.ReadOnly = true;
            this.grid.AutoGenerateColumns = true;
            this.grid.AllowUserToAddRows = false;
            this.grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            root.Controls.Add(this.grid, 0, 1);

            var bottom = new FlowLayoutPanel();
            bottom.Dock = DockStyle.Fill;
            bottom.AutoSize = true;
            bottom.Padding = new Padding(8);
            root.Controls.Add(bottom, 0, 2);

            this.Text = "Auto Mode";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Width = 1100; this.Height = 700;

            try
            {
                var mi = this.GetType().GetMethod("AfterBuildUi", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Public);
                if (mi != null) mi.Invoke(this, null);
            }
            catch { }
        }
    }
}
