using System;
using System.Windows.Forms;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Services;

namespace CryptoDayTraderSuite.UI
{
    public partial class AccountEditDialog : Form
    {
        private string _id;
        private TextBox txtLabel, txtKeyId;
        private ComboBox cmbService, cmbMode;
        private NumericUpDown numRisk, numMax;

        public AccountEditDialog(string id)
        {
            InitializeComponent();
            _id = id;
            BuildUi();
            if (!string.IsNullOrEmpty(id)) LoadExisting();
        }

        private void BuildUi()
        {
            this.Text = string.IsNullOrEmpty(_id) ? "Add Account" : "Edit Account";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Width = 560;
            this.Height = 360;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            var tl = new TableLayoutPanel();
            tl.Dock = DockStyle.Fill;
            tl.ColumnCount = 2;
            tl.Padding = new Padding(10);
            tl.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            tl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            this.Controls.Add(tl);

            tl.Controls.Add(new Label { Text = "Label", AutoSize = true, Margin = new Padding(0, 8, 8, 8) }, 0, 0);
            txtLabel = new TextBox(); txtLabel.Width = 360; tl.Controls.Add(txtLabel, 1, 0);

            tl.Controls.Add(new Label { Text = "Service", AutoSize = true, Margin = new Padding(0, 8, 8, 8) }, 0, 1);
            cmbService = new ComboBox(); cmbService.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbService.Items.AddRange(new object[] { "paper", "coinbase-exchange", "coinbase-advanced", "kraken", "bitstamp" });
            tl.Controls.Add(cmbService, 1, 1);

            tl.Controls.Add(new Label { Text = "Mode", AutoSize = true, Margin = new Padding(0, 8, 8, 8) }, 0, 2);
            cmbMode = new ComboBox(); cmbMode.DropDownStyle = ComboBoxStyle.DropDownList; cmbMode.Items.AddRange(new object[] { "Paper", "Live" }); tl.Controls.Add(cmbMode, 1, 2);

            tl.Controls.Add(new Label { Text = "Risk per trade %", AutoSize = true, Margin = new Padding(0, 8, 8, 8) }, 0, 3);
            numRisk = new NumericUpDown(); numRisk.DecimalPlaces = 2; numRisk.Minimum = 0; numRisk.Maximum = 100; numRisk.Value = 0.50M; tl.Controls.Add(numRisk, 1, 3);

            tl.Controls.Add(new Label { Text = "Max concurrent trades", AutoSize = true, Margin = new Padding(0, 8, 8, 8) }, 0, 4);
            numMax = new NumericUpDown(); numMax.Minimum = 1; numMax.Maximum = 50; numMax.Value = 3; tl.Controls.Add(numMax, 1, 4);

            tl.Controls.Add(new Label { Text = "Key Entry Id", AutoSize = true, Margin = new Padding(0, 8, 8, 8) }, 0, 5);
            txtKeyId = new TextBox(); txtKeyId.Width = 360; tl.Controls.Add(txtKeyId, 1, 5);

            var bar = new FlowLayoutPanel(); bar.Dock = DockStyle.Bottom; bar.FlowDirection = FlowDirection.RightToLeft; bar.Padding = new Padding(8);
            var btnSave = new Button(); btnSave.Text = "Save"; btnSave.Click += (s, e) => SaveClicked();
            var btnCancel = new Button(); btnCancel.Text = "Cancel"; btnCancel.Click += (s, e) => this.DialogResult = DialogResult.Cancel;
            bar.Controls.Add(btnSave); bar.Controls.Add(btnCancel);
            this.Controls.Add(bar);
        }

        private void LoadExisting()
        {
            var a = AccountRegistry.Get(_id);
            if (a == null) return;
            txtLabel.Text = a.Label;
            cmbService.SelectedItem = a.Service;
            cmbMode.SelectedItem = a.Mode.ToString();
            numRisk.Value = a.RiskPerTradePct;
            numMax.Value = a.MaxConcurrentTrades;
            txtKeyId.Text = a.KeyEntryId;
        }

        private void SaveClicked()
        {
            if (string.IsNullOrWhiteSpace(txtLabel.Text)) { MessageBox.Show("label required"); return; }
            if (cmbService.SelectedItem == null) { MessageBox.Show("service required"); return; }
            if (cmbMode.SelectedItem == null) { MessageBox.Show("mode required"); return; }

            var a = string.IsNullOrEmpty(_id) 
                ? (AccountProfile)new AccountProfile { Id = Guid.NewGuid().ToString(), CreatedUtc = DateTime.UtcNow } 
                : (AccountProfile)(AccountRegistry.Get(_id) ?? new AccountProfile { Id = Guid.NewGuid().ToString() });
            a.Label = txtLabel.Text.Trim();
            a.Service = cmbService.SelectedItem.ToString();
            a.Mode = (cmbMode.SelectedItem.ToString() == "Live") ? AccountMode.Live.ToString() : AccountMode.Paper.ToString();
            a.RiskPerTradePct = numRisk.Value;
            a.MaxConcurrentTrades = (int)numMax.Value;
            a.KeyEntryId = txtKeyId.Text.Trim();
            a.Enabled = true;
            a.UpdatedUtc = DateTime.UtcNow;
            AccountRegistry.Upsert(a);
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }
}