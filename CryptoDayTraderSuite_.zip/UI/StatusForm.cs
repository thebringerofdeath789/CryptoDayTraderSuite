using System;
using System.Drawing;
using System.Windows.Forms;

namespace CryptoDayTraderSuite.UI
{
    public class StatusForm : Form
    {
        private DataGridView grid;
        private Label lblSummary;

        public StatusForm()
        {
            this.Text = "Status / PnL vs Projection";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Width = 1000; this.Height = 700;

            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            this.Controls.Add(root);

            lblSummary = new Label { Text = "Summary: ", AutoSize = true, Padding = new Padding(8) };
            root.Controls.Add(lblSummary, 0, 0);

            grid = new DataGridView { Dock = DockStyle.Fill, ReadOnly = true, AutoGenerateColumns = true, AllowUserToAddRows = false };
            root.Controls.Add(grid, 0, 1);
        }

        public void LoadData(object rows, string summary)
        {
            try { grid.DataSource = rows; } catch { }
            if (!string.IsNullOrEmpty(summary)) lblSummary.Text = "Summary: " + summary;
        }
    }
}