/* File: UI/MainForm_PlannerButton.cs */
/* Author: Gregory King */
/* Date: 2025-08-10 */
/* Description: adds a Planner button to MainForm without editing the designer */
/* Functions: AddPlannerButton */

using System;
using System.Windows.Forms;

namespace CryptoDayTraderSuite.UI
{
    public static class MainFormPlannerButton
    {
        public static void AddPlannerButton(MainForm form)
        {
            /* create a button and place it near the bottom-right */
            var btn = new Button();
            btn.Text = "Planner";
            btn.Width = 90; btn.Height = 28;
            btn.Left = Math.Max(12, form.Width - 110);
            btn.Top = Math.Max(12, form.Height - 70);
            btn.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btn.Click += (s, e) => {
                var mi = form.GetType().GetMethod("btnPlanner_Click", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (mi != null) mi.Invoke(form, new object[] { form, EventArgs.Empty });
            };
            form.Controls.Add(btn);
        }
    }
}