namespace CryptoDayTraderSuite.UI
{
    partial class AccountsForm
    {
        private void InitializeComponent() { }
    }
}