/* file: UI/MainForm_Menu.cs */
using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace CryptoDayTraderSuite.UI
{
	public static class MainFormMenu
	{
		public static void Attach(MainForm f)
		{
			var menu = new MenuStrip(); menu.Dock = DockStyle.Top;
			f.MainMenuStrip = menu;
			f.Controls.Add(menu);
			f.Controls.SetChildIndex(menu, 0);

			var mFile = new ToolStripMenuItem("File");
			var mProfiles = new ToolStripMenuItem("Profiles");
			var mAccounts = new ToolStripMenuItem("Accounts");
			var mKeys = new ToolStripMenuItem("API Keys");
			var mData = new ToolStripMenuItem("Data");
			var mTrading = new ToolStripMenuItem("Trading");
			var mView = new ToolStripMenuItem("View");
			var mTools = new ToolStripMenuItem("Tools");
			var mLogs = new ToolStripMenuItem("Logs");
			var mHelp = new ToolStripMenuItem("Help");
			var mPlanner = new ToolStripMenuItem("Planner");

			menu.Items.AddRange(new ToolStripItem[] { mFile, mProfiles, mAccounts, mKeys, mData, mTrading, mView, mTools, mLogs, mHelp, mPlanner });

			/* file */
			mFile.DropDownItems.Add(new ToolStripMenuItem("Exit", null, (s, e) => f.Close()));

			/* profiles */
			mProfiles.DropDownItems.Add(new ToolStripMenuItem("Export Profile...", null, (s, e) => ExportProfile(f)));
			mProfiles.DropDownItems.Add(new ToolStripMenuItem("Import Profile...", null, (s, e) => ImportProfile(f)));

			/* accounts */
			mAccounts.DropDownItems.Add(new ToolStripMenuItem("Manage Accounts...", null, (s, e) => { using (var dlg = new AccountsForm()) dlg.ShowDialog(f); }));

			/* api keys */
			mKeys.DropDownItems.Add(new ToolStripMenuItem("Manage API Keys...", null, (s, e) => { using (var dlg = new KeysForm()) dlg.ShowDialog(f); }));

			/* data */
			mData.DropDownItems.Add(new ToolStripMenuItem("Load Products", null, (s, e) => TryClick(f, "btnLoadProducts")));
			mData.DropDownItems.Add(new ToolStripMenuItem("Get Fees", null, (s, e) => TryClick(f, "btnFees")));

			/* trading */
			mTrading.DropDownItems.Add(new ToolStripMenuItem("Auto Mode...", null, (s, e) => { using (var dlg = new AutoModeForm()) dlg.ShowDialog(f); }));
			mTrading.DropDownItems.Add(new ToolStripMenuItem("Status / PnL vs Projection...", null, (s, e) => { using (var dlg = new StatusForm()) dlg.ShowDialog(f); }));
			mTrading.DropDownItems.Add(new ToolStripMenuItem("Settings...", null, (s, e) => { using (var dlg = new SettingsForm()) dlg.ShowDialog(f); }));

			/* view */
			mView.DropDownItems.Add(new ToolStripMenuItem("Refresh Layout", null, (s, e) => f.PerformLayout()));

			/* tools */
			mTools.DropDownItems.Add(new ToolStripMenuItem("Backtest", null, (s, e) => TryClick(f, "btnBacktest")));
			mTools.DropDownItems.Add(new ToolStripMenuItem("Paper Trade", null, (s, e) => TryClick(f, "btnPaper")));
			mTools.DropDownItems.Add(new ToolStripMenuItem("Live Trade", null, (s, e) => TryClick(f, "btnLive")));
			mTools.DropDownItems.Add(new ToolStripMenuItem("Planner...", null, (s, e) => { using (var dlg = new PlannerForm()) dlg.ShowDialog(f); }));

			/* logs */
			mLogs.DropDownItems.Add(new ToolStripMenuItem("Open Log Folder", null, (s, e) => OpenLogFolder()));
			mLogs.DropDownItems.Add(new ToolStripMenuItem("Copy Recent Log To Clipboard", null, (s, e) => CopyRecentLogToClipboard(f)));

			/* help */
			mHelp.DropDownItems.Add(new ToolStripMenuItem("Open README", null, (s, e) => OpenReadme()));
			mHelp.DropDownItems.Add(new ToolStripMenuItem("About", null, (s, e) => MessageBox.Show(f, "Crypto Day-Trading Suite\r\n© Gregory King", "About", MessageBoxButtons.OK, MessageBoxIcon.Information)));

			/* planner */
			mPlanner.DropDownItems.Add(new ToolStripMenuItem("Open Planner...", null, (s, e) => { using (var dlg = new PlannerForm()) dlg.ShowDialog(f); }));
		}

		private static void TryClick(Form f, string fieldName)
		{
			/* try to click a known field by name */
			try
			{
				var fi = f.GetType().GetField(fieldName, System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Public);
				var val = fi != null ? fi.GetValue(f) : null;

				var btn = val as Button;
				if (btn != null) { btn.PerformClick(); return; }

				var tsi = val as ToolStripItem;
				if (tsi != null) { tsi.PerformClick(); return; }

				var ctrl = val as Control;
				if (ctrl != null)
				{
					var onClick = ctrl.GetType().GetMethod("OnClick", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
					if (onClick != null) onClick.Invoke(ctrl, new object[] { EventArgs.Empty });
				}
			}
			catch
			{
				/* ignore lookup errors */
			}
		}

		private static void ExportProfile(Form f)
		{
			using (var sfd = new SaveFileDialog())
			{
				sfd.Filter = "Profile (*.cdtp)|*.cdtp";
				sfd.Title = "Export Encrypted Profile";
				if (sfd.ShowDialog(f) == DialogResult.OK)
				{
					var pass = PromptPassphrase(f, "Enter passphrase to encrypt profile");
					if (pass == null) return;
					try
					{
						Services.ProfileStore.Export(sfd.FileName, pass);
						MessageBox.Show(f, "Profile exported.", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
					}
					catch (Exception ex)
					{
						MessageBox.Show(f, "Export failed: " + ex.Message, "Export", MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
				}
			}
		}

		private static void ImportProfile(Form f)
		{
			using (var ofd = new OpenFileDialog())
			{
				ofd.Filter = "Profile (*.cdtp)|*.cdtp";
				ofd.Title = "Import Encrypted Profile";
				if (ofd.ShowDialog(f) == DialogResult.OK)
				{
					var pass = PromptPassphrase(f, "Enter passphrase to decrypt profile");
					if (pass == null) return;
					try
					{
						Services.ProfileStore.Import(ofd.FileName, pass);
						MessageBox.Show(f, "Profile imported.", "Import", MessageBoxButtons.OK, MessageBoxIcon.Information);
					}
					catch (Exception ex)
					{
						MessageBox.Show(f, "Import failed: " + ex.Message, "Import", MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
				}
			}
		}

		private static string PromptPassphrase(Form f, string title)
		{
			var dlg = new Form(); dlg.Text = title; dlg.StartPosition = FormStartPosition.CenterParent; dlg.Width = 420; dlg.Height = 160;
			var tl = new TableLayoutPanel(); tl.Dock = DockStyle.Fill; tl.ColumnCount = 1; tl.RowCount = 3; dlg.Controls.Add(tl);
			tl.RowStyles.Add(new RowStyle(SizeType.AutoSize));
			tl.RowStyles.Add(new RowStyle(SizeType.AutoSize));
			tl.RowStyles.Add(new RowStyle(SizeType.AutoSize));

			var tb = new TextBox(); tb.PasswordChar = '●'; tb.Width = 360; tb.Margin = new Padding(12); tl.Controls.Add(tb, 0, 0);
			var bar = new FlowLayoutPanel(); bar.FlowDirection = FlowDirection.RightToLeft; bar.Margin = new Padding(12);
			var ok = new Button(); ok.Text = "OK"; var cancel = new Button(); cancel.Text = "Cancel";
			ok.Click += (s, e) => dlg.DialogResult = DialogResult.OK; cancel.Click += (s, e) => dlg.DialogResult = DialogResult.Cancel;
			bar.Controls.Add(ok); bar.Controls.Add(cancel); tl.Controls.Add(bar, 0, 1);

			return dlg.ShowDialog(f) == DialogResult.OK ? tb.Text : null;
		}

		private static void OpenLogFolder()
		{
			try
			{
				var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CryptoDayTraderSuite", "logs");
				if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
				Process.Start("explorer.exe", dir);
			}
			catch
			{
				/* ignore */
			}
		}

		private static void CopyRecentLogToClipboard(Form f)
		{
			try
			{
				var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CryptoDayTraderSuite", "logs");
				if (!Directory.Exists(dir)) { MessageBox.Show(f, "No logs yet.", "Logs", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
				var files = Directory.GetFiles(dir, "*.log");
				if (files.Length == 0) { MessageBox.Show(f, "No logs yet.", "Logs", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
				var last = files[files.Length - 1];
				Clipboard.SetText(File.ReadAllText(last, Encoding.UTF8));
				MessageBox.Show(f, "Copied.", "Logs", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show(f, "Copy failed: " + ex.Message, "Logs", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private static void OpenReadme()
		{
			try
			{
				var readmePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "README.md");
				if (File.Exists(readmePath)) Process.Start("notepad.exe", readmePath);
			}
			catch
			{
				/* ignore */
			}
		}
	}
}
