using System.Windows.Forms;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Strategy;

namespace CryptoDayTraderSuite.UI
{
    public partial class AutoModeForm : Form
    {
        private ComboBox cmbObjective;
        private TextBox txtTarget;

        partial void AfterBuildUi()
        {
            /* add objective controls to the first FlowLayoutPanel */
            if (this.Controls.Count > 0 && this.Controls[0] is TableLayoutPanel)
            {
                var tl = (TableLayoutPanel)this.Controls[0];
                if (tl.Controls.Count > 0 && tl.Controls[0] is FlowLayoutPanel)
                {
                    var top = (FlowLayoutPanel)tl.Controls[0];
                    top.Controls.Add(new Label { Text = "Mode", AutoSize = true, Padding = new Padding(12,6,8,0) });
                    cmbObjective = new ComboBox(); cmbObjective.DropDownStyle = ComboBoxStyle.DropDownList; cmbObjective.Items.AddRange(new object[]{ "USD growth", "Increase overall coins" }); cmbObjective.SelectedIndex = 0; top.Controls.Add(cmbObjective);

                    top.Controls.Add(new Label { Text = "Target", AutoSize = true, Padding = new Padding(12,6,8,0) });
                    txtTarget = new TextBox(); txtTarget.Width = 80; txtTarget.Text = "BTC"; top.Controls.Add(txtTarget);
                }
            }

            /* hook scan button to run objective-aware projection */
            if (btnScan != null)
            {
                btnScan.Click += (s, e) => {
                    if (cmbProduct.SelectedItem == null) return;
                    var symbol = cmbProduct.SelectedItem.ToString();
                    var gran = int.Parse(cmbGran.SelectedItem.ToString());
                    var objective = (cmbObjective != null && cmbObjective.SelectedIndex == 1) ? TradeObjective.CoinAccumulation : TradeObjective.USDGrowth;
                    var target = (txtTarget != null && !string.IsNullOrWhiteSpace(txtTarget.Text)) ? txtTarget.Text.Trim().ToUpperInvariant() : "BTC";
                    var rows = AutoPlannerEx.ProjectWithObjective(symbol, gran, (int)numLookback.Value, 0.006m, 0.004m, objective, target);
                    _last = rows;
                    grid.DataSource = rows;
                };
            }
        }
    }
}