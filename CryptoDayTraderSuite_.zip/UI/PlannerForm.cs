/* File: UI/PlannerForm.cs */
/* Author: Gregory King */
/* Date: 2025-08-10 */
/* Description: planner window to show planned and past trades, allow toggles and filters */
/* Functions: ctor, LoadData, btnRefresh_Click, btnSave_Click */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Services;

namespace CryptoDayTraderSuite.UI
{
    public partial class PlannerForm : Form
    {
        private List<TradeRecord> _planned = new List<TradeRecord>(); /* planned */
        private List<PredictionRecord> _preds = new List<PredictionRecord>(); /* predictions */

        public PlannerForm()
        {
            InitializeComponent(); /* init */
        }

        public void SetData(List<TradeRecord> planned)
        {
            _planned = planned ?? new List<TradeRecord>(); /* set */
            LoadData(); /* load */
        }

        private void LoadData()
        {
            gridPlanned.Rows.Clear(); /* clear */
            foreach (var p in _planned)
            {
                gridPlanned.Rows.Add(new object[] { p.Enabled, p.Exchange, p.ProductId, p.Strategy, p.Side, p.Quantity, p.Price, p.EstEdge, p.Notes });
            }

            _preds = HistoryStore.LoadPredictions(); /* load */
            gridPreds.Rows.Clear();
            foreach (var r in _preds.OrderByDescending(x=>x.AtUtc).Take(500))
            {
                gridPreds.Rows.Add(new object[] { r.ProductId, r.AtUtc.ToLocalTime(), r.HorizonMinutes, r.Direction, r.Probability, r.ExpectedReturn, r.ExpectedVol, r.RealizedKnown, r.RealizedDirection, r.RealizedReturn });
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e) { LoadData(); } /* refresh */

        private void btnSave_Click(object sender, EventArgs e)
        {
            /* update planned enabled flags from grid */
            for (int i = 0; i < gridPlanned.Rows.Count; i++)
            {
                var row = gridPlanned.Rows[i];
                bool en = Convert.ToBoolean(row.Cells[0].Value ?? false);
                if (i < _planned.Count) _planned[i].Enabled = en;
            }
            MessageBox.Show("planner updated"); /* ok */
        }
    }
}