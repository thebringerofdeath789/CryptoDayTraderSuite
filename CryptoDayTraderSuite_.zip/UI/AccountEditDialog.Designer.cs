namespace CryptoDayTraderSuite.UI
{
    partial class AccountEditDialog
    {
        private void InitializeComponent() { }
    }
}