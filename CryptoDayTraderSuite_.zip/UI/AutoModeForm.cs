using System;
using System.Linq;
using System.Windows.Forms;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Strategy;
using CryptoDayTraderSuite.Exchanges;
using CryptoDayTraderSuite.Services;

namespace CryptoDayTraderSuite.UI
{
    public partial class AutoModeForm : Form
    {
        protected ComboBox cmbProduct, cmbGran, cmbAccount;
        protected NumericUpDown numLookback, numEquity;
        protected DataGridView grid;
        protected Button btnScan, btnPropose, btnExecute;

        private System.Collections.Generic.List<ProjectionRow> _last;
        private System.Collections.Generic.List<AccountProfile> _accounts;

        public AutoModeForm()
        {
            InitializeComponent();
            BuildUi();
            LoadAccounts();
            LoadProducts();
        }

        private void BuildUi()
        {
            this.Text = "Automatic Mode";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Width = 980;
            this.Height = 640;

            var tl = new TableLayoutPanel(); tl.Dock = DockStyle.Fill; tl.ColumnCount = 1; tl.RowCount = 2;
            tl.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            tl.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            this.Controls.Add(tl);

            var top = new FlowLayoutPanel(); top.Dock = DockStyle.Top; top.AutoSize = true; top.Padding = new Padding(8);
            tl.Controls.Add(top, 0, 0);

            top.Controls.Add(new Label { Text = "Account", AutoSize = true, Padding = new Padding(0,6,8,0) });
            cmbAccount = new ComboBox(); cmbAccount.DropDownStyle = ComboBoxStyle.DropDownList; cmbAccount.Width = 200; top.Controls.Add(cmbAccount);

            top.Controls.Add(new Label { Text = "Product", AutoSize = true, Padding = new Padding(12,6,8,0) });
            cmbProduct = new ComboBox(); cmbProduct.DropDownStyle = ComboBoxStyle.DropDownList; cmbProduct.Width = 180; top.Controls.Add(cmbProduct);

            top.Controls.Add(new Label { Text = "Gran (min)", AutoSize = true, Padding = new Padding(12,6,8,0) });
            cmbGran = new ComboBox(); cmbGran.DropDownStyle = ComboBoxStyle.DropDownList; cmbGran.Items.AddRange(new object[]{ "1","5","15","30","60","240" }); cmbGran.SelectedIndex = 2; top.Controls.Add(cmbGran);

            top.Controls.Add(new Label { Text = "Lookback (days)", AutoSize = true, Padding = new Padding(12,6,8,0) });
            numLookback = new NumericUpDown(); numLookback.Minimum = 5; numLookback.Maximum = 120; numLookback.Value = 30; top.Controls.Add(numLookback);

            top.Controls.Add(new Label { Text = "Equity ($)", AutoSize = true, Padding = new Padding(12,6,8,0) });
            numEquity = new NumericUpDown(); numEquity.Minimum = 10; numEquity.Maximum = 1000000; numEquity.Value = 1000; top.Controls.Add(numEquity);

            btnScan = new Button(); btnScan.Text = "Scan"; btnScan.Click += (s, e) => DoScan(); top.Controls.Add(btnScan);
            btnPropose = new Button(); btnPropose.Text = "Propose"; btnPropose.Click += (s, e) => DoPropose(); top.Controls.Add(btnPropose);
            btnExecute = new Button(); btnExecute.Text = "Execute"; btnExecute.Click += (s, e) => DoExecute(); top.Controls.Add(btnExecute);

            grid = new DataGridView(); grid.Dock = DockStyle.Fill; grid.ReadOnly = true; grid.AutoGenerateColumns = false; grid.AllowUserToAddRows = false; grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Strategy", HeaderText = "Strategy", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, FillWeight = 200 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Expectancy", HeaderText = "Expectancy", Width = 110 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "WinRate", HeaderText = "Win%", Width = 80 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "AvgWin", HeaderText = "AvgWin", Width = 90 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "AvgLoss", HeaderText = "AvgLoss", Width = 90 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "SharpeApprox", HeaderText = "Sharpe", Width = 80 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Samples", HeaderText = "Samples", Width = 80 });
            tl.Controls.Add(grid, 0, 1);

            AfterBuildUi(); /* partial hook */
        }

        partial void AfterBuildUi();

        private void LoadAccounts()
        {
            _accounts = AccountRegistry.List()
                .FindAll(a => a.Enabled)
                .Select(a => (AccountProfile)a)
                .ToList();
            cmbAccount.Items.Clear();
            foreach (var a in _accounts) cmbAccount.Items.Add(a.Label + " [" + a.Service + "]");
            if (cmbAccount.Items.Count > 0) cmbAccount.SelectedIndex = 0;
        }

        private void LoadProducts()
        {
            try
            {
                var pub = new CoinbasePublicClient();
                var prods = pub.GetProducts();
                cmbProduct.Items.Clear();
                foreach (var p in prods) cmbProduct.Items.Add(p);
                if (cmbProduct.Items.Count > 0) cmbProduct.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("failed to load products: " + ex.Message);
            }
        }

        private void DoScan()
        {
            if (cmbProduct.SelectedItem == null) return;
            var symbol = cmbProduct.SelectedItem.ToString();
            var gran = int.Parse(cmbGran.SelectedItem.ToString());
            var rows = AutoPlanner.Project(symbol, gran, (int)numLookback.Value, 0.006m, 0.004m);
            _last = rows;
            grid.DataSource = rows;
        }

        private void DoPropose()
        {
            if (_last == null || _last.Count == 0) { MessageBox.Show("scan first"); return; }
            if (cmbAccount.SelectedIndex < 0) { MessageBox.Show("select account"); return; }
            var acc = _accounts[cmbAccount.SelectedIndex];
            var symbol = cmbProduct.SelectedItem.ToString();
            var gran = int.Parse(cmbGran.SelectedItem.ToString());
            var plans = AutoPlanner.Propose(acc.Id, symbol, gran, numEquity.Value, acc.RiskPerTradePct, _last);
            if (plans.Count == 0) { MessageBox.Show("no trades proposed"); return; }
            var msg = string.Join(Environment.NewLine, plans.Select(p => p.Strategy + " " + p.Symbol + " dir=" + (p.Direction>0?"LONG":"SHORT") + " qty=" + p.Qty + " entry=" + p.Entry + " stop=" + p.Stop + " target=" + p.Target));
            MessageBox.Show("proposed:" + Environment.NewLine + msg);
            _queued = plans;
        }

        private System.Collections.Generic.List<TradePlan> _queued;

        private async void DoExecute()
        {
            if (_queued == null || _queued.Count == 0) { MessageBox.Show("nothing to execute"); return; }
            if (cmbAccount.SelectedIndex < 0) { MessageBox.Show("select account"); return; }
            var acc = _accounts[cmbAccount.SelectedIndex];
            CryptoDayTraderSuite.Brokers.IBroker broker;
            AccountMode mode;
            if ((Enum.TryParse(acc.Mode, out mode) && mode == AccountMode.Paper) || acc.Service == "paper")
            {
                broker = new CryptoDayTraderSuite.Brokers.PaperBroker();
            }
            else broker = new CryptoDayTraderSuite.Brokers.CoinbaseExchangeBroker();

            foreach (var p in _queued)
            {
                if (p.AccountId != acc.Id) continue;
                var r = await broker.PlaceOrderAsync(p);
                MessageBox.Show((r.ok ? "ok: " : "err: ") + r.message);
            }
        }
    }
}