using System;
using System.Windows.Forms;

namespace CryptoDayTraderSuite.UI
{
    public class SettingsForm : Form
    {
        public SettingsForm()
        {
            this.Text = "Settings";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Width = 800; this.Height = 600;

            var tabs = new TabControl { Dock = DockStyle.Fill };
            this.Controls.Add(tabs);

            var tabGeneral = new TabPage("General");
            var tabTrading = new TabPage("Trading");
            var tabData = new TabPage("Data");
            tabs.TabPages.Add(tabGeneral);
            tabs.TabPages.Add(tabTrading);
            tabs.TabPages.Add(tabData);

            tabGeneral.Controls.Add(new Label { Text = "General application preferences.", Dock = DockStyle.Top, Padding = new Padding(8) });
            tabTrading.Controls.Add(new Label { Text = "Trading defaults and risk settings.", Dock = DockStyle.Top, Padding = new Padding(8) });
            tabData.Controls.Add(new Label { Text = "Data sources and cache settings.", Dock = DockStyle.Top, Padding = new Padding(8) });
        }
    }
}