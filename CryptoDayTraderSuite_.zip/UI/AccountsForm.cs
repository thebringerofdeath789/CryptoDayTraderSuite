using System;
using System.Windows.Forms;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Services;

namespace CryptoDayTraderSuite.UI
{
    public partial class AccountsForm : Form
    {
        private BindingSource _bs = new BindingSource();
        private DataGridView _grid;

        public AccountsForm()
        {
            InitializeComponent();
            BuildUi();
            LoadData();
        }

        private void BuildUi()
        {
            this.Text = "Accounts";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Width = 900;
            this.Height = 520;

            var tl = new TableLayoutPanel();
            tl.Dock = DockStyle.Fill;
            tl.ColumnCount = 1;
            tl.RowCount = 2;
            tl.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            tl.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            this.Controls.Add(tl);

            var top = new FlowLayoutPanel();
            top.Dock = DockStyle.Top;
            top.AutoSize = true;
            top.Padding = new Padding(8);
            var _btnAdd = new Button(); _btnAdd.Text = "Add"; _btnAdd.Click += (s, e) => AddClicked();
            var _btnEdit = new Button(); _btnEdit.Text = "Edit"; _btnEdit.Click += (s, e) => EditSelected();
            var _btnDelete = new Button(); _btnDelete.Text = "Delete"; _btnDelete.Click += (s, e) => DeleteSelected();
            var _btnClose = new Button(); _btnClose.Text = "Close"; _btnClose.Click += (s, e) => this.Close();
            top.Controls.AddRange(new Control[] { _btnAdd, _btnEdit, _btnDelete, _btnClose });
            tl.Controls.Add(top, 0, 0);

            _grid = new DataGridView();
            _grid.Dock = DockStyle.Fill;
            _grid.ReadOnly = true;
            _grid.AutoGenerateColumns = false;
            _grid.AllowUserToAddRows = false;
            _grid.AllowUserToDeleteRows = false;
            _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _grid.MultiSelect = false;
            _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Label", HeaderText = "Label", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, FillWeight = 220 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Service", HeaderText = "Service", Width = 180 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Mode", HeaderText = "Mode", Width = 80 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "RiskPerTradePct", HeaderText = "Risk %", Width = 80 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "MaxConcurrentTrades", HeaderText = "Max Open", Width = 90 });
            _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "KeyEntryId", HeaderText = "Key Id", Width = 280 });
            _grid.DoubleClick += (s, e) => EditSelected();
            tl.Controls.Add(_grid, 0, 1);
        }

        private void LoadData()
        {
            var rows = AccountRegistry.List();
            _bs.DataSource = rows;
            _grid.DataSource = _bs;
        }

        private AccountProfile Selected()
        {
            return _grid.CurrentRow != null ? _grid.CurrentRow.DataBoundItem as AccountProfile : null;
        }

        private void AddClicked()
        {
            var dlg = new AccountEditDialog(null);
            if (dlg.ShowDialog(this) == DialogResult.OK) LoadData();
        }

        private void EditSelected()
        {
            var cur = Selected();
            if (cur == null) return;
            var dlg = new AccountEditDialog(cur.Id);
            if (dlg.ShowDialog(this) == DialogResult.OK) LoadData();
        }

        private void DeleteSelected()
        {
            var cur = Selected();
            if (cur == null) return;
            if (MessageBox.Show("Delete account " + cur.Label + "?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                AccountRegistry.Delete(cur.Id);
                LoadData();
            }
        }
    }
}