using System;
using System.Linq;
using System.Windows.Forms;
using CryptoDayTraderSuite.Services;
using CryptoDayTraderSuite.Models;


namespace CryptoDayTraderSuite.UI
{
    public partial class KeyEditDialog : Form
    {
        private string _id;
        private ComboBox cmbService;
        private TextBox txtLabel, txtApiKey, txtSecret, txtPass, txtKeyName, txtPem;
        private CheckBox chkActive;

        public KeyEditDialog(string id)
        {
            InitializeComponent();
            _id = id;
            BuildUi();
            if (!string.IsNullOrEmpty(id)) LoadExisting();
        }

        private void BuildUi()
        {
            this.Text = string.IsNullOrEmpty(_id) ? "Add Key" : "Edit Key";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Width = 700; this.Height = 540;
            this.FormBorderStyle = FormBorderStyle.FixedDialog; this.MaximizeBox = false;

            var tl = new TableLayoutPanel(); tl.Dock = DockStyle.Fill; tl.ColumnCount = 2; tl.Padding = new Padding(10);
            tl.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            tl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            this.Controls.Add(tl);

            tl.Controls.Add(new Label { Text = "Service", AutoSize = true, Margin = new Padding(0,8,8,8) }, 0, 0);
            cmbService = new ComboBox(); cmbService.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbService.Items.AddRange(new object[] { "coinbase-exchange", "coinbase-advanced", "kraken", "bitstamp" });
            tl.Controls.Add(cmbService, 1, 0);

            tl.Controls.Add(new Label { Text = "Label", AutoSize = true, Margin = new Padding(0,8,8,8) }, 0, 1);
            txtLabel = new TextBox(); tl.Controls.Add(txtLabel, 1, 1);

            tl.Controls.Add(new Label { Text = "Active", AutoSize = true, Margin = new Padding(0,8,8,8) }, 0, 2);
            chkActive = new CheckBox(); tl.Controls.Add(chkActive, 1, 2);

            var sep1 = new Label { Text = "coinbase-exchange fields", AutoSize = true, Margin = new Padding(0,16,8,8) };
            sep1.Font = new System.Drawing.Font(sep1.Font, System.Drawing.FontStyle.Bold);
            tl.Controls.Add(sep1, 0, 3);
            tl.SetColumnSpan(sep1, 2);

            tl.Controls.Add(new Label { Text = "API Key", AutoSize = true, Margin = new Padding(0,8,8,8) }, 0, 4);
            txtApiKey = new TextBox(); tl.Controls.Add(txtApiKey, 1, 4);

            tl.Controls.Add(new Label { Text = "API Secret (base64)", AutoSize = true, Margin = new Padding(0,8,8,8) }, 0, 5);
            txtSecret = new TextBox(); tl.Controls.Add(txtSecret, 1, 5);

            tl.Controls.Add(new Label { Text = "Passphrase", AutoSize = true, Margin = new Padding(0,8,8,8) }, 0, 6);
            txtPass = new TextBox(); tl.Controls.Add(txtPass, 1, 6);

            var sep2 = new Label { Text = "coinbase-advanced fields", AutoSize = true, Margin = new Padding(0,16,8,8) };
            sep2.Font = new System.Drawing.Font(sep2.Font, System.Drawing.FontStyle.Bold);
            tl.Controls.Add(sep2, 0, 7);
            tl.SetColumnSpan(sep2, 2);

            tl.Controls.Add(new Label { Text = "API Key Name", AutoSize = true, Margin = new Padding(0,8,8,8) }, 0, 8);
            txtKeyName = new TextBox(); tl.Controls.Add(txtKeyName, 1, 8);

            tl.Controls.Add(new Label { Text = "EC Private Key (PEM)", AutoSize = true, Margin = new Padding(0,8,8,8) }, 0, 9);
            txtPem = new TextBox(); txtPem.Multiline = true; txtPem.Height = 120; tl.Controls.Add(txtPem, 1, 9);

            var bar = new FlowLayoutPanel(); bar.Dock = DockStyle.Bottom; bar.FlowDirection = FlowDirection.RightToLeft; bar.Padding = new Padding(8);
            var btnSave = new Button { Text = "Save" }; btnSave.Click += (s, e) => SaveClicked();
            var btnCancel = new Button { Text = "Cancel" }; btnCancel.Click += (s, e) => this.DialogResult = DialogResult.Cancel;
            bar.Controls.Add(btnSave); bar.Controls.Add(btnCancel);
            this.Controls.Add(bar);
        }

        private void LoadExisting()
        {
            var k = KeyRegistry.Get(_id);
            if (k == null) return;
            cmbService.SelectedItem = k.Service;
            txtLabel.Text = k.Label;
            chkActive.Checked = k.Active;
            string v;
            if (k.Data.TryGetValue("ApiKey", out v)) txtApiKey.Text = KeyRegistry.Unprotect(v);
            if (k.Data.TryGetValue("ApiSecretBase64", out v)) txtSecret.Text = KeyRegistry.Unprotect(v);
            if (k.Data.TryGetValue("Passphrase", out v)) txtPass.Text = KeyRegistry.Unprotect(v);
            if (k.Data.TryGetValue("ApiKeyName", out v)) txtKeyName.Text = v;
            if (k.Data.TryGetValue("ECPrivateKeyPem", out v)) txtPem.Text = KeyRegistry.Unprotect(v);
        }

        private void SaveClicked()
        {
            if (cmbService.SelectedItem == null) { MessageBox.Show("service required"); return; }
            if (string.IsNullOrWhiteSpace(txtLabel.Text)) { MessageBox.Show("label required"); return; }

            var k = string.IsNullOrEmpty(_id) ? new KeyEntry { Id = Guid.NewGuid().ToString(), CreatedUtc = DateTime.UtcNow } : KeyRegistry.Get(_id) ?? new KeyEntry { Id = Guid.NewGuid().ToString() };
            k.Service = cmbService.SelectedItem.ToString();
            k.Label = txtLabel.Text.Trim();
            k.Active = chkActive.Checked;
            k.UpdatedUtc = DateTime.UtcNow;

            k.Data["ApiKey"] = KeyRegistry.Protect(txtApiKey.Text.Trim());
            k.Data["ApiSecretBase64"] = KeyRegistry.Protect(txtSecret.Text.Trim());
            k.Data["Passphrase"] = KeyRegistry.Protect(txtPass.Text.Trim());
            k.Data["ApiKeyName"] = txtKeyName.Text.Trim();
            k.Data["ECPrivateKeyPem"] = KeyRegistry.Protect(txtPem.Text);

			//KeyRegistry.Upsert((KeyInfo)keyEntry);

            KeyRegistry.Upsert((KeyInfo)k);

			if (k.Active) KeyRegistry.SetActive(k.Service, k.Id);
            this.DialogResult = DialogResult.OK;
        }
    }
}