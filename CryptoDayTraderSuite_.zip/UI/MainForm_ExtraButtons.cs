using System;
using System.Windows.Forms;

namespace CryptoDayTraderSuite.UI
{
    public static class MainFormExtraButtons
    {
        public static void Add(MainForm f)
        {
            try
            {
                var btnAcc = new Button(); btnAcc.Text = "Accounts"; btnAcc.Width = 90; btnAcc.Height = 26; btnAcc.Top = 12; btnAcc.Left = f.ClientSize.Width - btnAcc.Width - 12; btnAcc.Anchor = AnchorStyles.Top | AnchorStyles.Right; f.Controls.Add(btnAcc);
                var btnKeys = new Button(); btnKeys.Text = "Keys"; btnKeys.Width = 70; btnKeys.Height = 26; btnKeys.Top = 44; btnKeys.Left = f.ClientSize.Width - btnKeys.Width - 12; btnKeys.Anchor = AnchorStyles.Top | AnchorStyles.Right; f.Controls.Add(btnKeys);
                var btnAuto = new Button(); btnAuto.Text = "Auto"; btnAuto.Width = 70; btnAuto.Height = 26; btnAuto.Top = 76; btnAuto.Left = f.ClientSize.Width - btnAuto.Width - 12; btnAuto.Anchor = AnchorStyles.Top | AnchorStyles.Right; f.Controls.Add(btnAuto);

                btnAcc.Click += (s, e) => { using (var dlg = new CryptoDayTraderSuite.UI.AccountsForm()) dlg.ShowDialog(f); };
                btnKeys.Click += (s, e) => { using (var dlg = new CryptoDayTraderSuite.UI.KeysForm()) dlg.ShowDialog(f); };
                btnAuto.Click += (s, e) => { using (var dlg = new CryptoDayTraderSuite.UI.AutoModeForm()) dlg.ShowDialog(f); };

                f.Resize += (s, e) => {
                    btnAcc.Left = f.ClientSize.Width - btnAcc.Width - 12;
                    btnKeys.Left = f.ClientSize.Width - btnKeys.Width - 12;
                    btnAuto.Left = f.ClientSize.Width - btnAuto.Width - 12;
                };
            }
            catch { }
        }
    }
}