/* File: Themes/Theme.cs */
/* simple dark theme */
using System.Drawing;
using System.Windows.Forms;

namespace CryptoDayTraderSuite.Themes
{
    public static class Theme
    {
        public static Color Bg = Color.FromArgb(26, 28, 34);
        public static Color Panel = Color.FromArgb(36, 38, 45);
        public static Color Text = Color.FromArgb(230, 232, 236);
        public static Color Accent = Color.FromArgb(80, 140, 255);

        public static void Apply(Form f)
        {
            f.BackColor = Bg;
            f.ForeColor = Text;
            foreach (Control c in f.Controls) ApplyControl(c);
        }

        private static void ApplyControl(Control c)
        {
            if (c is Button) { var b = (Button)c; b.FlatStyle = FlatStyle.Flat; b.FlatAppearance.BorderColor = Panel; b.BackColor = Panel; b.ForeColor = Text; }
            else if (c is TextBox) { c.BackColor = Panel; c.ForeColor = Text; }
            else if (c is ComboBox) { c.BackColor = Panel; c.ForeColor = Text; }
            else if (c is NumericUpDown) { c.BackColor = Panel; c.ForeColor = Text; }
            else if (c is DataGridView) { var g = (DataGridView)c; g.BackgroundColor = Panel; g.BorderStyle = BorderStyle.None; g.EnableHeadersVisualStyles = false; g.ColumnHeadersDefaultCellStyle.BackColor = Panel; g.ColumnHeadersDefaultCellStyle.ForeColor = Text; g.DefaultCellStyle.BackColor = Bg; g.DefaultCellStyle.ForeColor = Text; }
            else if (c is TabControl) { c.BackColor = Bg; c.ForeColor = Text; }
            else { if (c.BackColor == SystemColors.Control) c.BackColor = Panel; c.ForeColor = Text; }

            foreach (Control k in c.Controls) ApplyControl(k);
        }
    }
}