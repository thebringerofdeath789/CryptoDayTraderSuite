/* File: MainForm_PredictionHook.cs */
/* Author: Gregory King */
/* Date: 2025-08-10 */
/* Description: hooks for running predictions, planning trades, and showing planner form */
/* Functions: AnalyzeAndPlanAsync, btnPlanner_Click */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Strategy;
using CryptoDayTraderSuite.Services;

namespace CryptoDayTraderSuite
{
    public partial class MainForm
    {
        private readonly PredictionEngine _predict = new PredictionEngine(); /* prediction */
        private readonly TradePlanner _planner = new TradePlanner(); /* planner */
        private UI.PlannerForm _plannerForm = null; /* window */

        private async Task AnalyzeAndPlanAsync(string product, List<Candle> candles)
        {
            /* compute features */
            var f = FeatureExtractor.ComputeFeatures(candles); /* features */

            /* predict next 5 min move */
            var dir = _predict.PredictDirection(product, f, 5m); /* direction */
            var mag = _predict.PredictMagnitude(product, f, 5m); /* magnitude */

            /* save prediction */
            var rec = new PredictionRecord
            {
                ProductId = product,
                AtUtc = DateTime.UtcNow,
                HorizonMinutes = 5m,
                Direction = (int)dir.Direction,
                Probability = dir.Probability,
                ExpectedReturn = mag.ExpectedReturn,
                ExpectedVol = mag.ExpectedVol,
                RealizedKnown = false,
                RealizedDirection = 0,
                RealizedReturn = 0m
            };
            HistoryStore.SavePrediction(rec); /* persist */

            /* build trade candidates from our strategies using expected edge = prob-adjusted return minus friction */
            _planner.Clear(); /* reset */

            var fees = _fees; /* from main form */
            var friction = fees.MakerRate + fees.TakerRate + 0.0005m; /* est spread */

            /* candidate: ORB continuation */
            if (cmbStrategy.Items.Contains("ORB"))
            {
                var edge = mag.ExpectedReturn * dir.Probability - friction; /* naive edge */
                var side = edge >= 0m ? "buy" : "sell";
                _planner.AddCandidate(new TradeRecord
                {
                    Exchange = _client != null ? _client.Name : "n/a",
                    ProductId = product,
                    AtUtc = DateTime.UtcNow,
                    Strategy = "ORB",
                    Side = side,
                    Quantity = 0.0m, /* size decided later */
                    Price = candles[candles.Count - 1].Close,
                    EstEdge = Math.Abs(edge),
                    Executed = false,
                    Notes = "auto from prediction"
                });
            }

            /* candidate: VWAP reversion */
            if (cmbStrategy.Items.Contains("VWAPTrend"))
            {
                var edge = (-mag.ExpectedReturn) * (1m - dir.Probability) - friction;
                var side = edge >= 0m ? "sell" : "buy";
                _planner.AddCandidate(new TradeRecord
                {
                    Exchange = _client != null ? _client.Name : "n/a",
                    ProductId = product,
                    AtUtc = DateTime.UtcNow,
                    Strategy = "VWAPTrend",
                    Side = side,
                    Quantity = 0.0m,
                    Price = candles[candles.Count - 1].Close,
                    EstEdge = Math.Abs(edge),
                    Executed = false,
                    Notes = "auto from prediction"
                });
            }

            /* open planner window if requested */
            if (_plannerForm != null && !_plannerForm.IsDisposed)
            {
                _planner.ReapplyAll(); /* reapply rules */
                _plannerForm.SetData(_planner.Planned.ToList());
            }
        }

        private void btnPlanner_Click(object sender, EventArgs e)
        {
            if (_plannerForm == null || _plannerForm.IsDisposed)
            {
                _plannerForm = new UI.PlannerForm();
                _plannerForm.StartPosition = FormStartPosition.CenterParent;
            }
            _plannerForm.Show(this);
            _planner.ReapplyAll();
            _plannerForm.SetData(_planner.Planned.ToList());
        }
    }
}