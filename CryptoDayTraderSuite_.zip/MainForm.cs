/* File: MainForm.cs */
/* Author: Gregory King */
/* Date: 2025-08-10 */
/* Description: main form logic, wiring, and handlers */
/* Functions: ctor, Log, BuildClient, btnLoadProducts_Click, Load1mCandles, btnFees_Click, btnBacktest_Click, UpdateProjections, btnPaper_Click, btnLive_Click, btnSaveKeys_Click */

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using CryptoDayTraderSuite.Backtest;
using CryptoDayTraderSuite.Exchanges;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Strategy;
using CryptoDayTraderSuite.Util;
using CryptoDayTraderSuite.UI;

namespace CryptoDayTraderSuite
{
	public partial class MainForm : Form
	{
		private IExchangeClient _client = null; /* current client */
		private StrategyEngine _engine = new StrategyEngine(); /* engine */
		private FeeSchedule _fees = new FeeSchedule { MakerRate = 0.0040m, TakerRate = 0.0060m, Notes = "default" }; /* default */
		private TabControl _mainTabs;

		public MainForm()
		{
			InitializeComponent(); /* init */

			/* add cue banners for key fields on .net 4.8 */
			CueBanner.SetCue(txtApiKey, "api key"); /* cue */
			CueBanner.SetCue(txtSecret, "api secret (base64 if coinbase/kraken)"); /* cue */
			CueBanner.SetCue(txtExtra, "passphrase (coinbase) or customer id (bitstamp)"); /* cue */

			/* defaults */
			cmbExchange.SelectedIndex = 0; /* default */
			cmbStrategy.SelectedIndex = 0; /* default */
			Log("ready"); /* log */

			BuildMainTabs();
		}

		private void Log(string s) { txtLog.AppendText(DateTime.Now.ToString("HH:mm:ss") + " " + s + Environment.NewLine); } /* log */

		private IExchangeClient BuildClient()
		{
			var exch = cmbExchange.SelectedItem.ToString(); /* exch */
			var key = KeyStore.Unprotect(Properties.Settings.Default.ApiKey); /* key */
			var sec = KeyStore.Unprotect(Properties.Settings.Default.ApiSecret); /* sec */
			var extra = KeyStore.Unprotect(Properties.Settings.Default.ApiExtra); /* extra */
			if (exch == "Coinbase") return new CoinbaseExchangeClient(key, sec, extra); /* coinbase */
			if (exch == "Kraken") return new KrakenClient(key, sec); /* kraken */
			return new BitstampClient(key, sec, extra); /* bitstamp */
		}

		private async void btnLoadProducts_Click(object sender, EventArgs e)
		{
			try
			{
				_client = BuildClient(); /* build */
				var list = await _client.ListProductsAsync(); /* load */
				cmbProduct.Items.Clear(); foreach (var p in list.Where(x => x.Contains("/USD") || x.Contains("-USD"))) cmbProduct.Items.Add(p); /* usd pairs */
				if (cmbProduct.Items.Count > 0) cmbProduct.SelectedIndex = 0; /* select */
				Log("loaded products: " + cmbProduct.Items.Count); /* log */
			}
			catch (Exception ex) { Log("error loading products " + ex.Message); } /* error */
		}

		private async Task<List<Candle>> Load1mCandles(string productId, DateTime startUtc, DateTime endUtc)
		{
			var c = await _client.GetCandlesAsync(productId, 1, startUtc, endUtc); /* candles */
			return c; /* return */
		}

		private async void btnFees_Click(object sender, EventArgs e)
		{
			try
			{
				_client = BuildClient(); /* build */
				_fees = await _client.GetFeesAsync(); /* fetch */
				Log("fees maker " + (_fees.MakerRate * 100m).ToString("0.###") + "% taker " + (_fees.TakerRate * 100m).ToString("0.###") + "% " + _fees.Notes); /* log */
			}
			catch (Exception ex) { Log("error getting fees " + ex.Message); } /* err */
		}

		private async void btnBacktest_Click(object sender, EventArgs e)
		{
			try
			{
				_client = BuildClient(); /* client */
				var product = cmbProduct.SelectedItem?.ToString() ?? "BTC/USD"; /* product */
				var end = DateTime.UtcNow; var start = end.AddDays(-7); /* last week */
				var candles = await Load1mCandles(product, start, end); /* load */
				if (candles.Count < 100) { Log("not enough candles"); return; } /* guard */
				_engine.Active = cmbStrategy.SelectedItem.ToString() == "ORB" ? StrategyKind.ORB : StrategyKind.VWAPTrend; /* set */
				var riskFrac = (decimal)numRisk.Value / 100m; var equity = (decimal)numEquity.Value; /* risk */
				Func<List<Candle>, OrderRequest> signal = (sl) =>
				{
					var price = sl[sl.Count - 1].Close; /* last */
					CostBreakdown cb; /* costs */
					return _engine.Evaluate(product, sl, _fees, equity, riskFrac, price, out cb); /* order */
				}; /* func */

				var res = Backtest.Backtester.Run(candles, signal, _fees.MakerRate + _fees.TakerRate + 0.0005m); /* run */
				Log("backtest " + product + " trades " + res.Trades + " pnl $" + res.PnL.ToString("0.00") + " win " + (res.WinRate * 100m).ToString("0.0") + "% mdd " + (res.MaxDrawdown * 100m).ToString("0.0") + "%"); /* log */

				UpdateProjections(); /* projections */
			}
			catch (Exception ex) { Log("backtest error " + ex.Message); } /* err */
		}

		private void UpdateProjections()
		{
			var riskFrac = (decimal)numRisk.Value / 100m; /* risk */
			var roundtrip = _fees.MakerRate + _fees.TakerRate + 0.0005m; /* fees + spread */
			var p = new ProjectionInput { StartingEquity = 100m, TradesPerDay = 10, WinRate = 0.52m, AvgWinR = 1.1m, AvgLossR = 1.0m, RiskPerTradeFraction = riskFrac, NetFeeAndFrictionRate = roundtrip, Days = 20 }; /* params */
			var r = Projections.Compute(p); /* compute */
			lblProj100.Text = "$100 projection: " + r.EndingEquity.ToString("0.00") + " daily " + r.DailyExpectedReturnPct.ToString("0.00") + "%"; /* label */
			p.StartingEquity = 1000m; var r2 = Projections.Compute(p); lblProj1000.Text = "$1000 projection: " + r2.EndingEquity.ToString("0.00"); /* label */
		}

		private async void btnPaper_Click(object sender, EventArgs e)
		{
			try
			{
				_client = BuildClient(); /* client */
				var product = cmbProduct.SelectedItem?.ToString() ?? "BTC/USD"; /* product */
				var end = DateTime.UtcNow; var start = end.AddHours(-8); /* session */
				var candles = await Load1mCandles(product, start, end); /* load */
				_engine.Active = cmbStrategy.SelectedItem.ToString() == "ORB" ? StrategyKind.ORB : StrategyKind.VWAPTrend; /* set */
				var riskFrac = (decimal)numRisk.Value / 100m; var equity = (decimal)numEquity.Value; /* risk */
				CostBreakdown cb; /* costs */
				var price = candles[candles.Count - 1].Close; /* last */
				var order = _engine.Evaluate(product, candles, _fees, equity, riskFrac, price, out cb); /* eval */
				if (order == null) { Log("no paper signal"); return; } /* none */
				Log("paper trade " + order.Side + " " + order.Quantity + " " + product + " est fee " + (cb.TotalRoundTripRate * 100m).ToString("0.###") + "%"); /* log */
			}
			catch (Exception ex) { Log("paper error " + ex.Message); }
		}

		private async void btnLive_Click(object sender, EventArgs e)
		{
			try
			{
				_client = BuildClient(); /* client */
				var product = cmbProduct.SelectedItem?.ToString() ?? "BTC/USD"; /* product */
				var end = DateTime.UtcNow; var start = end.AddHours(-8); /* session */
				var candles = await Load1mCandles(product, start, end); /* load */
				_engine.Active = cmbStrategy.SelectedItem.ToString() == "ORB" ? StrategyKind.ORB : StrategyKind.VWAPTrend; /* set */
				var riskFrac = (decimal)numRisk.Value / 100m; var equity = (decimal)numEquity.Value; /* risk */
				var ticker = await _client.GetTickerAsync(product); /* ticker */
				CostBreakdown cb; /* costs */
				var order = _engine.Evaluate(product, candles, _fees, equity, riskFrac, ticker.Last, out cb); /* eval */
				if (order == null) { Log("no live signal"); return; } /* none */
				var res = await _client.PlaceOrderAsync(order); /* place */
				Log("live order " + res.OrderId + " " + res.Message); /* log */
			}
			catch (Exception ex) { Log("live error " + ex.Message); } /* err */
		}

		private void btnSaveKeys_Click(object sender, EventArgs e)
		{
			/* save encrypted keys to user settings */
			Properties.Settings.Default.ApiKey = KeyStore.Protect(txtApiKey.Text); /* save */
			Properties.Settings.Default.ApiSecret = KeyStore.Protect(txtSecret.Text); /* save */
			Properties.Settings.Default.ApiExtra = KeyStore.Protect(txtExtra.Text); /* save */
			Properties.Settings.Default.Save(); /* commit */
			Log("keys saved for " + cmbExchange.SelectedItem.ToString()); /* log */
		}

		private void BuildMainTabs()
		{
			_mainTabs = new TabControl { Dock = DockStyle.Fill };

			void AddTab(string title, Control ctrl)
			{
				var tab = new TabPage(title);
				ctrl.Dock = DockStyle.Fill;
				tab.Controls.Add(ctrl);
				_mainTabs.TabPages.Add(tab);
			}

			AddTab("Dashboard", new DashboardControl());
			AddTab("Trading", new TradingControl());
			AddTab("Planner", new PlannerControl());
			AddTab("Accounts", new AccountsControl());
			AddTab("API Keys", new KeysControl());
			AddTab("Status", new StatusControl());
			AddTab("Auto Mode", new AutoModeControl());

			this.Controls.Clear();
			this.Controls.Add(_mainTabs);
		}
	}
}
