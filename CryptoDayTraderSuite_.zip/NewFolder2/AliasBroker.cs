﻿using System;
using CryptoDayTraderSuite.Brokers;

namespace CryptoDayTraderSuite.Brokers
{
	/* these classes expose the types AutoModeForm references, inheriting the existing exchange clients */
	public class CoinbaseExchangeBroker : CryptoDayTraderSuite.Exchanges.CoinbaseExchangeClient
	{
		public CoinbaseExchangeBroker() : base() { }
	}

	public class KrakenBroker : CryptoDayTraderSuite.Exchanges.KrakenClient
	{
		public KrakenBroker() : base() { }
	}

	public class BitstampBroker : CryptoDayTraderSuite.Exchanges.BitstampClient
	{
		public BitstampBroker() : base() { }
	}
}
