
using System;
using System.Windows.Forms;

namespace CryptoDayTraderSuite
{
    static class Program
    {
        /* entry point */
        [STAThread]
        static void Main()
        {
            /* enable visual styles */
            Application.EnableVisualStyles(); /* enable */
            Application.SetCompatibleTextRenderingDefault(false); /* set */
            Application.Run(new MainForm()); /* run */
        }
    }
}
