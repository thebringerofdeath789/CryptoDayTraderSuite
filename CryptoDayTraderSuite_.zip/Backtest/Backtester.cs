
using System;
using System.Collections.Generic;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.Backtest
{
    public class Backtester
    {
        public class Result
        {
            public int Trades { get; set; } /* trades */
            public decimal PnL { get; set; } /* pnl */
            public decimal MaxDrawdown { get; set; } /* mdd */
            public decimal WinRate { get; set; } /* win */
        }

        public static Result Run(List<Candle> candles, Func<List<Candle>, OrderRequest> signal, decimal feeRoundTripRate)
        {
            var pos = new Position { ProductId = "", Qty = 0m, AvgPrice = 0m }; /* position */
            decimal equity = 1000m; decimal peak = equity; decimal trough = equity; decimal wins = 0m; decimal trades = 0m; /* stats */

            for (int i = 50; i < candles.Count; i++)
            {
                var slice = candles.GetRange(0, i + 1); /* up to i */
                var req = signal(slice); /* signal */
                if (req != null && pos.Qty == 0m)
                {
                    /* enter at close price */
                    var price = candles[i].Close; var qty = req.Quantity; /* qty */
                    pos.Qty = req.Side == OrderSide.Buy ? qty : -qty; pos.AvgPrice = price; trades += 1m; /* open */
                    /* fees applied on notional */
                    equity -= Math.Abs(qty * price) * feeRoundTripRate / 2m; /* entry half */
                }
                else if (pos.Qty != 0m)
                {
                    /* exit when opposite signal appears */
                    if ((pos.Qty > 0m && req != null && req.Side == OrderSide.Sell) || (pos.Qty < 0m && req != null && req.Side == OrderSide.Buy))
                    {
                        var price = candles[i].Close; /* price */
                        var pnl = (price - pos.AvgPrice) * pos.Qty; equity += pnl; /* pnl */
                        equity -= Math.Abs(pos.Qty * price) * feeRoundTripRate / 2m; /* exit */
                        if (pnl > 0m) wins += 1m; /* win */
                        pos.Qty = 0m; pos.AvgPrice = 0m; /* flat */
                        if (equity > peak) peak = equity; if (equity < trough) trough = equity; /* track */
                    }
                }
            }

            var res = new Result(); res.Trades = (int)trades; res.PnL = equity - 1000m; res.WinRate = trades > 0m ? wins / trades : 0m; res.MaxDrawdown = peak > 0m ? (peak - trough) / peak : 0m; return res; /* return */
        }
    }
}
