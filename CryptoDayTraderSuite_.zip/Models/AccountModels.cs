using System;

namespace CryptoDayTraderSuite.Models
{
    //public enum AccountMode { Paper, Live }

    /*public class AccountProfile
    {
        public string Id;
        public string Label;
        public string Service; 
        public string KeyEntryId; 
        public AccountMode Mode;
        public decimal RiskPerTradePct;
        public decimal MaxConcurrentTrades;
        public bool Enabled;
        public DateTime CreatedUtc;
        public DateTime UpdatedUtc;
    }
    */
    public class TradePlan
    {
        public string PlanId;
        public string Strategy;
        public string Symbol;
        public int GranMinutes;
        public int Direction;
        public decimal Entry;
        public decimal Stop;
        public decimal Target;
        public decimal Qty;
        public string Note;
        public DateTime CreatedUtc;
        public string AccountId;
    }

    public class ProjectionRow
    {
        public string Strategy;
        public string Symbol;
        public int GranMinutes;
        public double Expectancy;
        public double WinRate;
        public double AvgWin;
        public double AvgLoss;
        public double SharpeApprox;
        public int Samples;
    }
}