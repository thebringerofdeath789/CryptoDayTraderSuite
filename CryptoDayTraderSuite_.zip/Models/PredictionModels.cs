/* File: Models/PredictionModels.cs */
/* Author: Gregory King */
/* Date: 2025-08-10 */
/* Description: prediction and analytics models */
/* Types: DirectionPrediction, MagnitudePrediction, PredictionRecord, TradeRecord */

using System;

namespace CryptoDayTraderSuite.Models
{
    public enum MarketDirection { Down = -1, Flat = 0, Up = 1 } /* direction */

    public class DirectionPrediction
    {
        public string ProductId; /* symbol */
        public DateTime AtUtc; /* when predicted */
        public MarketDirection Direction; /* up/down/flat */
        public decimal Probability; /* probability of predicted direction 0..1 */
        public decimal HorizonMinutes; /* minutes ahead */
    }

    public class MagnitudePrediction
    {
        public string ProductId; /* symbol */
        public DateTime AtUtc; /* when predicted */
        public decimal ExpectedReturn; /* expected fractional return over horizon, signed */
        public decimal ExpectedVol; /* expected absolute move */
        public decimal HorizonMinutes; /* minutes */
    }

    public class PredictionRecord
    {
        public string ProductId; /* symbol */
        public DateTime AtUtc; /* timestamp */
        public decimal HorizonMinutes; /* horizon */
        public int Direction; /* -1/0/1 */
        public decimal Probability; /* prob */
        public decimal ExpectedReturn; /* mu */
        public decimal ExpectedVol; /* vol */
        public bool RealizedKnown; /* do we have outcome yet */
        public int RealizedDirection; /* -1/0/1 */
        public decimal RealizedReturn; /* realized */
    }

    public class TradeRecord
    {
        public string Exchange; /* exchange name */
        public string ProductId; /* symbol */
        public DateTime AtUtc; /* time */
        public string Strategy; /* strategy id */
        public string Side; /* buy/sell */
        public decimal Quantity; /* qty */
        public decimal Price; /* price */
        public decimal EstEdge; /* expected pnl fraction per unit */
        public bool Executed; /* executed flag */
        public decimal? FillPrice; /* fill price if any */
        public decimal? PnL; /* realized pnl if known */
        public string Notes; /* misc */
        public bool Enabled; /* governance toggle */
    }
}