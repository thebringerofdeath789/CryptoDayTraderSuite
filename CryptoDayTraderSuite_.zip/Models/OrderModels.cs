
using System;

namespace CryptoDayTraderSuite.Models
{
    public class OrderRequest
    {
        public string ProductId { get; set; } /* pair like BTC-USD or XBTUSD */
        public OrderSide Side { get; set; } /* side */
        public OrderType Type { get; set; } /* type */
        public decimal Quantity { get; set; } /* qty */
        public decimal? Price { get; set; } /* limit price */
        public TimeInForce Tif { get; set; } /* tif */
        public string ClientOrderId { get; set; } /* client id */
    }

    public class OrderResult
    {
        public string OrderId { get; set; } /* order id */
        public bool Accepted { get; set; } /* accepted */
        public bool Filled { get; set; } /* filled */
        public decimal FilledQty { get; set; } /* fill qty */
        public decimal AvgFillPrice { get; set; } /* avg price */
        public string Message { get; set; } /* message */
    }

    public class Position
    {
        public string ProductId { get; set; } /* product */
        public decimal Qty { get; set; } /* qty */
        public decimal AvgPrice { get; set; } /* avg */
        public decimal UnrealizedPnL(decimal mark) { return (mark - AvgPrice) * Qty; } /* calc */
    }
}
