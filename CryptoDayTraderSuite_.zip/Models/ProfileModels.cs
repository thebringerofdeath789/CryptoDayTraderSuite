using System;

namespace CryptoDayTraderSuite.Models
{
	[Serializable]
	public class AccountInfo
	{
		public string Id;                        /* unique id */
		public string Broker;                    /* e.g., Coinbase, Kraken */
		public string DisplayName;               /* friendly name for UI */
		public string DefaultQuote;              /* e.g., USD */
		public bool Paper;                       /* legacy flag */
		public decimal MaxOrderPct;              /* % equity per order */

		public DateTime CreatedUtc = DateTime.UtcNow; /* used by UI */
		public bool Enabled = true;              /* allow this account for auto mode */
		public DateTime UpdatedUtc = DateTime.UtcNow; // <-- Add this line

		/* unified mode as enum to satisfy comparisons like (acc.Mode == AccountMode.Paper) */
		public AccountMode Mode = AccountMode.Live;

		public decimal RiskPerTradePct = 1m;     /* risk per trade in % */
		public int MaxConcurrentTrades = 3;      /* cap concurrent trades */
		public string KeyEntryId;                /* selected key id: Broker|Label */

		/* aliases expected by some UI bits */
		public string Label                     /* alias for DisplayName */
		{
			get { return DisplayName; }
			set { DisplayName = value; }
		}

		public string Service                   /* alias for Broker */
		{
			get { return Broker; }
			set { Broker = value; }
		}
	}

	/* UI profile shape (stringy) with implicit conversions to/from AccountInfo */
	[Serializable]
	public class AccountProfile
	{
		public string Id;
		public string Label;
		public string Service;
		public string Mode;                      /* "Live"/"Paper" */
		public string DefaultQuote;
		public bool Paper;
		public decimal MaxOrderPct;
		public decimal RiskPerTradePct;
		public int MaxConcurrentTrades;
		public string KeyEntryId;
		public DateTime CreatedUtc;              /* UI reads this */
		public bool Enabled;                     // <-- Add this line
		public DateTime UpdatedUtc;              // <-- Add this line

		public static implicit operator AccountProfile(AccountInfo a)
		{
			if (a == null) return null;
			return new AccountProfile
			{
				Id = a.Id,
				Label = a.Label,
				Service = a.Service,
				Mode = a.Mode.ToString(),        /* enum -> string */
				DefaultQuote = a.DefaultQuote,
				Paper = a.Paper,
				MaxOrderPct = a.MaxOrderPct,
				RiskPerTradePct = a.RiskPerTradePct,
				MaxConcurrentTrades = a.MaxConcurrentTrades,
				KeyEntryId = a.KeyEntryId,
				CreatedUtc = a.CreatedUtc,
				Enabled = a.Enabled,
				UpdatedUtc = a.UpdatedUtc
			};
		}

		public static implicit operator AccountInfo(AccountProfile p)
		{
			if (p == null) return null;
			var info = new AccountInfo
			{
				Id = p.Id,
				DisplayName = p.Label,
				Broker = p.Service,
				DefaultQuote = p.DefaultQuote,
				Paper = p.Paper,
				MaxOrderPct = p.MaxOrderPct,
				RiskPerTradePct = p.RiskPerTradePct,
				MaxConcurrentTrades = p.MaxConcurrentTrades,
				KeyEntryId = p.KeyEntryId,
				CreatedUtc = p.CreatedUtc == default(DateTime) ? DateTime.UtcNow : p.CreatedUtc,
				Enabled = p.Enabled,
				UpdatedUtc = p.UpdatedUtc
			};
			/* map string -> enum safely */
			AccountMode m;
			info.Mode = Enum.TryParse(p.Mode ?? "Live", true, out m) ? m : AccountMode.Live;
			return info;
		}
	}

	/* helper payload for key secrets; some UI uses KeyInfo.Data.TryGetValue(...) */
	[Serializable]
	public class KeyData
	{
		public string ApiKey;
		public string Secret;
		public string Passphrase;

		/* normalize any alias to a canonical field name */
		private static string Canon(string key)
		{
			if (string.IsNullOrWhiteSpace(key)) return "";
			var k = key.Trim().ToLowerInvariant();
			if (k == "apikey" || k == "api_key" || k == "key") return "apikey";
			if (k == "secret" ) return "secret";
			if (k == "passphrase" || k == "phrase" || k == "pass") return "passphrase";
			return k;
		}

		/* map-like accessor used by existing UI code */
		public bool TryGetValue(string key, out string value)
		{
			value = null;
			switch (Canon(key))
			{
				case "apikey": value = ApiKey; break;
				case "secret": value = Secret; break;
				case "passphrase": value = Passphrase; break;
				default: return false;
			}
			return !string.IsNullOrEmpty(value);
		}

		/* requested by CoinbaseExchangeBroker.cs */
		public bool ContainsKey(string key)
		{
			string v; return TryGetValue(key, out v);
		}

		/* indexer so code can do data["apiKey"] */
		public string this[string key]
		{
			get
			{
				string v; TryGetValue(key, out v); return v;
			}
			set
			{
				switch (Canon(key))
				{
					case "apikey": ApiKey = value; break;
					case "secret": Secret = value; break;
					case "passphrase": Passphrase = value; break;
					default: /* ignore unknown keys */ break;
				}
			}
		}
	}


	[Serializable]
	public class KeyInfo
	{
		public string Broker;
		public string Label;
		public string ApiKey;
		public string Secret;
		public string Passphrase;
		public DateTime CreatedUtc = DateTime.UtcNow;
		public bool Enabled = true;

		/* aliases expected by UI */
		public string Service
		{
			get { return Broker; }
			set { Broker = value; }
		}

		public bool Active;                      /* UI toggles this */

		/* facade so code like key.Data["apiKey"] works (via TryGetValue above) */
		public KeyData Data
		{
			get { return new KeyData { ApiKey = ApiKey, Secret = Secret, Passphrase = Passphrase }; }
			set
			{
				if (value == null) return;
				ApiKey = value.ApiKey;
				Secret = value.Secret;
				Passphrase = value.Passphrase;
			}
		}
	}
}
