
CryptoDayTraderSuite prediction + planner patch

files added
- Models/PredictionModels.cs
- Strategy/FeatureExtractor.cs
- Strategy/PredictionEngine.cs
- Strategy/TradePlanner.cs
- Services/HistoryStore.cs
- UI/PlannerForm.cs
- UI/PlannerForm.Designer.cs
- MainForm_PredictionHook.cs (partial class for MainForm)
- UI/MainForm_PlannerButton.cs

hook up
1) include these files in your project (.csproj). if you use the classic csproj, add them under the existing ItemGroup with other .cs files.
2) in MainForm.cs ctor (after InitializeComponent()), call:
   UI.MainFormPlannerButton.AddPlannerButton(this);
3) after you load candles (e.g., in btnBacktest_Click or before a live/paper decision), call:
   await AnalyzeAndPlanAsync(product, candles);
4) to open the planner window manually, the Planner button opens it. it shows planned trades and recent predictions from %APPDATA%\CryptoDayTraderSuite\*.csv.
5) predictions and trades are saved to CSV with headers for later review.

learning
- the model adapts after you compute realized outcomes. to feed outcomes back, call:
  _predict.Learn(product, features, realizedDir, realizedReturn);
  where realizedReturn is (close_t+h / close_t - 1).
- you can schedule learning after each candle closes.

governance
- tweak Strategy/TradePlanner.cs GovernanceRules to block certain strategies, products, times of day, minimum edge, and losing streak cutoff.

ui
- PlannerForm is a simple grid UI that lets you toggle "Enabled" for planned trades and inspect predictions (last 500).

notes
- no external packages.
- this is not investment advice and cannot guarantee profit.
