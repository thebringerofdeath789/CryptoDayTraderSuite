using System.Threading.Tasks;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Util;

namespace CryptoDayTraderSuite.Brokers
{
    public class PaperBroker : IBroker
    {
        public string Service { get { return "paper"; } }
        public Task<(bool ok, string message)> PlaceOrderAsync(TradePlan plan)
        {
            Log.Info("paper fill " + plan.Symbol + " " + (plan.Direction>0?"LONG":"SHORT") + " qty=" + plan.Qty + " at " + plan.Entry + " account=" + plan.AccountId);
            return System.Threading.Tasks.Task.FromResult((true, "paper filled at " + plan.Entry));
        }
        public Task<(bool ok, string message)> CancelAllAsync(string symbol)
        {
            Log.Info("paper cancel all " + symbol);
            return System.Threading.Tasks.Task.FromResult((true, "paper canceled"));
        }
    }
}