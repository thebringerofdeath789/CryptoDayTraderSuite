using System.Threading.Tasks;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.Brokers
{
    public interface IBroker
    {
        string Service { get; }
        Task<(bool ok, string message)> PlaceOrderAsync(TradePlan plan);
        Task<(bool ok, string message)> CancelAllAsync(string symbol);
    }
}