using System;
using System.Reflection;
using System.Threading.Tasks;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Services;
using CryptoDayTraderSuite.Util;

namespace CryptoDayTraderSuite.Brokers
{
    public class CoinbaseExchangeBroker : IBroker
    {
        public string Service { get { return "coinbase-exchange"; } }

        public async Task<(bool ok, string message)> PlaceOrderAsync(TradePlan plan)
        {
            try
            {
                var asm = Assembly.GetExecutingAssembly();
                var t = asm.GetType("CryptoDayTraderSuite.Exchanges.CoinbaseExchangeClient", false);
                if (t == null) return (false, "coinbase client not found; add Exchanges/CoinbaseExchangeClient.cs");
                var cli = Activator.CreateInstance(t);

                var active = KeyRegistry.GetActiveId("coinbase-exchange");
                if (string.IsNullOrEmpty(active)) return (false, "no active coinbase-exchange key selected");
                var e = KeyRegistry.Get(active);
                string apiKey = KeyRegistry.Unprotect(e.Data.ContainsKey("ApiKey") ? e.Data["ApiKey"] : "");
                string apiSecret = KeyRegistry.Unprotect(e.Data.ContainsKey("ApiSecretBase64") ? e.Data["ApiSecretBase64"] : "");
                string passphrase = KeyRegistry.Unprotect(e.Data.ContainsKey("Passphrase") ? e.Data["Passphrase"] : "");

                TrySetProp(cli, "ApiKey", apiKey);
                TrySetProp(cli, "ApiSecretBase64", apiSecret);
                TrySetProp(cli, "Passphrase", passphrase);

                var m = t.GetMethod("PlaceLimitOrderAsync") ?? t.GetMethod("PlaceOrderAsync");
                if (m == null) return (false, "place order method not found on client");
                var side = plan.Direction > 0 ? "buy" : "sell";
                object task = null;
                var ps = m.GetParameters();
                if (ps.Length == 4) task = m.Invoke(cli, new object[] { plan.Symbol, side, (double)plan.Qty, (double)plan.Entry });
                else if (ps.Length == 5) task = m.Invoke(cli, new object[] { plan.Symbol, side, (double)plan.Qty, (double)plan.Entry, "GTC" });
                else return (false, "unsupported order signature");
                await AwaitDynamic(task);
                return (true, "sent");
            }
            catch (Exception ex)
            {
                Log.Error("coinbase place failed: " + ex.Message, ex);
                return (false, ex.Message);
            }
        }

        public async Task<(bool ok, string message)> CancelAllAsync(string symbol)
        {
            try
            {
                var asm = Assembly.GetExecutingAssembly();
                var t = asm.GetType("CryptoDayTraderSuite.Exchanges.CoinbaseExchangeClient", false);
                if (t == null) return (false, "coinbase client not found");
                var cli = Activator.CreateInstance(t);
                var m = t.GetMethod("CancelAllAsync");
                if (m == null) return (false, "cancel all method not found");
                object task = null;
                var ps = m.GetParameters();
                if (ps.Length == 1) task = m.Invoke(cli, new object[] { symbol });
                else task = m.Invoke(cli, new object[] { });
                await AwaitDynamic(task);
                return (true, "sent");
            }
            catch (Exception ex)
            {
                Log.Error("coinbase cancel failed: " + ex.Message, ex);
                return (false, ex.Message);
            }
        }

        private static async System.Threading.Tasks.Task AwaitDynamic(object task)
        {
            var t = task as System.Threading.Tasks.Task;
            if (t != null) await t;
        }

        private static void TrySetProp(object obj, string name, object value)
        {
            try
            {
                var p = obj.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
                if (p != null && p.CanWrite) p.SetValue(obj, value, null);
            }
            catch { }
        }
    }
}