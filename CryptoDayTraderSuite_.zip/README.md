# Crypto Day-Trading Suite

Author: Gregory King

## What this build includes

- Automatic Mode: ranks strategies (Donchian, VWAP Pullback, Range Reversion) by expectancy after fees and proposes trades sized by risk.
- Trade Modes:
  - USD growth (maximize USD expectancy)
  - Increase overall coins (maximize expectancy in a target coin like BTC) using a conversion router that supports coin-to-coin and coin-to-fiat pairs.
- Multi-Account Profiles: paper/live, service label, risk %, max concurrent, link to a Key entry.
- Keys Manager: manage API keys; supports Coinbase Exchange (API key/secret/passphrase) and Coinbase Advanced (key name + EC private key PEM) for storage; values are protected with Windows DPAPI per user.
- Brokers:
  - PaperBroker: instant simulated fills.
  - CoinbaseExchangeBroker: reflection adapter that calls your `Exchanges.CoinbaseExchangeClient` if present.
- Public Market Data: `Exchanges/CoinbasePublicClient` for products, candles (with 300-row chunking), and ticker mid.
- Strategy Helpers: signal generation for Donchian breakout, VWAP pullback, Range reversion.
- Risk Guards: helpers to block low-edge trades (fees vs target, spread vs ATR, volatility spikes).
- Logging: async rolling log files under `%LocalAppData%\CryptoDayTraderSuite\logs` + UI button and in-form mirroring.
- Tooltips: common control explanations on MainForm.

## Building

- Target: .NET Framework 4.8, C# 7.3
- Open `CryptoDayTraderSuite.sln` in Visual Studio 2022. Restore packages if prompted.
- Ensure references:
  - System.Windows.Forms.DataVisualization
  - System.Runtime.Serialization
  - System.Security

## Running

1. Start the app.
2. Click **Accounts** to create a Paper account (or Live if configured). Set risk %.
3. Click **Keys** to add Coinbase Exchange keys. Mark the one you want as **Active**.
4. Click **Auto** → choose the product, time-frame, lookback, equity.
5. Choose **Mode** (USD growth or Increase overall coins) and target asset (e.g., BTC).
6. **Scan** to see expectancy and stats. **Propose** to create trade plans. **Execute** to route per selected account.
   - Paper accounts use the PaperBroker.
   - Live accounts with service `coinbase-exchange` use the CoinbaseExchangeBroker.

## Notes on Reliability and Profitability

No strategy can guarantee profit. This suite focuses on edge that survives fees:
- Maker-first entries when feasible.
- ATR-scaled stops and targets.
- Regime-aware filters for range reversion.
- Expectancy measured after fees and converted to the objective denomination.
- Daily risk rails are recommended (add in StrategyEngine if you have it).

## UI Hooks

- `UI/MainForm_ExtraButtons.cs`: injects Accounts / Keys / Auto buttons into your MainForm without editing the designer.
- `UI/MainForm_LogHook.cs`: starts logging; a "Log" button opens the log folder; lines mirror into a `txtLog` textbox if you have it.
- `UI/MainForm_Tooltips.cs`: attaches helpful tooltips to common controls if present.

## Security

- Secrets are stored in `%AppData%\CryptoDayTraderSuite\keys.json` with DPAPI per-user protection.
- For cross-machine portability or AES passphrase profiles, you can add an export/import path (future enhancement).

## Extending

- Add more strategies by producing `List<Signal>` from your bar list and passing them through the `Measure` function.
- To add exchange support, implement an `IBroker` and (optionally) a public data client similar to `CoinbasePublicClient`.

Regenerated build: added UtilCompat, ensured references, fixed MainForm overrides, added menu, restored AutoModeForm.Designer.