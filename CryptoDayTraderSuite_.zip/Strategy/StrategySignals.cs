using System;
using System.Collections.Generic;
using System.Linq;

namespace CryptoDayTraderSuite.Strategy
{
    public class Bar
    {
        public DateTime T;
        public decimal O;
        public decimal H;
        public decimal L;
        public decimal C;
        public decimal V;
        public decimal Vwap; 
        public decimal Atr;  
    }

    public class Signal
    {
        public int Index;
        public string Kind;
        public string Name;
        public int Direction; 
        public decimal Stop;
        public decimal Target;
        public string Note;
    }

    public static class StrategySignals
    {
        public static List<Signal> DonchianBreakout(List<Bar> bars, int lookback, int pullbackExit, decimal atrMult, decimal minVolRatio)
        {
            var res = new List<Signal>();
            if (bars == null || bars.Count < lookback + 5) return res;

            var highs = new decimal[bars.Count];
            var lows  = new decimal[bars.Count];
            var vma20 = new decimal[bars.Count];
            decimal vSum = 0m;

            for (int i = 0; i < bars.Count; i++)
            {
                if (i == 0) vSum = bars[i].V;
                else vSum += bars[i].V - (i >= 20 ? bars[i-20].V : 0m);
                vma20[i] = (i >= 19) ? vSum / 20m : 0m;

                decimal hh = bars[Math.Max(0, i-lookback+1)].H;
                decimal ll = bars[Math.Max(0, i-lookback+1)].L;
                for (int k = Math.Max(0, i-lookback+1); k <= i; k++)
                {
                    if (bars[k].H > hh) hh = bars[k].H;
                    if (bars[k].L < ll) ll = bars[k].L;
                }
                highs[i] = hh; lows[i] = ll;
            }

            for (int i = lookback; i < bars.Count; i++)
            {
                var b = bars[i];
                var atr = b.Atr > 0m ? b.Atr : GuessAtr(bars, i, 14);
                var volOk = (i > 0 && vma20[i] > 0m) ? (b.V / vma20[i]) >= minVolRatio : true;

                if (b.C > highs[i-1] && volOk)
                {
                    var stop = b.C - atrMult * atr;
                    var target = b.C + atrMult * atr;
                    res.Add(new Signal { Index = i, Kind = "entry", Name = "Donchian", Direction = +1, Stop = stop, Target = target, Note = "breakout long" });
                }
                if (b.C < lows[i-1] && volOk)
                {
                    var stop = b.C + atrMult * atr;
                    var target = b.C - atrMult * atr;
                    res.Add(new Signal { Index = i, Kind = "entry", Name = "Donchian", Direction = -1, Stop = stop, Target = target, Note = "breakout short" });
                }
            }
            return res;
        }

        public static List<Signal> VWAPPullback(List<Bar> bars, int emaFast, decimal maxPullAtr, decimal resumeLookback)
        {
            var res = new List<Signal>();
            if (bars == null || bars.Count < Math.Max(emaFast+5, 30)) return res;
            var ema = Ema(bars.Select(x=>x.C), emaFast);
            for (int i = emaFast+1; i < bars.Count; i++)
            {
                var vw = bars[i].Vwap;
                var vwPrev = bars[i-1].Vwap;
                var atr = bars[i].Atr > 0m ? bars[i].Atr : GuessAtr(bars, i, 14);
                bool trendUp = vw > 0m && vwPrev > 0m && vw > vwPrev && bars[i].C > vw;

                if (trendUp)
                {
                    bool pulled = bars[i-1].C < ema[i-1] || bars[i-2].C < ema[i-2];
                    bool notTooDeep = vw - bars[i-1].C <= maxPullAtr * atr;
                    bool resume = bars[i].C > bars[i-1].H;
                    if (pulled && notTooDeep && resume)
                    {
                        var stop = bars[i].L - 1m * atr;
                        var target = bars[i].C + 2m * atr;
                        res.Add(new Signal { Index = i, Kind = "entry", Name = "VWAP-PB", Direction = +1, Stop = stop, Target = target, Note = "vwap up + ema pullback resume" });
                    }
                }
            }
            return res;
        }

        public static List<Signal> RangeReversion(List<Bar> bars, int bbLen, decimal bbStd, decimal widthPctile, int lookbackForPct)
        {
            var res = new List<Signal>();
            if (bars == null || bars.Count < Math.Max(bbLen+lookbackForPct, 40)) return res;
            var sma = Sma(bars.Select(x=>x.C), bbLen);
            var sd  = RollingStd(bars.Select(x=>x.C), bbLen);
            var width = new decimal[bars.Count];
            for (int i = 0; i < bars.Count; i++)
            {
                if (i >= bbLen-1)
                {
                    var upper = sma[i] + bbStd * sd[i];
                    var lower = sma[i] - bbStd * sd[i];
                    width[i] = upper - lower;
                }
            }
            for (int i = bbLen; i < bars.Count; i++)
            {
                int s = Math.Max(0, i - lookbackForPct);
                int n = i - s;
                if (n <= 5) continue;
                int below = 0;
                for (int k = s; k < i; k++) if (width[k] <= width[i]) below++;
                var pct = (decimal)below / (decimal)n;
                var atr = bars[i].Atr > 0m ? bars[i].Atr : GuessAtr(bars, i, 14);

                bool quiet = pct <= widthPctile;
                if (!quiet) continue;

                var mean = sma[i];
                var lowerBand = mean - bbStd * sd[i];
                var upperBand = mean + bbStd * sd[i];
                if (bars[i-1].L <= lowerBand && bars[i].C > bars[i-1].H)
                {
                    var stop = bars[i].L - 1m * atr;
                    var target = mean;
                    res.Add(new Signal { Index = i, Kind = "entry", Name = "RangeRV", Direction = +1, Stop = stop, Target = target, Note = "quiet regime fade up" });
                }
                if (bars[i-1].H >= upperBand && bars[i].C < bars[i-1].L)
                {
                    var stop = bars[i].H + 1m * atr;
                    var target = mean;
                    res.Add(new Signal { Index = i, Kind = "entry", Name = "RangeRV", Direction = -1, Stop = stop, Target = target, Note = "quiet regime fade down" });
                }
            }
            return res;
        }

        public static decimal[] Sma(IEnumerable<decimal> seq, int len)
        {
            var a = new List<decimal>(seq);
            var res = new decimal[a.Count];
            decimal sum = 0m;
            for (int i = 0; i < a.Count; i++)
            {
                sum += a[i];
                if (i >= len) sum -= a[i-len];
                res[i] = i >= len-1 ? sum / len : 0m;
            }
            return res;
        }

        public static decimal[] Ema(IEnumerable<decimal> seq, int len)
        {
            var a = new List<decimal>(seq);
            var res = new decimal[a.Count];
            if (a.Count == 0) return res;
            decimal k = 2m / (len + 1m);
            decimal ema = a[0];
            for (int i = 0; i < a.Count; i++)
            {
                ema = i == 0 ? a[i] : (a[i] - ema) * k + ema;
                res[i] = ema;
            }
            return res;
        }

        public static decimal[] RollingStd(IEnumerable<decimal> seq, int len)
        {
            var a = new List<decimal>(seq);
            var res = new decimal[a.Count];
            decimal sum = 0m, sum2 = 0m;
            for (int i = 0; i < a.Count; i++)
            {
                var x = a[i];
                sum += x;
                sum2 += x * x;
                if (i >= len)
                {
                    var y = a[i-len];
                    sum -= y;
                    sum2 -= y * y;
                }
                if (i >= len-1)
                {
                    var mean = sum / len;
                    var varx = (sum2 / len) - (mean * mean);
                    res[i] = varx > 0m ? (decimal)System.Math.Sqrt((double)varx) : 0m;
                }
            }
            return res;
        }

        public static decimal GuessAtr(List<Bar> bars, int i, int n)
        {
            decimal sum = 0m; int cnt = 0;
            int s = Math.Max(1, i - n + 1);
            for (int k = s; k <= i; k++)
            {
                var tr = Math.Max(bars[k].H - bars[k].L, Math.Max(Math.Abs(bars[k].H - bars[k-1].C), Math.Abs(bars[k].L - bars[k-1].C)));
                sum += tr; cnt++;
            }
            return cnt > 0 ? sum / cnt : 0m;
        }
    }
}