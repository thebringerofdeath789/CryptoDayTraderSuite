using System;
using System.Collections.Generic;
using System.Linq;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Exchanges;

namespace CryptoDayTraderSuite.Strategy
{
    public static class AutoPlanner
    {
        public static List<ProjectionRow> Project(string productId, int granMinutes, int lookbackDays, decimal takerFeeRate, decimal makerFeeRate)
        {
            var pub = new CoinbasePublicClient();
            var end = DateTime.UtcNow;
            var start = end.AddDays(-lookbackDays);
            var rows = pub.GetCandles(productId, granMinutes * 60, start, end);
            var bars = new List<Bar>();
            foreach (var r in rows) bars.Add(new Bar { T = r.TimeUtc, O = r.Open, H = r.High, L = r.Low, C = r.Close, V = r.Volume });

            ApplyAtr(bars, 14);
            ApplyVwap(bars, 20);

            var results = new List<ProjectionRow>();

            var don = StrategySignals.DonchianBreakout(bars, 20, 10, 2.0m, 1.2m);
            var mDon = Measure(bars, don, takerFeeRate, makerFeeRate);
            mDon.Strategy = "Donchian 20/ATR2"; mDon.Symbol = productId; mDon.GranMinutes = granMinutes; results.Add(mDon);

            var pb = StrategySignals.VWAPPullback(bars, 20, 1.5m, 3m);
            var mPb = Measure(bars, pb, takerFeeRate, makerFeeRate);
            mPb.Strategy = "VWAP Pullback 20/1.5"; mPb.Symbol = productId; mPb.GranMinutes = granMinutes; results.Add(mPb);

            var rv = StrategySignals.RangeReversion(bars, 20, 2.0m, 0.15m, 240);
            var mRv = Measure(bars, rv, takerFeeRate, makerFeeRate);
            mRv.Strategy = "Range Reversion 20/2 @15%"; mRv.Symbol = productId; mRv.GranMinutes = granMinutes; results.Add(mRv);

            results.Sort((a,b) => b.Expectancy.CompareTo(a.Expectancy));
            return results;
        }

        public static List<TradePlan> Propose(string accountId, string productId, int granMinutes, decimal equity, decimal riskPct, List<ProjectionRow> ranking)
        {
            var plans = new List<TradePlan>();
            var pub = new CoinbasePublicClient();
            var end = DateTime.UtcNow;
            var start = end.AddHours(-12);
            var rows = pub.GetCandles(productId, granMinutes * 60, start, end);
            if (rows.Count < 30) return plans;
            var last = rows[rows.Count - 1];
            decimal price = last.Close;

            decimal atr = 0m;
            for (int i = Math.Max(1, rows.Count - 14); i < rows.Count; i++)
            {
                var tr = Math.Max(rows[i].High - rows[i].Low, Math.Max(Math.Abs(rows[i].High - rows[i-1].Close), Math.Abs(rows[i].Low - rows[i-1].Close)));
                atr += tr;
            }
            atr = atr / 14m;
            if (atr <= 0m) return plans;

            decimal riskCash = equity * (riskPct / 100m);
            decimal qty = riskCash / atr;
            if (qty <= 0m) return plans;

            int take = Math.Min(2, ranking.Count);
            for (int i = 0; i < take; i++)
            {
                var r = ranking[i];
                int dir = last.Close >= rows[rows.Count-2].Close ? +1 : -1;
                decimal entry = price;
                decimal stop = dir > 0 ? price - atr : price + atr;
                decimal target = dir > 0 ? price + 2m * atr : price - 2m * atr;
                plans.Add(new TradePlan
                {
                    PlanId = Guid.NewGuid().ToString(),
                    Strategy = r.Strategy,
                    Symbol = productId,
                    GranMinutes = granMinutes,
                    Direction = dir,
                    Entry = entry,
                    Stop = stop,
                    Target = target,
                    Qty = Math.Round(qty, 6),
                    Note = "auto",
                    CreatedUtc = DateTime.UtcNow,
                    AccountId = accountId
                });
            }
            return plans;
        }

        private static ProjectionRow Measure(List<Bar> bars, List<Signal> signals, decimal takerFee, decimal makerFee)
        {
            int wins = 0, losses = 0;
            double sumWin = 0, sumLoss = 0;
            double pnlSum = 0, pnlSq = 0;
            int cnt = 0;
            foreach (var s in signals)
            {
                if (s.Index + 5 >= bars.Count) continue;
                var entry = bars[s.Index].C;
                var stop = s.Stop;
                var target = s.Target;
                var fee = (double)(takerFee * entry) * 2.0;
                bool hit = false;
                for (int i = s.Index + 1; i < Math.Min(bars.Count, s.Index + 11); i++)
                {
                    var b = bars[i];
                    if (s.Direction > 0)
                    {
                        if (b.L <= stop) { losses++; var pnl = (double)(stop - entry) - fee; sumLoss += -pnl; pnlSum += pnl; pnlSq += pnl * pnl; cnt++; hit = true; break; }
                        if (b.H >= target) { wins++; var pnl = (double)(target - entry) - fee; sumWin += pnl; pnlSum += pnl; pnlSq += pnl * pnl; cnt++; hit = true; break; }
                    }
                    else
                    {
                        if (b.H >= stop) { losses++; var pnl = (double)(entry - stop) - fee; sumLoss += -pnl; pnlSum += pnl; pnlSq += pnl * pnl; cnt++; hit = true; break; }
                        if (b.L <= target) { wins++; var pnl = (double)(entry - target) - fee; sumWin += pnl; pnlSum += pnl; pnlSq += pnl * pnl; cnt++; hit = true; break; }
                    }
                }
                if (!hit)
                {
                    if (s.Direction > 0)
                    {
                        var target1r = entry + (entry - stop);
                        var pnl = (double)(target1r - entry) - fee;
                        wins++; sumWin += pnl; pnlSum += pnl; pnlSq += pnl * pnl; cnt++;
                    }
                    else
                    {
                        var target1r = entry - (stop - entry);
                        var pnl = (double)(entry - target1r) - fee;
                        wins++; sumWin += pnl; pnlSum += pnl; pnlSq += pnl * pnl; cnt++;
                    }
                }
            }
            var row = new ProjectionRow();
            row.Samples = cnt;
            row.WinRate = cnt > 0 ? (double)wins / (double)cnt : 0.0;
            row.AvgWin = wins > 0 ? sumWin / wins : 0.0;
            row.AvgLoss = losses > 0 ? sumLoss / losses : 0.0;
            row.Expectancy = cnt > 0 ? pnlSum / cnt : 0.0;
            var mean = cnt > 0 ? pnlSum / cnt : 0.0;
            var varx = cnt > 0 ? (pnlSq / cnt) - (mean * mean) : 0.0;
            var sd = varx > 0 ? Math.Sqrt(varx) : 0.0;
            row.SharpeApprox = sd > 1e-9 ? mean / sd : 0.0;
            return row;
        }

        private static void ApplyAtr(List<Bar> bars, int n)
        {
            for (int i = 1; i < bars.Count; i++)
            {
                decimal sum = 0m; int cnt = 0;
                int s = Math.Max(1, i - n + 1);
                for (int k = s; k <= i; k++)
                {
                    var tr = Math.Max(bars[k].H - bars[k].L, Math.Max(Math.Abs(bars[k].H - bars[k-1].C), Math.Abs(bars[k].L - bars[k-1].C)));
                    sum += tr; cnt++;
                }
                bars[i].Atr = cnt > 0 ? sum / cnt : 0m;
            }
        }

        private static void ApplyVwap(List<Bar> bars, int n)
        {
            decimal pv = 0m, vv = 0m;
            for (int i = 0; i < bars.Count; i++)
            {
                var tp = (bars[i].H + bars[i].L + bars[i].C) / 3m;
                pv += tp * bars[i].V;
                vv += bars[i].V;
                bars[i].Vwap = vv > 0m ? pv / vv : bars[i].C;
                if (i % n == 0) { pv = 0m; vv = 0m; }
            }
        }
    }
}