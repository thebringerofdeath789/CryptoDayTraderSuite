namespace CryptoDayTraderSuite.Strategy
{
    public static class RiskGuards
    {
        public static bool FeesKillEdge(decimal targetTicks, decimal tickValue, decimal qty, decimal makerFee, decimal takerFee, bool takerEntry)
        {
            var feeRate = takerEntry ? takerFee : makerFee;
            var gross = targetTicks * tickValue * qty;
            if (gross <= 0m) return true;
            var fees = feeRate * (tickValue * qty) * 2m;
            var ratio = fees / gross;
            return ratio >= 0.25m;
        }

        public static bool SpreadTooWide(decimal spread, decimal atr, decimal maxSpreadToAtr)
        {
            if (atr <= 0m) return false;
            var r = spread / atr;
            return r > maxSpreadToAtr;
        }

        public static bool VolatilityShock(decimal atrNow, decimal atrMedian, decimal spikeFactor)
        {
            if (atrMedian <= 0m) return false;
            return atrNow >= spikeFactor * atrMedian;
        }
    }
}