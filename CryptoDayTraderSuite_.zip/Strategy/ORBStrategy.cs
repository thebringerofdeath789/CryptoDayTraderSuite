
using System;
using System.Collections.Generic;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.Strategy
{
    public class ORBStrategy
    {
        public TimeSpan OpeningRange = TimeSpan.FromMinutes(15); /* default 15m */
        public decimal BufferATRMultiples = 0.25m; /* enter buffer */
        public decimal StopATRMultiples = 0.75m; /* stop */
        public decimal TakeProfitATRMultiples = 1.5m; /* tp */
        public int AtrPeriod = 14; /* atr */

        public bool TrySignal(List<Candle> dayCandles, out OrderSide side, out decimal entry, out decimal stop, out decimal takeProfit)
        {
            side = OrderSide.Buy; entry = stop = takeProfit = 0m; /* init */
            if (dayCandles == null || dayCandles.Count == 0) return false; /* no data */
            var atr = Indicators.ATR(dayCandles, AtrPeriod); if (atr <= 0m) return false; /* need atr */
            /* compute opening range over first N minutes */
            var start = dayCandles[0].Time.Date.AddHours(0); /* day start utc */
            var orHigh = decimal.MinValue; var orLow = decimal.MaxValue; /* range */
            var cutoff = dayCandles[0].Time.Date.Add(OpeningRange); /* end */
            foreach (var c in dayCandles) { if (c.Time - dayCandles[0].Time <= OpeningRange) { if (c.High > orHigh) orHigh = c.High; if (c.Low < orLow) orLow = c.Low; } } /* compute */
            if (orHigh <= 0m || orLow <= 0m || orHigh <= orLow) return false; /* invalid */
            /* breakout check on the most recent candle */
            var last = dayCandles[dayCandles.Count - 1]; /* last */
            if (last.Close > orHigh + BufferATRMultiples * atr)
            {
                side = OrderSide.Buy; entry = last.Close; stop = last.Close - StopATRMultiples * atr; takeProfit = last.Close + TakeProfitATRMultiples * atr; return true; /* long */
            }
            if (last.Close < orLow - BufferATRMultiples * atr)
            {
                side = OrderSide.Sell; entry = last.Close; stop = last.Close + StopATRMultiples * atr; takeProfit = last.Close - TakeProfitATRMultiples * atr; return true; /* short */
            }
            return false; /* no signal */
        }
    }
}
