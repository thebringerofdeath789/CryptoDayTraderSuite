
using System;
using System.Collections.Generic;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.Strategy
{
    public class VWAPTrendStrategy
    {
        public int LookbackMinutes = 120; /* last 2h */
        public decimal PullbackMultipleATR = 0.5m; /* pullback depth */
        public int AtrPeriod = 14; /* atr */

        public bool TrySignal(List<Candle> intraday, out OrderSide side)
        {
            side = OrderSide.Buy; /* default */
            if (intraday == null || intraday.Count < AtrPeriod + 2) return false; /* need data */
            var vwap = Indicators.VWAP(intraday); /* vwap */
            var atr = Indicators.ATR(intraday, AtrPeriod); if (atr <= 0m) return false; /* atr */
            var last = intraday[intraday.Count - 1]; /* last */
            /* trend criteria */
            var upTrend = last.Close > vwap && intraday[intraday.Count - 2].Close > vwap; /* above vwap */
            var downTrend = last.Close < vwap && intraday[intraday.Count - 2].Close < vwap; /* below vwap */
            if (upTrend) { side = OrderSide.Buy; return true; } /* buy */
            if (downTrend) { side = OrderSide.Sell; return true; } /* sell */
            return false; /* no signal */
        }
    }
}
