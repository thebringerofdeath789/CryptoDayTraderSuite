
using System;
using System.Collections.Generic;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.Strategy
{
    public static class Indicators
    {
        public static decimal ATR(List<Candle> candles, int period)
        {
            /* average true range */
            if (candles.Count < period + 1) return 0m; /* need history */
            decimal sum = 0m; for (int i = 1; i <= period; i++)
            {
                var c = candles[candles.Count - i]; var p = candles[candles.Count - i - 1]; /* current prev */
                var tr = Math.Max((double)(c.High - c.Low), Math.Max(Math.Abs((double)(c.High - p.Close)), Math.Abs((double)(c.Low - p.Close)))); /* tr */
                sum += (decimal)tr; /* sum */
            }
            return sum / period; /* atr */
        }

        public static decimal VWAP(List<Candle> intraday)
        {
            /* session vwap for provided slice */
            decimal pv = 0m; decimal v = 0m; foreach (var c in intraday) { pv += c.Close * c.Volume; v += c.Volume; } /* sum */
            if (v <= 0m) return 0m; return pv / v; /* vwap */
        }

        public static decimal SMA(List<Candle> candles, int period)
        {
            if (candles.Count < period) return 0m; /* need history */
            decimal sum = 0m; for (int i = candles.Count - period; i < candles.Count; i++) sum += candles[i].Close; /* sum */
            return sum / period; /* sma */
        }
    }
}
