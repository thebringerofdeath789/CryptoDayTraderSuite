
using System;
using System.Collections.Generic;
using System.Globalization;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.Strategy
{
    public class StrategyEngine
    {
        public StrategyKind Active { get; set; } /* active strategy */
        public ORBStrategy Orb { get; private set; } = new ORBStrategy(); /* orb */
        public VWAPTrendStrategy VwapTrend { get; private set; } = new VWAPTrendStrategy(); /* vwap */

        public OrderRequest Evaluate(string productId, List<Candle> candles, FeeSchedule fees, decimal equityUsd, decimal riskFraction, decimal price, out CostBreakdown costs)
        {
            /* choose strategy */
            costs = new CostBreakdown(); /* init */
            OrderSide side; decimal entry, stop, tp; /* out */
            var signal = false; /* flag */
            if (Active == StrategyKind.ORB) signal = Orb.TrySignal(candles, out side, out entry, out stop, out tp); /* orb */
            else { signal = VwapTrend.TrySignal(candles, out side); entry = price; stop = side == OrderSide.Buy ? price * 0.995m : price * 1.005m; tp = side == OrderSide.Buy ? price * 1.01m : price * 0.99m; } /* vwap fallback */

            if (!signal) return null; /* no trade */

            /* compute costs */
            var feeRate = fees.TakerRate; /* assume taker for entry */
            costs.FeeRateUsed = feeRate; /* set */
            /* estimate spread from bid ask will be filled in UI layer, default 0.0005 = 5 bps */
            costs.EstimatedSpreadRate = 0.0005m; /* spread */
            costs.TotalRoundTripRate = feeRate + fees.MakerRate + costs.EstimatedSpreadRate; /* approx */

            /* risk sizing */
            var riskPerTrade = equityUsd * riskFraction; /* $ risk */
            var stopDistance = Math.Abs(entry - stop); if (stopDistance <= 0m) return null; /* guard */
            var qty = riskPerTrade / stopDistance; /* qty */
            qty = Math.Round(qty, 6); if (qty <= 0m) return null; /* round */

            return new OrderRequest { ProductId = productId, Side = side, Type = OrderType.Market, Quantity = qty, Tif = TimeInForce.GTC, Price = null, ClientOrderId = "cdts-" + Guid.NewGuid().ToString("N") }; /* order */
        }
    }
}
