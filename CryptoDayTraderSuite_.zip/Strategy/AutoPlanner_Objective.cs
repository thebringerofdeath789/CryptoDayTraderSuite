using System.Collections.Generic;
using System.Linq;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Services;

namespace CryptoDayTraderSuite.Strategy
{
    public static class AutoPlannerEx
    {
        public static System.Collections.Generic.List<ProjectionRow> ProjectWithObjective(string productId, int granMinutes, int lookbackDays, decimal takerFeeRate, decimal makerFeeRate, TradeObjective objective, string targetAsset)
        {
            var rows = AutoPlanner.Project(productId, granMinutes, lookbackDays, takerFeeRate, makerFeeRate);
            var router = new RateRouter();
            foreach (var r in rows)
            {
                r.Expectancy = ObjectiveScorer.ToObjectiveUnits(productId, r.Expectancy, objective, targetAsset, router);
            }
            return new System.Collections.Generic.List<ProjectionRow>(rows.OrderByDescending(x => x.Expectancy));
        }
    }
}