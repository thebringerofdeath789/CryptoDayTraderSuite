
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CryptoDayTraderSuite")]
[assembly: AssemblyDescription("WinForms day trading suite with Coinbase, Kraken, Bitstamp integration")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("G Trading Tools")]
[assembly: AssemblyProduct("CryptoDayTraderSuite")] 
[assembly: AssemblyCopyright("Copyright © 2025")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("e3e25f3d-4c6a-4b44-b0d7-1a5dbb9c4a90")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
