/* File: Exchanges/KrakenClient.cs */
/* Author: Gregory King */
/* Date: 2025-08-10 */
/* Description: Kraken REST client: minimal public data + private fees/balances + order place/cancel */
/* Functions: ctor, Name, NormalizeProduct, DenormalizeProduct, PrivatePostAsync, ListProductsAsync, GetCandlesAsync, GetTickerAsync, GetFeesAsync, GetBalancesAsync, PlaceOrderAsync, CancelOrderAsync */

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Util;

namespace CryptoDayTraderSuite.Exchanges
{
	public class KrakenClient : IExchangeClient
	{
		private readonly string _key; /* api key */
		private readonly string _secretBase64; /* secret base64 */
		private const string Rest = "https://api.kraken.com"; /* base */

		public KrakenClient(string key, string secretBase64) { _key = key; _secretBase64 = secretBase64; } /* ctor */

		public string Name { get { return "Kraken"; } } /* name */

		public string NormalizeProduct(string uiSymbol)
		{
			var s = uiSymbol.Replace("-", "").Replace("/", "").ToUpperInvariant(); /* compact */
			if (s == "BTCUSD" || s == "XBTUSD") return "XXBTZUSD"; /* xbt */
			if (s == "ETHUSD") return "XETHZUSD"; /* eth */
			if (s == "SOLUSD") return "SOLUSD"; /* sol */
			return s; /* fallback */
		}

		public string DenormalizeProduct(string apiSymbol)
		{
			if (apiSymbol == "XXBTZUSD") return "BTC/USD"; /* map */
			if (apiSymbol == "XETHZUSD") return "ETH/USD"; /* map */
			if (apiSymbol == "SOLUSD") return "SOL/USD"; /* map */
			return apiSymbol; /* fallback */
		}

		private async Task<string> PrivatePostAsync(string path, Dictionary<string, string> form)
		{
			/* kraken signing: API-Sign = HMAC-SHA512(URI path + SHA256(nonce + POST data)) using base64 secret */
			var nonce = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds().ToString(); /* nonce */
			form = form ?? new Dictionary<string, string>(); form["nonce"] = nonce; /* add */
			var post = new FormUrlEncodedContent(form); /* form */
			var postStr = await post.ReadAsStringAsync(); /* str */
			var shaData = SecurityUtil.Sha256(Encoding.UTF8.GetBytes(nonce + postStr)); /* sha */
			var toSign = Encoding.UTF8.GetBytes(path); /* path */
			var message = new byte[toSign.Length + shaData.Length]; Buffer.BlockCopy(toSign, 0, message, 0, toSign.Length); Buffer.BlockCopy(shaData, 0, message, toSign.Length, shaData.Length); /* concat */
			var sig = SecurityUtil.ComputeHmacSha512Base64(_secretBase64, message); /* sign */
			var url = Rest + path; using (var http = new HttpClient()) { http.DefaultRequestHeaders.Add("API-Key", _key); http.DefaultRequestHeaders.Add("API-Sign", sig); var resp = await http.PostAsync(url, post); var body = await resp.Content.ReadAsStringAsync(); if (!resp.IsSuccessStatusCode) throw new Exception(body); return body; } /* post */
		}

		public Task<List<string>> ListProductsAsync()
		{
			/* static subset; avoids pointless async warning */
			var list = new List<string> { "BTC/USD", "ETH/USD", "SOL/USD" }; /* simple */
			return Task.FromResult(list); /* return */
		}

		public async Task<List<Candle>> GetCandlesAsync(string productId, int minutes, DateTime startUtc, DateTime endUtc)
		{
			var pair = NormalizeProduct(productId); /* map */
			var interval = minutes; if (interval < 1) interval = 1; if (interval > 1440) interval = 1440; /* clamp */
			var url = Rest + "/0/public/OHLC?pair=" + pair + "&interval=" + interval; /* public */
			var json = await Util.HttpUtil.GetAsync(url); /* get */
			var dict = Util.JsonUtil.Deserialize<Dictionary<string, object>>(json); /* parse */
			var result = new List<Candle>(); /* list */
			if (dict.ContainsKey("result"))
			{
				var res = (Dictionary<string, object>)dict["result"]; /* res */
				foreach (var k in res.Keys)
				{
					if (k == "last") continue; /* skip */
					var arr = res[k] as object[]; if (arr == null)
					{
						var al = res[k] as System.Collections.ArrayList; if (al != null) arr = al.ToArray(); /* normalize */
					}
					if (arr == null) continue; /* cast */
					foreach (var o in arr)
					{
						var row = o as object[]; if (row == null || row.Length < 6) continue; /* check */
						var ts = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(Convert.ToInt64(row[0])); /* ts */
						if (ts < startUtc || ts > endUtc) continue; /* filter */
						result.Add(new Candle { Time = ts, Open = Convert.ToDecimal(row[1]), High = Convert.ToDecimal(row[2]), Low = Convert.ToDecimal(row[3]), Close = Convert.ToDecimal(row[4]), Volume = Convert.ToDecimal(row[6]) }); /* add */
					}
				}
			}
			result.Sort((a, b) => a.Time.CompareTo(b.Time)); /* sort */
			return result; /* return */
		}

		public async Task<Ticker> GetTickerAsync(string productId)
		{
			var pair = NormalizeProduct(productId); /* map */
			var url = Rest + "/0/public/Ticker?pair=" + pair; /* ticker */
			var json = await Util.HttpUtil.GetAsync(url); /* get */
			var dict = Util.JsonUtil.Deserialize<Dictionary<string, object>>(json); /* parse */
			var t = new Ticker { Time = DateTime.UtcNow }; /* init */
			if (dict.ContainsKey("result"))
			{
				var res = (Dictionary<string, object>)dict["result"]; /* res */
				foreach (var k in res.Keys)
				{
					var obj = (Dictionary<string, object>)res[k]; /* obj */
					var a = obj["a"] as object[]; var b = obj["b"] as object[]; var c = obj["c"] as object[]; /* arrays */
					t.Ask = a != null && a.Length > 0 ? Convert.ToDecimal(a[0]) : 0m; /* ask */
					t.Bid = b != null && b.Length > 0 ? Convert.ToDecimal(b[0]) : 0m; /* bid */
					t.Last = c != null && c.Length > 0 ? Convert.ToDecimal(c[0]) : 0m; /* last */
					break; /* first */
				}
			}
			return t; /* return */
		}

		public async Task<FeeSchedule> GetFeesAsync()
		{
			var body = new Dictionary<string, string>(); /* form */
			body["fee-info"] = "true"; /* include fees */
			var json = await PrivatePostAsync("/0/private/TradeVolume", body); /* call */
			var obj = Util.JsonUtil.Deserialize<Dictionary<string, object>>(json); /* parse */
			var maker = 0.0025m; var taker = 0.0040m; /* defaults per base tier */
			try
			{
				if (obj.ContainsKey("result"))
				{
					var res = (Dictionary<string, object>)obj["result"]; /* res */
					if (res.ContainsKey("fees_maker"))
					{
						var fm = (Dictionary<string, object>)res["fees_maker"]; /* dict */
						foreach (var key in fm.Keys) { var d = (Dictionary<string, object>)fm[key]; maker = Convert.ToDecimal(d["fee"].ToString()) / 100m; break; } /* parse % */
					}
					if (res.ContainsKey("fees"))
					{
						var ft = (Dictionary<string, object>)res["fees"]; /* dict */
						foreach (var key in ft.Keys) { var d = (Dictionary<string, object>)ft[key]; taker = Convert.ToDecimal(d["fee"].ToString()) / 100m; break; } /* parse % */
					}
				}
			}
			catch { }
			return new FeeSchedule { MakerRate = maker, TakerRate = taker, Notes = "from TradeVolume" }; /* return */
		}

		public async Task<Dictionary<string, decimal>> GetBalancesAsync()
		{
			var json = await PrivatePostAsync("/0/private/Balance", new Dictionary<string, string>()); /* call */
			var obj = Util.JsonUtil.Deserialize<Dictionary<string, object>>(json); /* parse */
			var d = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase); /* dict */
			if (obj.ContainsKey("result"))
			{
				var res = (Dictionary<string, object>)obj["result"]; /* res */
				foreach (var k in res.Keys) d[k] = Convert.ToDecimal(res[k].ToString()); /* add */
			}
			return d; /* return */
		}

		public async Task<OrderResult> PlaceOrderAsync(OrderRequest req)
		{
			var form = new Dictionary<string, string>(); /* form */
			form["pair"] = NormalizeProduct(req.ProductId); /* pair */
			form["type"] = req.Side == OrderSide.Buy ? "buy" : "sell"; /* side */
			form["ordertype"] = req.Type == OrderType.Market ? "market" : "limit"; /* type */
			form["volume"] = req.Quantity.ToString(CultureInfo.InvariantCulture); /* qty */
			if (req.Type == OrderType.Limit && req.Price.HasValue) form["price"] = req.Price.Value.ToString(CultureInfo.InvariantCulture); /* price */
			var json = await PrivatePostAsync("/0/private/AddOrder", form); /* post */
			var obj = Util.JsonUtil.Deserialize<Dictionary<string, object>>(json); /* parse */
			var accepted = !(obj.ContainsKey("error") && ((object[])obj["error"]).Length > 0); /* ok */
			var id = ""; if (obj.ContainsKey("result")) { var res = (Dictionary<string, object>)obj["result"]; var tx = res["txid"] as object[]; if (tx != null && tx.Length > 0) id = tx[0].ToString(); } /* id */
			return new OrderResult { OrderId = id, Accepted = accepted, Filled = false, FilledQty = 0m, AvgFillPrice = 0m, Message = accepted ? "accepted" : "error" }; /* return */
		}

		public async Task<bool> CancelOrderAsync(string orderId)
		{
			var form = new Dictionary<string, string>(); form["txid"] = orderId; /* id */
			var json = await PrivatePostAsync("/0/private/CancelOrder", form); /* post */
			return json.Contains("count"); /* naive */
		}
	}
}
