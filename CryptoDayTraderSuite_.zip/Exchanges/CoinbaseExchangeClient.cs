/* File: Exchanges/CoinbaseExchangeClient.cs */
/* fixes: 
   - chunk candles to obey 300 buckets per call
   - no DefaultRequestHeaders Content-Type (prevents 'Misused header name')
   - friendlier base64 secret error message
*/
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Util;

namespace CryptoDayTraderSuite.Exchanges
{
    public class CoinbaseExchangeClient : IExchangeClient
    {
        private readonly string _key;
        private readonly string _secretBase64;
        private readonly string _passphrase;
        private const string Rest = "https://api.exchange.coinbase.com";

        public CoinbaseExchangeClient(string key, string secretBase64, string passphrase) { _key = key; _secretBase64 = secretBase64; _passphrase = passphrase; }
        public string Name { get { return "Coinbase Exchange"; } }

        public string NormalizeProduct(string uiSymbol) { return uiSymbol.Replace("/", "-").ToUpperInvariant(); }
        public string DenormalizeProduct(string apiSymbol) { return apiSymbol.Replace("-", "/").ToUpperInvariant(); }

        private void SetAuthHeaders(string method, string path, string bodyJson)
        {
            HttpUtil.ClearDefaultHeaders();
            var ts = ((long)(DateTime.UtcNow - new DateTime(1970,1,1)).TotalSeconds).ToString(CultureInfo.InvariantCulture);
            var prehash = ts + method.ToUpperInvariant() + path + (bodyJson ?? "");
            var sig = SecurityUtil.ComputeHmacSha256Base64(_secretBase64, prehash);
            HttpUtil.AddDefaultHeader("CB-ACCESS-KEY", _key);
            HttpUtil.AddDefaultHeader("CB-ACCESS-SIGN", sig);
            HttpUtil.AddDefaultHeader("CB-ACCESS-TIMESTAMP", ts);
            HttpUtil.AddDefaultHeader("CB-ACCESS-PASSPHRASE", _passphrase);
            HttpUtil.AddDefaultHeader("User-Agent", "CryptoDayTraderSuite/1.0");
            HttpUtil.AddDefaultHeader("Accept", "application/json"); /* ok on default headers */
            /* do not set Content-Type here; POST adds it on HttpContent */
        }

        public async Task<List<string>> ListProductsAsync()
        {
            var url = Rest + "/products";
            var json = await HttpUtil.GetAsync(url);
            var list = JsonUtil.Deserialize<List<Dictionary<string, object>>>(json);
            var res = new List<string>();
            foreach (var p in list) if (p.ContainsKey("id")) res.Add(DenormalizeProduct(p["id"].ToString()));
            return res;
        }

        private static object[] ToObjArray(object o)
        {
            if (o is object[]) return (object[])o;
            var al = o as ArrayList; if (al != null) return al.ToArray();
            return null;
        }

        public async Task<Ticker> GetTickerAsync(string productId)
        {
            var api = NormalizeProduct(productId);
            var url = Rest + "/products/" + api + "/book?level=1";
            var json = await HttpUtil.GetAsync(url);
            var obj = JsonUtil.Deserialize<Dictionary<string, object>>(json);
            var bid = 0m; var ask = 0m;
            if (obj != null)
            {
                var bidsList = obj.ContainsKey("bids") ? ToObjArray(obj["bids"]) : null;
                var asksList = obj.ContainsKey("asks") ? ToObjArray(obj["asks"]) : null;
                if (bidsList != null && bidsList.Length > 0) { var bb = ToObjArray(bidsList[0]); if (bb != null && bb.Length > 0) bid = Convert.ToDecimal(bb[0]); }
                if (asksList != null && asksList.Length > 0) { var aa = ToObjArray(asksList[0]); if (aa != null && aa.Length > 0) ask = Convert.ToDecimal(aa[0]); }
            }
            var last = (bid > 0m && ask > 0m) ? (bid + ask)/2m : Math.Max(bid, ask);
            return new Ticker { Bid = bid, Ask = ask, Last = last, Time = DateTime.UtcNow };
        }

        public async Task<FeeSchedule> GetFeesAsync()
        {
            var path = "/fees";
            SetAuthHeaders("GET", path, "");
            var json = await HttpUtil.GetAsync(Rest + path);
            var obj = JsonUtil.Deserialize<Dictionary<string, object>>(json);
            var maker = obj.ContainsKey("maker_fee_rate") ? Convert.ToDecimal(obj["maker_fee_rate"].ToString()) : 0.0040m;
            var taker = obj.ContainsKey("taker_fee_rate") ? Convert.ToDecimal(obj["taker_fee_rate"].ToString()) : 0.0060m;
            return new FeeSchedule { MakerRate = maker, TakerRate = taker, Notes = "from /fees" };
        }

        public async Task<System.Collections.Generic.Dictionary<string, decimal>> GetBalancesAsync()
        {
            var path = "/accounts";
            SetAuthHeaders("GET", path, "");
            var json = await HttpUtil.GetAsync(Rest + path);
            var arr = JsonUtil.Deserialize<List<Dictionary<string, object>>>(json);
            var d = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase);
            foreach (var a in arr)
            {
                var currency = a.ContainsKey("currency") ? a["currency"].ToString() : "";
                if (string.IsNullOrEmpty(currency)) continue;
                decimal bal = 0m;
                if (a.ContainsKey("balance"))
                {
                    var b = a["balance"];
                    if (b is Dictionary<string, object>) bal = Convert.ToDecimal(((Dictionary<string, object>)b)["amount"].ToString());
                    else bal = Convert.ToDecimal(a["balance"].ToString());
                }
                d[currency] = bal;
            }
            return d;
        }

        public async Task<List<Candle>> GetCandlesAsync(string productId, int minutes, DateTime startUtc, DateTime endUtc)
        {
            var api = NormalizeProduct(productId);
            int gran = Math.Max(60, minutes * 60);
            var list = new List<Candle>();
            var t0 = startUtc;
            var maxSpanSec = 300 * gran;
            while (t0 < endUtc)
            {
                var t1 = t0.AddSeconds(maxSpanSec - 1);
                if (t1 > endUtc) t1 = endUtc;
                var start = ((long)(t0 - new DateTime(1970,1,1)).TotalSeconds).ToString(CultureInfo.InvariantCulture);
                var end = ((long)(t1 - new DateTime(1970,1,1)).TotalSeconds).ToString(CultureInfo.InvariantCulture);
                var url = Rest + "/products/" + api + "/candles?granularity=" + gran + "&start=" + start + "&end=" + end;
                var json = await HttpUtil.GetAsync(url);
                var arr = JsonUtil.Deserialize<List<List<object>>>(json);
                foreach (var c in arr)
                {
                    var ts = new DateTime(1970,1,1,0,0,0,DateTimeKind.Utc).AddSeconds(Convert.ToInt64(c[0]));
                    list.Add(new Candle { Time = ts, Low = Convert.ToDecimal(c[1]), High = Convert.ToDecimal(c[2]), Open = Convert.ToDecimal(c[3]), Close = Convert.ToDecimal(c[4]), Volume = Convert.ToDecimal(c[5]) });
                }
                t0 = t1.AddSeconds(gran);
            }
            list.Sort((a,b)=>a.Time.CompareTo(b.Time));
            return list;
        }

        public async Task<OrderResult> PlaceOrderAsync(OrderRequest req)
        {
            var path = "/orders";
            var obj = new Dictionary<string, object>();
            obj["product_id"] = NormalizeProduct(req.ProductId);
            obj["side"] = req.Side == OrderSide.Buy ? "buy" : "sell";
            if (req.Type == OrderType.Market) { obj["type"] = "market"; obj["size"] = req.Quantity.ToString(CultureInfo.InvariantCulture); }
            else { obj["type"] = "limit"; obj["size"] = req.Quantity.ToString(CultureInfo.InvariantCulture); obj["price"] = req.Price.Value.ToString(CultureInfo.InvariantCulture); obj["time_in_force"] = req.Tif.ToString(); }
            if (!string.IsNullOrEmpty(req.ClientOrderId)) obj["client_oid"] = req.ClientOrderId;
            var body = new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(obj);
            SetAuthHeaders("POST", path, body);
            var reqMsg = new HttpRequestMessage(HttpMethod.Post, Rest + path);
            reqMsg.Content = new StringContent(body, Encoding.UTF8, "application/json");
            var json = await HttpUtil.SendAsync(reqMsg);
            var resp = JsonUtil.Deserialize<Dictionary<string, object>>(json);
            var id = resp.ContainsKey("id") ? resp["id"].ToString() : "";
            var st = resp.ContainsKey("status") ? resp["status"].ToString() : "";
            return new OrderResult { OrderId = id, Accepted = true, Filled = st=="done"||st=="filled", FilledQty = 0m, AvgFillPrice = 0m, Message = st };
        }

        public async Task<bool> CancelOrderAsync(string orderId)
        {
            var path = "/orders/" + orderId;
            SetAuthHeaders("DELETE", path, "");
            try { await HttpUtil.DeleteAsync(Rest + path); return true; } catch { return false; }
        }
    }
}