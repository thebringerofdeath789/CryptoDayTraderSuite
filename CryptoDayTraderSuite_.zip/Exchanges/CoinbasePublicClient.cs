using System;
using System.Collections.Generic;
using CryptoDayTraderSuite.Util;

namespace CryptoDayTraderSuite.Exchanges
{
    public class CoinbasePublicClient
    {
        private const string Base = "https://api.exchange.coinbase.com";

        public List<string> GetProducts()
        {
            var url = Base + "/products";
            var json = UtilCompat.HttpGet(url, "application/json");
            var arr = UtilCompat.JsonDeserialize<List<Product>>(json) ?? new List<Product>();
            var res = new List<string>();
            foreach (var p in arr)
            {
                if (!string.IsNullOrEmpty(p.id)) res.Add(p.id);
            }
            res.Sort(StringComparer.OrdinalIgnoreCase);
            return res;
        }

        public List<CandleRow> GetCandles(string productId, int granSeconds, DateTime startUtc, DateTime endUtc)
        {
            var outRows = new List<CandleRow>();
            var step = TimeSpan.FromSeconds(granSeconds * 300);
            var t = startUtc;
            while (t < endUtc)
            {
                var t2 = t + step;
                if (t2 > endUtc) t2 = endUtc;
                var url = Base + "/products/" + Uri.EscapeDataString(productId) + "/candles?granularity=" + granSeconds
                        + "&start=" + Uri.EscapeDataString(t.ToString("o"))
                        + "&end=" + Uri.EscapeDataString(t2.ToString("o"));
                var json = UtilCompat.HttpGet(url, "application/json");
                var arr = UtilCompat.JsonDeserialize<List<List<double>>>(json) ?? new List<List<double>>();
                foreach (var row in arr)
                {
                    if (row.Count >= 6)
                    {
                        var ts = DateTimeOffset.FromUnixTimeSeconds((long)row[0]).UtcDateTime;
                        outRows.Add(new CandleRow { TimeUtc = ts, Low = (decimal)row[1], High = (decimal)row[2], Open = (decimal)row[3], Close = (decimal)row[4], Volume = (decimal)row[5] });
                    }
                }
                t = t2;
            }
            outRows.Sort((a,b) => a.TimeUtc.CompareTo(b.TimeUtc));
            return outRows;
        }

        public decimal GetTickerMid(string productId)
        {
            try
            {
                var url = Base + "/products/" + Uri.EscapeDataString(productId) + "/ticker";
                var json = UtilCompat.HttpGet(url, "application/json");
                var t = UtilCompat.JsonDeserialize<Ticker>(json);
                if (t == null) return 0m;
                decimal bid = 0m, ask = 0m, price = 0m;
                decimal.TryParse(t.bid ?? "0", out bid);
                decimal.TryParse(t.ask ?? "0", out ask);
                decimal.TryParse(t.price ?? "0", out price);
                if (bid > 0m && ask > 0m) return (bid + ask) / 2m;
                return price;
            }
            catch { return 0m; }
        }

        private class Product { public string id { get; set; } }
        private class Ticker { public string price { get; set; } public string bid { get; set; } public string ask { get; set; } }

        public class CandleRow
        {
            public DateTime TimeUtc;
            public decimal Open;
            public decimal High;
            public decimal Low;
            public decimal Close;
            public decimal Volume;
        }
    }
}