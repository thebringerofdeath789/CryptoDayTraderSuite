
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.Exchanges
{
    public interface IExchangeClient
    {
        string Name { get; } /* name */
        Task<List<string>> ListProductsAsync(); /* list tradable product ids */
        Task<List<Candle>> GetCandlesAsync(string productId, int minutes, DateTime startUtc, DateTime endUtc); /* candles */
        Task<Ticker> GetTickerAsync(string productId); /* ticker */
        Task<FeeSchedule> GetFeesAsync(); /* fee schedule */
        Task<Dictionary<string, decimal>> GetBalancesAsync(); /* balances */
        Task<OrderResult> PlaceOrderAsync(OrderRequest req); /* place */
        Task<bool> CancelOrderAsync(string orderId); /* cancel */
        string NormalizeProduct(string uiSymbol); /* normalize ui string to api pair */
        string DenormalizeProduct(string apiSymbol); /* back to ui */
    }
}
