using System.Collections.Generic;

namespace CryptoDayTraderSuite.Services
{
    public static class TimeFilters
    {
        private static readonly HashSet<int> _blockedHours = new HashSet<int>();

        public static void BlockHour(int hour) { if (hour >= 0 && hour <= 23) _blockedHours.Add(hour); }
        public static bool IsTradableHour(int hour) { return !(hour >= 0 && hour <= 23 && _blockedHours.Contains(hour)); }
        public static void Clear() { _blockedHours.Clear(); }
    }
}