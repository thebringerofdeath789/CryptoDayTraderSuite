/* file: Services/KeyRegistry.cs */
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Util;

namespace CryptoDayTraderSuite.Services
{
	public static class KeyRegistry
	{
		private static readonly object _lock = new object();
		private static List<KeyInfo> _items = new List<KeyInfo>();
		private static Dictionary<string, string> _activeByBroker = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

		private static string BaseDir
		{
			get
			{
				var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CryptoDayTraderSuite");
				if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
				return dir;
			}
		}
		private static string StorePath => Path.Combine(BaseDir, "keys.json");
		private static string ActivePath => Path.Combine(BaseDir, "keys.active.json");

		static KeyRegistry() { TryLoad(); TryLoadActive(); }

		private static void TryLoad()
		{
			try
			{
				if (File.Exists(StorePath))
				{
					var json = File.ReadAllText(StorePath, Encoding.UTF8);
					var list = UtilCompat.JsonDeserialize<List<KeyInfo>>(json) ?? new List<KeyInfo>();
					lock (_lock) _items = list;
				}
			}
			catch { }
		}

		private static void TryLoadActive()
		{
			try
			{
				if (File.Exists(ActivePath))
				{
					var json = File.ReadAllText(ActivePath, Encoding.UTF8);
					var map = UtilCompat.JsonDeserialize<Dictionary<string, string>>(json);
					_activeByBroker = map ?? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
				}
			}
			catch { _activeByBroker = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase); }
		}

		private static void Save()
		{
			try
			{
				List<KeyInfo> snap; lock (_lock) snap = new List<KeyInfo>(_items);
				File.WriteAllText(StorePath, UtilCompat.JsonSerialize(snap), Encoding.UTF8);
			}
			catch { }
		}

		private static void SaveActive()
		{
			try { File.WriteAllText(ActivePath, UtilCompat.JsonSerialize(_activeByBroker), Encoding.UTF8); }
			catch { }
		}

		/* basic listing */
		public static List<KeyInfo> GetAll() { lock (_lock) return new List<KeyInfo>(_items); }
		public static List<KeyInfo> List() => GetAll(); /* legacy alias */

		public static void ReplaceAll(List<KeyInfo> items)
		{
			lock (_lock) _items = items ?? new List<KeyInfo>();
			Save();
		}

		public static void Upsert(KeyInfo info)
		{
			if (info == null) return;
			lock (_lock)
			{
				var idx = _items.FindIndex(k =>
					string.Equals(k.Broker, info.Broker, StringComparison.OrdinalIgnoreCase) &&
					string.Equals(k.Label, info.Label, StringComparison.OrdinalIgnoreCase));
				if (idx >= 0) _items[idx] = info; else _items.Add(info);
			}
			Save();
		}

		public static void Remove(string broker, string label)
		{
			lock (_lock)
			{
				_items.RemoveAll(k =>
					string.Equals(k.Broker, broker, StringComparison.OrdinalIgnoreCase) &&
					string.Equals(k.Label, label, StringComparison.OrdinalIgnoreCase));
			}
			Save();
		}

		public static void Delete(string id)
		{
			string broker, label; KeyEntry.SplitId(id, out broker, out label);
			Remove(broker, label);
		}

		/* lookup */
		public static KeyInfo Get(string id)
		{
			string broker, label; KeyEntry.SplitId(id, out broker, out label);
			return Get(broker, label);
		}

		public static KeyInfo Get(string broker, string label)
		{
			lock (_lock)
			{
				return _items.Find(k =>
					string.Equals(k.Broker, broker, StringComparison.OrdinalIgnoreCase) &&
					string.Equals(k.Label, label, StringComparison.OrdinalIgnoreCase));
			}
		}

		/* active selection */
		public static void SetActive(string id)
		{
			string broker, label; KeyEntry.SplitId(id, out broker, out label);
			if (string.IsNullOrEmpty(broker)) return;
			_activeByBroker[broker] = id;
			SaveActive();
		}

		public static void SetActive(string broker, string label) => SetActive(KeyEntry.MakeId(broker, label));

		public static string GetActiveId()
		{
			foreach (var kv in _activeByBroker) if (!string.IsNullOrWhiteSpace(kv.Value)) return kv.Value;
			lock (_lock)
			{
				var any = _items.Find(k => k.Enabled);
				return any != null ? KeyEntry.MakeId(any.Broker, any.Label) : null;
			}
		}

		public static string GetActiveId(string broker)
		{
			if (string.IsNullOrEmpty(broker)) return GetActiveId();
			string id;
			if (_activeByBroker.TryGetValue(broker, out id) && !string.IsNullOrWhiteSpace(id)) return id;
			lock (_lock)
			{
				var any = _items.Find(k => string.Equals(k.Broker, broker, StringComparison.OrdinalIgnoreCase) && k.Enabled);
				return any != null ? KeyEntry.MakeId(any.Broker, any.Label) : null;
			}
		}

		/* local encryption wrappers (DPAPI) so UI/brokers can call KeyRegistry.Unprotect(...) */
		public static string Protect(string plain)
		{
			if (string.IsNullOrEmpty(plain)) return plain;
			try
			{
				var bytes = Encoding.UTF8.GetBytes(plain);
				var enc = ProtectedData.Protect(bytes, null, DataProtectionScope.CurrentUser);
				return Convert.ToBase64String(enc);
			}
			catch { return plain; }
		}

		public static string Unprotect(string cipher)
		{
			if (string.IsNullOrEmpty(cipher)) return cipher;
			try
			{
				var enc = Convert.FromBase64String(cipher);
				var dec = ProtectedData.Unprotect(enc, null, DataProtectionScope.CurrentUser);
				return Encoding.UTF8.GetString(dec);
			}
			catch { return cipher; }
		}
	}
}
