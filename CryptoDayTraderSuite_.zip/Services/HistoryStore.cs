/* File: Services/HistoryStore.cs */
/* Author: Gregory King */
/* Date: 2025-08-10 */
/* Description: csv store for predictions and trades in %appdata% */
/* Functions: SavePrediction, SaveTrade, LoadPredictions, LoadTrades */

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.Services
{
    public static class HistoryStore
    {
        private static string Root()
        {
            var app = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var dir = Path.Combine(app, "CryptoDayTraderSuite"); /* dir */
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
            return dir;
        }

        private static string PredPath() { return Path.Combine(Root(), "predictions.csv"); } /* path */
        private static string TradePath() { return Path.Combine(Root(), "trades.csv"); } /* path */

        public static void SavePrediction(PredictionRecord r)
        {
            bool writeHeader = !File.Exists(PredPath());
            using (var sw = new StreamWriter(PredPath(), true))
            {
                if (writeHeader) sw.WriteLine("product,at_utc,horizon_min,dir,prob,exp_ret,exp_vol,realized_known,realized_dir,realized_ret"); /* header */
                sw.WriteLine(string.Join(",", new string[] {
                    r.ProductId,
                    r.AtUtc.ToString("o"),
                    r.HorizonMinutes.ToString(CultureInfo.InvariantCulture),
                    r.Direction.ToString(CultureInfo.InvariantCulture),
                    r.Probability.ToString(CultureInfo.InvariantCulture),
                    r.ExpectedReturn.ToString(CultureInfo.InvariantCulture),
                    r.ExpectedVol.ToString(CultureInfo.InvariantCulture),
                    r.RealizedKnown ? "1" : "0",
                    r.RealizedDirection.ToString(CultureInfo.InvariantCulture),
                    r.RealizedReturn.ToString(CultureInfo.InvariantCulture)
                }));
            }
        }

        public static void SaveTrade(TradeRecord t)
        {
            bool writeHeader = !File.Exists(TradePath());
            using (var sw = new StreamWriter(TradePath(), true))
            {
                if (writeHeader) sw.WriteLine("exchange,product,at_utc,strategy,side,qty,price,edge,executed,fill_price,pnl,notes,enabled"); /* header */
                sw.WriteLine(string.Join(",", new string[] {
                    Esc(t.Exchange), Esc(t.ProductId), t.AtUtc.ToString("o"), Esc(t.Strategy), Esc(t.Side),
                    t.Quantity.ToString(CultureInfo.InvariantCulture),
                    t.Price.ToString(CultureInfo.InvariantCulture),
                    t.EstEdge.ToString(CultureInfo.InvariantCulture),
                    t.Executed ? "1":"0",
                    t.FillPrice.HasValue ? t.FillPrice.Value.ToString(CultureInfo.InvariantCulture) : "",
                    t.PnL.HasValue ? t.PnL.Value.ToString(CultureInfo.InvariantCulture) : "",
                    Esc(t.Notes),
                    t.Enabled ? "1":"0"
                }));
            }
        }

        public static List<PredictionRecord> LoadPredictions()
        {
            var list = new List<PredictionRecord>();
            var p = PredPath(); if (!File.Exists(p)) return list;
            using (var sr = new StreamReader(p))
            {
                string line = sr.ReadLine(); /* header */
                while ((line = sr.ReadLine()) != null)
                {
                    var sp = SplitCsv(line);
                    if (sp.Length < 10) continue;
                    var r = new PredictionRecord();
                    r.ProductId = sp[0];
                    r.AtUtc = DateTime.Parse(sp[1], null, DateTimeStyles.RoundtripKind);
                    r.HorizonMinutes = decimal.Parse(sp[2], CultureInfo.InvariantCulture);
                    r.Direction = int.Parse(sp[3], CultureInfo.InvariantCulture);
                    r.Probability = decimal.Parse(sp[4], CultureInfo.InvariantCulture);
                    r.ExpectedReturn = decimal.Parse(sp[5], CultureInfo.InvariantCulture);
                    r.ExpectedVol = decimal.Parse(sp[6], CultureInfo.InvariantCulture);
                    r.RealizedKnown = sp[7] == "1";
                    r.RealizedDirection = string.IsNullOrEmpty(sp[8]) ? 0 : int.Parse(sp[8], CultureInfo.InvariantCulture);
                    r.RealizedReturn = string.IsNullOrEmpty(sp[9]) ? 0m : decimal.Parse(sp[9], CultureInfo.InvariantCulture);
                    list.Add(r);
                }
            }
            return list;
        }

        public static List<TradeRecord> LoadTrades()
        {
            var list = new List<TradeRecord>();
            var p = TradePath(); if (!File.Exists(p)) return list;
            using (var sr = new StreamReader(p))
            {
                string line = sr.ReadLine(); /* header */
                while ((line = sr.ReadLine()) != null)
                {
                    var sp = SplitCsv(line);
                    if (sp.Length < 13) continue;
                    var t = new TradeRecord();
                    t.Exchange = Unesc(sp[0]); t.ProductId = Unesc(sp[1]);
                    t.AtUtc = DateTime.Parse(sp[2], null, DateTimeStyles.RoundtripKind);
                    t.Strategy = Unesc(sp[3]); t.Side = Unesc(sp[4]);
                    t.Quantity = decimal.Parse(sp[5], CultureInfo.InvariantCulture);
                    t.Price = decimal.Parse(sp[6], CultureInfo.InvariantCulture);
                    t.EstEdge = decimal.Parse(sp[7], CultureInfo.InvariantCulture);
                    t.Executed = sp[8] == "1";
                    t.FillPrice = string.IsNullOrEmpty(sp[9]) ? (decimal?)null : decimal.Parse(sp[9], CultureInfo.InvariantCulture);
                    t.PnL = string.IsNullOrEmpty(sp[10]) ? (decimal?)null : decimal.Parse(sp[10], CultureInfo.InvariantCulture);
                    t.Notes = Unesc(sp[11]);
                    t.Enabled = sp[12] == "1";
                    list.Add(t);
                }
            }
            return list;
        }

        private static string Esc(string s) { if (s == null) return ""; if (s.Contains(",") || s.Contains("\"")) return "\"" + s.Replace("\"","\"\"") + "\""; return s; } /* esc */
        private static string Unesc(string s) { s = s ?? ""; s = s.Trim(); if (s.StartsWith("\"") && s.EndsWith("\"")) s = s.Substring(1, s.Length - 2).Replace("\"\"","\""); return s; } /* unesc */

        private static string[] SplitCsv(string line)
        {
            var list = new System.Collections.Generic.List<string>();
            bool inq = false; var cur = new System.Text.StringBuilder();
            for (int i = 0; i < line.Length; i++)
            {
                var ch = line[i];
                if (inq)
                {
                    if (ch == '"' && i + 1 < line.Length && line[i + 1] == '"') { cur.Append('"'); i++; }
                    else if (ch == '"') { inq = false; }
                    else cur.Append(ch);
                }
                else
                {
                    if (ch == ',') { list.Add(cur.ToString()); cur.Clear(); }
                    else if (ch == '"') { inq = true; }
                    else cur.Append(ch);
                }
            }
            list.Add(cur.ToString());
            return list.ToArray();
        }
    }
}