/* file: Services/AccountRegistry.cs */
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Util;

namespace CryptoDayTraderSuite.Services
{
	public static class AccountRegistry
	{
		/* in-memory accounts list with simple persistence */
		private static readonly object _lock = new object(); /* sync */
		private static List<AccountInfo> _items = new List<AccountInfo>(); /* store */

		private static string StorePath
		{
			get
			{
				var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CryptoDayTraderSuite");
				if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
				return Path.Combine(dir, "accounts.json");
			}
		}

		static AccountRegistry() { TryLoad(); /* load at startup */ }

		private static void TryLoad()
		{
			try
			{
				if (File.Exists(StorePath))
				{
					var json = File.ReadAllText(StorePath, Encoding.UTF8); /* read */
					var list = UtilCompat.JsonDeserialize<List<AccountInfo>>(json) ?? new List<AccountInfo>(); /* parse */
					lock (_lock) _items = list; /* swap */
				}
			}
			catch
			{
				/* ignore corrupt file and start empty */
			}
		}

		private static void Save()
		{
			try
			{
				List<AccountInfo> snap;
				lock (_lock) snap = new List<AccountInfo>(_items); /* copy */
				var json = UtilCompat.JsonSerialize(snap); /* serialize */
				File.WriteAllText(StorePath, json, Encoding.UTF8); /* write */
			}
			catch
			{
				/* ignore write errors */
			}
		}

		public static List<AccountInfo> GetAll()
		{
			lock (_lock) return new List<AccountInfo>(_items); /* return copy */
		}

		public static void ReplaceAll(List<AccountInfo> items)
		{
			lock (_lock) _items = items ?? new List<AccountInfo>(); /* swap */
			Save(); /* persist */
		}

		public static void Upsert(AccountInfo info)
		{
			if (info == null) return; /* guard */
			lock (_lock)
			{
				var idx = _items.FindIndex(a => string.Equals(a.Id, info.Id, StringComparison.OrdinalIgnoreCase));
				if (idx >= 0) _items[idx] = info; else _items.Add(info); /* upsert */
			}
			Save(); /* persist */
		}

		public static void Remove(string id)
		{
			lock (_lock) _items.RemoveAll(a => string.Equals(a.Id, id, StringComparison.OrdinalIgnoreCase)); /* delete */
			Save(); /* persist */
		}
		/* alias used by some forms */
		public static System.Collections.Generic.List<CryptoDayTraderSuite.Models.AccountInfo> List()
		{
			return GetAll();
		}

		public static CryptoDayTraderSuite.Models.AccountInfo Get(string id)
		{
			lock (_lock) return _items.Find(a => string.Equals(a.Id, id, StringComparison.OrdinalIgnoreCase));
		}

		public static void Delete(string id)
		{
			Remove(id);
		}
		/* aliases used by some UI files */
	

	}
}
