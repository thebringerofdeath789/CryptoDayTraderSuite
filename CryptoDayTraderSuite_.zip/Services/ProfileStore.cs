using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using CryptoDayTraderSuite.Util;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.Services
{
    public class ProfileData
    {
        public List<AccountInfo> Accounts = new List<AccountInfo>();
        public List<KeyInfo> Keys = new List<KeyInfo>();
        public List<int> BlockedHours = new List<int>();
        public decimal DefaultRiskPct = 0.5m;
        public string QuoteFilter = "USD";
        public int DefaultGranMinutes = 15;
    }

    public static class ProfileStore
    {
        private const string Magic = "CDTPv1\0";

        public static void Export(string path, string passphrase)
        {
            var pd = new ProfileData();
            pd.Accounts = AccountRegistry.GetAll();
            pd.Keys = KeyRegistry.GetAll();
            for (int h=0; h<24; h++) if (!TimeFilters.IsTradableHour(h)) pd.BlockedHours.Add(h);

            var json = UtilCompat.JsonSerialize(pd);
            var bytes = Encoding.UTF8.GetBytes(json);
            var enc = Encrypt(bytes, passphrase);
            File.WriteAllBytes(path, enc);
        }

        public static void Import(string path, string passphrase)
        {
            var enc = File.ReadAllBytes(path);
            var plain = Decrypt(enc, passphrase);
            var json = Encoding.UTF8.GetString(plain);
            var pd = UtilCompat.JsonDeserialize<ProfileData>(json);
            if (pd == null) throw new Exception("invalid profile");

            AccountRegistry.ReplaceAll(pd.Accounts);
            KeyRegistry.ReplaceAll(pd.Keys);

            TimeFilters.Clear();
            foreach (var h in pd.BlockedHours) TimeFilters.BlockHour(h);
        }

        private static byte[] Encrypt(byte[] data, string pass)
        {
            var salt = new byte[16]; new RNGCryptoServiceProvider().GetBytes(salt);
            using (var r = new Rfc2898DeriveBytes(pass ?? "", salt, 100000))
            using (var aes = new AesManaged())
            {
                aes.Key = r.GetBytes(32);
                aes.GenerateIV();
                aes.Mode = CipherMode.CBC; aes.Padding = PaddingMode.PKCS7;
                using (var ms = new MemoryStream())
                {
                    var magic = Encoding.ASCII.GetBytes(Magic);
                    ms.Write(magic, 0, magic.Length);
                    ms.Write(salt, 0, salt.Length);
                    ms.Write(aes.IV, 0, aes.IV.Length);
                    using (var cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(data, 0, data.Length);
                        cs.FlushFinalBlock();
                    }
                    return ms.ToArray();
                }
            }
        }

        private static byte[] Decrypt(byte[] enc, string pass)
        {
            using (var ms = new MemoryStream(enc))
            {
                var magic = new byte[Magic.Length];
                if (ms.Read(magic, 0, magic.Length) != magic.Length) throw new Exception("bad profile");
                if (Encoding.ASCII.GetString(magic) != Magic) throw new Exception("bad header");
                var salt = new byte[16]; if (ms.Read(salt, 0, 16) != 16) throw new Exception("bad salt");
                var iv = new byte[16]; if (ms.Read(iv, 0, 16) != 16) throw new Exception("bad iv");
                using (var r = new Rfc2898DeriveBytes(pass ?? "", salt, 100000))
                using (var aes = new AesManaged())
                {
                    aes.Key = r.GetBytes(32);
                    aes.IV = iv; aes.Mode = CipherMode.CBC; aes.Padding = PaddingMode.PKCS7;
                    using (var cs = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read))
                    using (var outMs = new MemoryStream())
                    {
                        cs.CopyTo(outMs);
                        return outMs.ToArray();
                    }
                }
            }
        }
    }
}
