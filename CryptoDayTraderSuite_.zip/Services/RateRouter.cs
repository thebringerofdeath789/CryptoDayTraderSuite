using System;
using System.Collections.Generic;
using CryptoDayTraderSuite.Exchanges;

namespace CryptoDayTraderSuite.Services
{
    public class RateRouter
    {
        private readonly CoinbasePublicClient _pub = new CoinbasePublicClient();
        private readonly System.Collections.Generic.Dictionary<string, decimal> _mid = new System.Collections.Generic.Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase);

        private decimal Mid(string baseAsset, string quoteAsset)
        {
            var pid = baseAsset + "-" + quoteAsset;
            decimal v;
            if (_mid.TryGetValue(pid, out v)) return v;
            v = _pub.GetTickerMid(pid);
            if (v <= 0m) return 0m;
            _mid[pid] = v;
            return v;
        }

        public decimal Convert(string fromAsset, string toAsset, decimal amount)
        {
            if (string.Equals(fromAsset, toAsset, StringComparison.OrdinalIgnoreCase)) return amount;

            /* try direct, else reverse, else hop via USD or USDC or BTC */
            var d = Mid(fromAsset, toAsset);
            if (d > 0m) return amount * d;
            var r = Mid(toAsset, fromAsset);
            if (r > 0m) return amount / r;

            string[] hubs = new string[] { "USD", "USDC", "USDT", "BTC", "ETH" };
            foreach (var hub in hubs)
            {
                var a = Mid(fromAsset, hub);
                var b = Mid(hub, toAsset);
                if (a > 0m && b > 0m) return amount * a * b;
                var ar = Mid(hub, fromAsset);
                var br = Mid(toAsset, hub);
                if (ar > 0m && br > 0m) return amount / ar / br;
            }
            return 0m;
        }
    }
}