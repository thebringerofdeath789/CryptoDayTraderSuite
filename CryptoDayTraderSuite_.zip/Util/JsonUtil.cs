
using System;
using System.Web.Script.Serialization;

namespace CryptoDayTraderSuite.Util
{
    public static class JsonUtil
    {
        private static readonly JavaScriptSerializer _ser = new JavaScriptSerializer(); /* serializer */
        public static T Deserialize<T>(string json) { return _ser.Deserialize<T>(json); } /* parse */
    }
}
