
using System;
using System.Security.Cryptography;
using System.Text;

namespace CryptoDayTraderSuite.Util
{
    public static class KeyStore
    {
        public static string Protect(string plain)
        {
            /* protect with dpapi local machine scope */
            var bytes = Encoding.UTF8.GetBytes(plain ?? ""); /* to bytes */
            var enc = ProtectedData.Protect(bytes, null, DataProtectionScope.CurrentUser); /* protect */
            return Convert.ToBase64String(enc); /* to base64 */
        }

        public static string Unprotect(string base64)
        {
            try
            {
                var bytes = Convert.FromBase64String(base64 ?? ""); /* from base64 */
                var dec = ProtectedData.Unprotect(bytes, null, DataProtectionScope.CurrentUser); /* unprotect */
                return Encoding.UTF8.GetString(dec); /* to string */
            }
            catch { return ""; } /* fail safe */
        }
    }
}
