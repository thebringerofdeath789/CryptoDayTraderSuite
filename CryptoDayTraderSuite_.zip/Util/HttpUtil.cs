/* File: Util/HttpUtil.cs */
/* fixes: no Content-Type on DefaultRequestHeaders to avoid 'Misused header name' */
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace CryptoDayTraderSuite.Util
{
    public static class HttpUtil
    {
        private static readonly HttpClient _http = new HttpClient(); /* shared */

        public static void ClearDefaultHeaders()
        {
            _http.DefaultRequestHeaders.Clear();
        }

        public static void AddDefaultHeader(string name, string value)
        {
            _http.DefaultRequestHeaders.Remove(name);
            _http.DefaultRequestHeaders.Add(name, value);
        }

        public static async Task<string> GetAsync(string url)
        {
            var r = await _http.GetAsync(url);
            var body = await r.Content.ReadAsStringAsync();
            if (!r.IsSuccessStatusCode) throw new Exception("http error " + (int)r.StatusCode + " " + body);
            return body;
        }

        public static async Task<string> PostAsync(string url, HttpContent content)
        {
            var r = await _http.PostAsync(url, content);
            var body = await r.Content.ReadAsStringAsync();
            if (!r.IsSuccessStatusCode) throw new Exception("http error " + (int)r.StatusCode + " " + body);
            return body;
        }

        public static async Task<string> DeleteAsync(string url)
        {
            var r = await _http.DeleteAsync(url);
            var body = await r.Content.ReadAsStringAsync();
            if (!r.IsSuccessStatusCode) throw new Exception("http error " + (int)r.StatusCode + " " + body);
            return body;
        }

        public static async Task<string> SendAsync(HttpRequestMessage req)
        {
            var r = await _http.SendAsync(req);
            var body = await r.Content.ReadAsStringAsync();
            if (!r.IsSuccessStatusCode) throw new Exception("http error " + (int)r.StatusCode + " " + body);
            return body;
        }
    }
}