using System.Threading.Tasks;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.Brokers
{
    /// <summary>
    /// Broker interface for placing and managing orders.
    /// </summary>
    public interface IBroker
    {
        /// <summary>
        /// The service name (e.g., "coinbase-exchange").
        /// </summary>
        string Service { get; }

        /// <summary>
        /// Place an order asynchronously.
        /// </summary>
        /// <param name="plan">Trade plan to execute.</param>
        /// <returns>Tuple (ok, message) indicating success and details.</returns>
        Task<(bool ok, string message)> PlaceOrderAsync(TradePlan plan);

        /// <summary>
        /// Cancel all open orders for a symbol asynchronously.
        /// </summary>
        /// <param name="symbol">Symbol to cancel orders for.</param>
        /// <returns>Tuple (ok, message) indicating success and details.</returns>
        Task<(bool ok, string message)> CancelAllAsync(string symbol);
    }
}