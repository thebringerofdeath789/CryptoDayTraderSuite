using System;
using System.Collections.Generic;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.Backtest
{
    public class Backtester
    {
        public class Result
        {
            public int Trades { get; set; } /* trades */
            public decimal PnL { get; set; } /* pnl */
            public decimal MaxDrawdown { get; set; } /* mdd */
            public decimal WinRate { get; set; } /* win */
        }

        public static Result Run(List<Candle> candles, Func<List<Candle>, int, OrderRequest> signal, decimal feeRoundTripRate, decimal startingEquity = 1000m)
        {
            var pos = new Position { ProductId = "", Qty = 0m, AvgPrice = 0m };
            decimal equity = startingEquity, peak = equity, trough = equity, wins = 0m, trades = 0m;

            for (int i = 50; i < candles.Count; i++)
            {
                var req = signal(candles, i);

                if (req != null && pos.Qty == 0m)
                {
                    var price = candles[i].Close;
                    var qty = req.Quantity;
                    pos.Qty = req.Side == OrderSide.Buy ? qty : -qty;
                    pos.AvgPrice = price;
                    trades++;
                    equity -= Math.Abs(qty * price) * feeRoundTripRate / 2m;
                }
                else if (pos.Qty != 0m)
                {
                    if ((pos.Qty > 0m && req?.Side == OrderSide.Sell) || (pos.Qty < 0m && req?.Side == OrderSide.Buy))
                    {
                        var price = candles[i].Close;
                        var pnl = (price - pos.AvgPrice) * pos.Qty;
                        equity += pnl;
                        equity -= Math.Abs(pos.Qty * price) * feeRoundTripRate / 2m;
                        if (pnl > 0m) wins++;
                        pos.Qty = 0m;
                        pos.AvgPrice = 0m;
                        peak = Math.Max(peak, equity);
                        trough = Math.Min(trough, equity);
                    }
                }
            }

            return new Result
            {
                Trades = (int)trades,
                PnL = equity - startingEquity,
                WinRate = trades > 0m ? wins / trades : 0m,
                MaxDrawdown = peak > 0m ? (peak - trough) / peak : 0m
            };
        }
    }
}
