﻿/* File: MainForm.cs */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using CryptoDayTraderSuite.Exchanges;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Strategy;
using CryptoDayTraderSuite.Util;
using CryptoDayTraderSuite.UI;
using CryptoDayTraderSuite.Services;
using CryptoDayTraderSuite.Services.Messaging;
using CryptoDayTraderSuite.Services.Messaging.Events;

namespace CryptoDayTraderSuite
{
 public partial class MainForm : Form
 {
 /* Injected Dependencies */
 private AutoPlannerService _autoPlanner;
 private IExchangeProvider _exchangeProvider;
        private BacktestService _backtestService;
        private IEventBus _eventBus;
        private IAccountService _accountService;
        private IKeyService _keyService;
        private IProfileService _profileService;
        private IHistoryService _historyService;
        private ChromeSidecar _sidecar;
        private AIGovernor _governor;
        private IRateRouter _rateRouter;

        /* State */
        private IExchangeClient _client = null;
        private StrategyEngine _engine = new StrategyEngine();
        private FeeSchedule _fees = new FeeSchedule { MakerRate = 0.0040m, TakerRate = 0.0060m, Notes = "default" };
        
        /* UI Components */
        private SidebarControl _sidebar;
        private Panel _contentPanel;
        private ToolStripStatusLabel _statusLabel;
        private TradingControl _tradingControl;
        private Dictionary<string, Control> _views = new Dictionary<string, Control>();

        /* Public Accessors for Menu Integration */
        public AutoPlannerService AutoPlanner => _autoPlanner;
        public IExchangeProvider ExchangeProvider => _exchangeProvider;
        public IAccountService AccountService => _accountService;
        public IKeyService KeyService => _keyService;
        public IProfileService ProfileService => _profileService;
        public IHistoryService HistoryService => _historyService;

        public MainForm(IProfileService profileService)
        {
            InitializeComponent();
            _profileService = profileService;

           
            /* Default fallbacks for Designer or legacy startup (replaced by InitializeDependencies) */
            if (_keyService == null) _keyService = new KeyService();
            if (_exchangeProvider == null) _exchangeProvider = new ExchangeProvider(_keyService);
            if (_accountService == null) _accountService = new AccountService();
            
            if (cmbExchange.Items.Count > 0) cmbExchange.SelectedIndex = 0;
            if (cmbStrategy.Items.Count > 0) cmbStrategy.SelectedIndex = 0;

            try { LoadCoinbaseCdpKeys(); } catch { }
            
            /* Defer Build until dependencies likely ready, or do basic build */
            BuildModernLayout();
            Log("MainForm constructed");
        }

        public void InitializeDependencies(
            AutoPlannerService planner, 
            IExchangeProvider provider, 
            BacktestService backtester,
            IEventBus eventBus,
            IAccountService accountService,
            IKeyService keyService,
            IHistoryService historyService,
            ChromeSidecar sidecar,
            StrategyEngine engine,
            IRateRouter rateRouter,
            AIGovernor governor)
        {
            _autoPlanner = planner;
            _exchangeProvider = provider;
            _backtestService = backtester;
            _eventBus = eventBus;
            _accountService = accountService;
            _keyService = keyService;
            _historyService = historyService;
            _sidecar = sidecar;
            _engine = engine;
            _rateRouter = rateRouter;
            _governor = governor;

            if (_sidecar != null)
            {
                Task.Run(async () => {
                    if (await _sidecar.ConnectAsync()) Log("Chrome Sidecar Connected");
                    else Log("Chrome Sidecar: Not Found (Run Chrome with --remote-debugging-port=9222)");
                });
            }

            /* Re-subscribe loggers using EventBus */
            if (_eventBus != null)
            {
                _eventBus.Subscribe<LogEvent>(OnLogEvent);
            }
 
            /* Rebuild layout with new dependencies */
            // Clear view cache so they are recreated with new services
            _views.Clear();
            this.Controls.Clear();
            BuildModernLayout();
        }

        private void OnLogEvent(LogEvent evt)
        {
            /* Marshall to UI thread */
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new Action<LogEvent>(OnLogEvent), evt);
                return;
            }
            
            // 1. Update Global Status Bar (Always Visible)
            if (_statusLabel != null)
            {
                _statusLabel.Text = $"{evt.Timestamp:HH:mm:ss} {evt.Message}";
            }

            // 2. Update Trading Control (If Active/Cached)
            if (_tradingControl != null)
            {
                _tradingControl.Log(evt.Timestamp.ToString("HH:mm:ss") + " " + evt.Message);
            }
        }

 private void Log(string s) 
 { 
 /* Legacy local log method, now forwards to EventBus if available, or direct UI */
 if (_eventBus != null)
 {
 _eventBus.Publish(new LogEvent(s));
 }
 else
 {
 // Fallback direct update
 if (_tradingControl != null) _tradingControl.Log(s);
 }
 }

 private void LoadCoinbaseCdpKeys()
 {
     if (_keyService == null) return;
     try
     {
         var cdpFile = Path.Combine(Application.StartupPath, "cdp_api_key.json");
         if (File.Exists(cdpFile))
         {
             var json = File.ReadAllText(cdpFile);
             var cdpData = UtilCompat.JsonDeserialize<Dictionary<string, object>>(json);
             if (cdpData != null && cdpData.ContainsKey("name") && cdpData.ContainsKey("privateKey"))
             {
                 var keyInfo = new KeyInfo { 
                     Broker = "Coinbase", 
                     Label = "CDP Auto-loaded", 
                     ApiKey = cdpData["name"].ToString(), 
                     Secret = cdpData["privateKey"].ToString(), 
                     Passphrase = "", 
                     CreatedUtc = DateTime.UtcNow, 
                     Enabled = true 
                 };
                 _keyService.Upsert(keyInfo);
                 _keyService.SetActive("Coinbase", "CDP Auto-loaded");
                 Log("loaded coinbase CDP key");
             }
         }
     }
     catch (Exception ex) { Log("error loading CDP key: " + ex.Message); }
 }

 /* 
 REFACTOR: Use ExchangeProvider for client creation 
 */
 private IExchangeClient BuildClient()
 {
 string exch = "Coinbase";
 if (_tradingControl != null) exch = _tradingControl.Exchange ?? "Coinbase";
 else if (cmbExchange.SelectedItem != null) exch = cmbExchange.SelectedItem.ToString();
 
 return _exchangeProvider.CreateAuthenticatedClient(exch);
 }

 private async void btnLoadProducts_Click(object sender, EventArgs e)
 {
                try
                {
                    string exch = "Coinbase";
                    if (_tradingControl != null) exch = _tradingControl.Exchange ?? "Coinbase";
                    // Use Provider
                    _client = _exchangeProvider.CreatePublicClient(exch);

                    var list = await _client.ListProductsAsync();
                    var usdPairs = list.Where(x => x.Contains("/USD") || x.Contains("-USD")).ToList();
                    if (_tradingControl != null) _tradingControl.SetProducts(usdPairs);
                    Log("loaded products: " + usdPairs.Count);
                }
                catch (Exception ex) { Log("error loading products " + ex.Message); }
            }

            private async Task<List<Candle>> Load1mCandles(string productId, DateTime startUtc, DateTime endUtc)
            {
                /* If no client, create public one default */
                if (_client == null) _client = _exchangeProvider.CreatePublicClient("Coinbase");
                var c = await _client.GetCandlesAsync(productId, 1, startUtc, endUtc);
                return c;
            }

 private async void btnFees_Click(object sender, EventArgs e)
 {
 try
 {
 _client = BuildClient();
 _fees = await _client.GetFeesAsync();
                    Log("fees maker " + (_fees.MakerRate * 100m).ToString("0.###") + "% taker " + (_fees.TakerRate * 100m).ToString("0.###") + "% " + _fees.Notes);
                }
                catch (Exception ex) { Log("error getting fees " + ex.Message); }
            }

            /* 
               REFACTOR: Use BacktestService 
            */
            private async void btnBacktest_Click(object sender, EventArgs e)
            {
                try
                {
                    if (_backtestService == null) { Log("BacktestService not initialized"); return; }

                    var product = (_tradingControl != null ? _tradingControl.Product : null) ?? "BTC-USD";
                    var strat = (_tradingControl != null ? _tradingControl.Strategy : null) ?? "ORB";
                    var risk = (_tradingControl != null ? _tradingControl.Risk : 1m);
                    var equity = (_tradingControl != null ? _tradingControl.Equity : 1000m);
                    var exchange = (_tradingControl != null ? _tradingControl.Exchange : "Coinbase") ?? "Coinbase";

                    Log("starting backtest...");
                    var res = await _backtestService.RunBacktestAsync(exchange, product, strat, risk, equity, _fees);
                    
                    if (res.Error != null) { Log("Backtest Error: " + res.Error); return; }

                    if (_tradingControl != null && res.Candles != null) _tradingControl.SetCandles(res.Candles);
                    
                    var r = res.RunResult;
                    Log("backtest " + product + " trades " + r.Trades + " pnl $" + r.PnL.ToString("0.00") + " win " + (r.WinRate * 100m).ToString("0.0") + "% mdd " + (r.MaxDrawdown * 100m).ToString("0.0") + "%");

                    UpdateProjections();
                }
                catch (Exception ex) { Log("backtest fatal error " + ex.Message); }
            }

            /* Legacy Projection UI Logic */
            private void UpdateProjections()
            {
                var riskFrac = ((_tradingControl != null ? _tradingControl.Risk : 1m)) / 100m;
                var roundtrip = _fees.MakerRate + _fees.TakerRate + 0.0005m;
                var p = new ProjectionInput { StartingEquity = 100m, TradesPerDay = 10, WinRate = 0.52m, AvgWinR = 1.1m, AvgLossR = 1.0m, RiskPerTradeFraction = riskFrac, NetFeeAndFrictionRate = roundtrip, Days = 20 };
                var r = Projections.Compute(p);
                var s100 = " projection: " + r.EndingEquity.ToString("0.00") + " daily " + r.DailyExpectedReturnPct.ToString("0.00") + "%";
                p.StartingEquity = 1000m; var r2 = Projections.Compute(p); 
                var s1000 = " projection: " + r2.EndingEquity.ToString("0.00");
                if (_tradingControl != null) _tradingControl.SetProjections(s100, s1000);
            }

            private async void btnPaper_Click(object sender, EventArgs e)
            {
                // Keep legacy logic for now, StrategyEngine decoupled internally
                try
                {
                    _client = BuildClient();
                    var product = (_tradingControl != null ? _tradingControl.Product : null) ?? "BTC-USD";
                    var strat = (_tradingControl != null ? _tradingControl.Strategy : null) ?? "ORB";
                    var end = DateTime.UtcNow; var start = end.AddHours(-8);
                    
                    // AUDIT: Load1mCandles might not exist, use client directly
                    var candles = await _client.GetCandlesAsync(product, 1, start, end);
                    if (_tradingControl != null) _tradingControl.SetCandles(candles);

                    _engine.SetStrategy(strat);
                    var riskFrac = ((_tradingControl != null ? _tradingControl.Risk : 1m)) / 100m; 
                    var equity = (_tradingControl != null ? _tradingControl.Equity : 1000m);
                    CostBreakdown cb;
                    
                    if (candles == null || candles.Count == 0) { Log("No candles"); return; }

                    var price = candles.Last().Close;
                    var order = _engine.Evaluate(product, candles, _fees, equity, riskFrac, price, out cb);
                    if (order == null) { Log("no paper signal"); return; }
                    Log("paper trade " + order.Side + " " + order.Quantity + " " + product);
                }
                catch (Exception ex) { Log("paper error " + ex.Message); }
            }

            private async void btnLive_Click(object sender, EventArgs e)
            {
                try
                {
                    _client = BuildClient();
                    var product = (_tradingControl != null ? _tradingControl.Product : null) ?? "BTC-USD";
                    var strat = (_tradingControl != null ? _tradingControl.Strategy : null) ?? "ORB";
                    var end = DateTime.UtcNow; var start = end.AddHours(-8);

                    var candles = await _client.GetCandlesAsync(product, 1, start, end);
                    if (_tradingControl != null) _tradingControl.SetCandles(candles);

                    _engine.SetStrategy(strat);
                    var riskFrac = ((_tradingControl != null ? _tradingControl.Risk : 1m)) / 100m; 
                    var equity = (_tradingControl != null ? _tradingControl.Equity : 1000m);

                    var ticker = await _client.GetTickerAsync(product);
                    CostBreakdown cb;
                    var order = _engine.Evaluate(product, candles, _fees, equity, riskFrac, ticker.Last, out cb);
                    if (order == null) { Log("no live signal"); return; }
                    var res = await _client.PlaceOrderAsync(order);
                    Log("live order " + res.OrderId + " " + res.Message);
                }
                catch (Exception ex) { Log("live error " + ex.Message); }
            }

        private void BuildModernLayout()
        {
            this.Controls.Clear();
            CryptoDayTraderSuite.Themes.Theme.Apply(this);

            /* 1. Sidebar (Added Last to be Top of Z-Order for Left Dock) */
            _sidebar = new SidebarControl();
            _sidebar.Dock = DockStyle.Left;
            _sidebar.NavigationSelected += OnNavigationSelected;
            
            /* Wire AI Status */
            if (_governor != null)
            {
                _sidebar.Configure(_governor);
            }
            
            /* 2. Status Bar (Added before content to be at bottom) */
            var statusStrip = new StatusStrip();
            statusStrip.Dock = DockStyle.Bottom;
            statusStrip.BackColor = CryptoDayTraderSuite.Themes.Theme.PanelBg;
            statusStrip.ForeColor = CryptoDayTraderSuite.Themes.Theme.TextMuted;
            
            _statusLabel = new ToolStripStatusLabel();
            _statusLabel.Text = "Ready";
            _statusLabel.Spring = true;
            _statusLabel.TextAlign = ContentAlignment.MiddleLeft;
            statusStrip.Items.Add(_statusLabel);
            
            this.Controls.Add(statusStrip);

            /* 3. Content (Added First, so it fills remaining space) */
            _contentPanel = new Panel();
            _contentPanel.Dock = DockStyle.Fill;
            _contentPanel.BackColor = CryptoDayTraderSuite.Themes.Theme.ContentBg;
            
            this.Controls.Add(_contentPanel);
            this.Controls.Add(_sidebar);      
            this.Controls.SetChildIndex(_sidebar, 0); // Ensure Sidebar is top z-order (docked last = Left)
            
            /* Load Default */
            OnNavigationSelected("Dashboard");
        }

        public void NavigateTo(string page)
        {
            _sidebar?.SetActivePage(page);
            OnNavigationSelected(page);
        }

        private void OnNavigationSelected(string page)
        {
            Control view = null;
            if (_views.ContainsKey(page)) 
            {
                view = _views[page];
            }
            else 
            {
                view = CreateView(page);
                if (view != null) _views[page] = view;
            }

            _contentPanel.Controls.Clear();
            if (view != null)
            {
                view.Dock = DockStyle.Fill;
                _contentPanel.Controls.Add(view);
            }
        }

        private Control CreateView(string page)
        {
            try 
            {
                switch(page)
                {
                    case "Dashboard":
                        var db = new DashboardControl();
                        if (_accountService != null) 
                            db.Initialize(_accountService, _historyService ?? new HistoryService(), _governor);
                        CryptoDayTraderSuite.Themes.Theme.Apply(db);
                        return db;

                    case "Trading":
                        _tradingControl = new TradingControl();
                        /* Wire Legacy Events */
                        _tradingControl.LoadProductsClicked += btnLoadProducts_Click;
                        _tradingControl.FeesClicked += btnFees_Click;
                        _tradingControl.BacktestClicked += btnBacktest_Click;
                        _tradingControl.PaperClicked += btnPaper_Click;
                        _tradingControl.LiveClicked += btnLive_Click;
                        
                        /* Populate Lists */
                        _tradingControl.SetExchanges(new [] { "Coinbase", "Kraken", "Bitstamp" });
                        _tradingControl.SetStrategies(new [] { "ORB", "VWAPTrend", "RSIReversion", "Donchian 20" });

                        CryptoDayTraderSuite.Themes.Theme.Apply(_tradingControl);
                        return _tradingControl;

                    case "Planner":
                        var pc = new PlannerControl();
                        pc.Initialize(_historyService ?? new HistoryService());
                        CryptoDayTraderSuite.Themes.Theme.Apply(pc);
                        return pc;

                    case "Auto":
                        var ac = new AutoModeControl();
                        /* Handle partial initialization */
                        var planner = _autoPlanner;
                        var pubClient = _exchangeProvider.CreatePublicClient("Coinbase");
                        if (planner != null) {
                            ac.Initialize(planner, pubClient, _accountService);
                        }
                        CryptoDayTraderSuite.Themes.Theme.Apply(ac);
                        return ac;

                    case "Accounts":
                         var accCtrl = new AccountsControl();
                         if (_accountService != null) accCtrl.Initialize(_accountService);
                         CryptoDayTraderSuite.Themes.Theme.Apply(accCtrl);
                         return accCtrl;

                    case "Keys":
                         var keysCtrl = new KeysControl();
                         if (_keyService != null) keysCtrl.Initialize(_keyService);
                         CryptoDayTraderSuite.Themes.Theme.Apply(keysCtrl);
                         return keysCtrl;
                         
                    case "Settings":
                        /* Composite Settings View */
                        var settingsPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, AutoScroll = true, WrapContents = false };
                        settingsPanel.BackColor = CryptoDayTraderSuite.Themes.Theme.ContentBg;

                        /* 1. Profiles */
                        var lblProf = new Label { Text = "Profiles", Font = new System.Drawing.Font("Segoe UI", 14, System.Drawing.FontStyle.Bold), AutoSize = true, ForeColor = CryptoDayTraderSuite.Themes.Theme.Text, Margin = new Padding(10) };
                        settingsPanel.Controls.Add(lblProf);
                        
                        var profCtrl = new ProfilesControl();
                        if (_profileService != null) profCtrl.Initialize(_profileService);
                        profCtrl.Width = 600; profCtrl.Height = 400;
                        settingsPanel.Controls.Add(profCtrl);

                        /* 2. Strategy Config */
                        var btnConfig = new Button { Text = "Configure Strategies", Width = 200, Height = 40, Margin = new Padding(20) };
                        btnConfig.Click += (s, ev) => { 
                            if (_engine != null)
                            {
                                using(var dlg = new StrategyConfigDialog(_engine))
                                {
                                    dlg.ShowDialog();
                                }
                            }
                            else MessageBox.Show("Strategy Engine not initialized.");
                        };
                        settingsPanel.Controls.Add(btnConfig);
                        
                        // Fix for Theme.Apply overloading issue
                        if (settingsPanel is Panel p) ApplyThemeToControl(p);
                        else CryptoDayTraderSuite.Themes.Theme.Apply(settingsPanel as UserControl); // Only if UserControl
                        
                        return settingsPanel;

                    case "Profiles":
                        var pm = new ProfileManagerControl();
                        pm.Initialize(_keyService, _accountService, _profileService);
                        // Fix for Theme.Apply overloading issue
                        ApplyThemeToControl(pm);
                        return pm;
                         
                    default:
                        return null;
                }
            }
            catch (Exception ex)
            {
                Log("Error creating view " + page + ": " + ex.Message);
                return new Label { Text = "Error: " + ex.Message };
            }
        }
 protected override void OnLoad(EventArgs e)
 {
 base.OnLoad(e);
 LoadAI();
 BuildResponsiveLayout(); /* build layout at runtime */
 this.MinimumSize = new System.Drawing.Size(900, 600);
 this.KeyPreview = true;
 this.KeyDown += (s, a) => { if (a.KeyCode == Keys.F11) ToggleFullScreen(); };
 }

 protected override void OnFormClosing(FormClosingEventArgs e)
 {
 base.OnFormClosing(e);
 if (_eventBus != null) _eventBus.Unsubscribe<LogEvent>(OnLogEvent);
 SaveAI();
 }
 
        private void ApplyThemeToControl(Control c)
        {
            c.BackColor = CryptoDayTraderSuite.Themes.Theme.ContentBg;
            c.ForeColor = CryptoDayTraderSuite.Themes.Theme.Text;
            foreach (Control child in c.Controls) ApplyThemeToControlRecursively(child);
        }

        private void ApplyThemeToControlRecursively(Control c)
        {
            // Simple recursive applier since Theme.Apply only takes Form/UserControl
             if (c is Button b) 
            { 
                b.FlatStyle = FlatStyle.Flat; 
                b.FlatAppearance.BorderColor = CryptoDayTraderSuite.Themes.Theme.PanelBg; 
                b.BackColor = CryptoDayTraderSuite.Themes.Theme.PanelBg; 
                b.ForeColor = CryptoDayTraderSuite.Themes.Theme.Text; 
            }
            else if (c is TextBox t) { t.BackColor = CryptoDayTraderSuite.Themes.Theme.PanelBg; t.ForeColor = CryptoDayTraderSuite.Themes.Theme.Text; t.BorderStyle = BorderStyle.FixedSingle; }
            else {
                 c.BackColor = CryptoDayTraderSuite.Themes.Theme.PanelBg;
                 c.ForeColor = CryptoDayTraderSuite.Themes.Theme.Text;
                 if (c.HasChildren) foreach (Control child in c.Controls) ApplyThemeToControlRecursively(child);
            }
        }
 }
}
