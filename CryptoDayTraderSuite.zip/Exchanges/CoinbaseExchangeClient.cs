/* File: Exchanges/CoinbaseExchangeClient.cs */
/* Author: Gregory King */
/* Date: 2025-08-10 */
/* Description: Coinbase REST client (formerly GDAX) for public data and private trading */
/* Functions: ctor, Name, NormalizeProduct, DenormalizeProduct, PrivatePostAsync, ListProductsAsync, GetCandlesAsync, GetTickerAsync, GetFeesAsync, GetBalancesAsync, PlaceOrderAsync, CancelOrderAsync */

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Util;

namespace CryptoDayTraderSuite.Exchanges
{
	public class CoinbaseExchangeClient : IExchangeClient
	{
		private string _key; /* api key */
		private string _secretBase64; /* secret base64 */
		private string _passphrase; /* passphrase */
		private const string Rest = "https://api.exchange.coinbase.com"; /* base */
        private static readonly HttpClient _http = new HttpClient(); /* shared client */

		public CoinbaseExchangeClient(string key, string secretBase64, string passphrase) { _key = key; _secretBase64 = secretBase64; _passphrase = passphrase; } /* ctor */

        public void SetCredentials(string apiKey, string apiSecret, string passphrase = null)
        {
            _key = apiKey;
            _secretBase64 = apiSecret;
            _passphrase = passphrase;
        }

		public string Name { get { return "Coinbase"; } } /* name */

		public string NormalizeProduct(string uiSymbol) { return uiSymbol.Replace("/", "-"); } /* e.g. BTC-USD */
		public string DenormalizeProduct(string apiSymbol) { return apiSymbol.Replace("-", "/"); } /* to ui */

		private async Task<string> PrivateRequestAsync(string method, string path, string body = "")
		{
            return await HttpUtil.RetryAsync(async () =>
            {
			    /* coinbase signing: CB-ACCESS-SIGN = base64(HMAC-SHA256(secret, timestamp + method + path + body)) */
			    var ts = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(); /* timestamp */
			    var message = ts + method.ToUpperInvariant() + path + body; /* concat */
			    var sig = SecurityUtil.ComputeHmacSha256Base64(_secretBase64, message); /* sign */
			    var url = Rest + path;

                using (var req = new HttpRequestMessage(new HttpMethod(method.ToUpperInvariant()), url))
                {
                    req.Headers.Add("CB-ACCESS-KEY", _key); /* key */
                    req.Headers.Add("CB-ACCESS-SIGN", sig); /* sig */
                    req.Headers.Add("CB-ACCESS-TIMESTAMP", ts); /* ts */
                    req.Headers.Add("CB-ACCESS-PASSPHRASE", _passphrase); /* pass */
                    req.Headers.Add("User-Agent", "CryptoDayTraderSuite"); /* agent */

                    if (!string.IsNullOrEmpty(body))
                    {
                        req.Content = new StringContent(body, Encoding.UTF8, "application/json");
                    }

                    using (var resp = await _http.SendAsync(req))
                    {
                        var respBody = await resp.Content.ReadAsStringAsync();
                        if (!resp.IsSuccessStatusCode) throw new Exception(respBody);
                        return respBody;
                    }
                }
            });
		}

		public async Task<List<string>> ListProductsAsync()
		{
            return await HttpUtil.RetryAsync(async () => 
            {
			    var json = await HttpUtil.GetAsync(Rest + "/products"); /* list */
			    var arr = UtilCompat.JsonDeserialize<List<Dictionary<string, object>>>(json); /* parse */
			    var res = new List<string>(); foreach (var p in arr) if (p.ContainsKey("id")) res.Add(p["id"].ToString()); /* add */
			    return res; /* return */
            });
		}

		public async Task<List<Candle>> GetCandlesAsync(string productId, int minutes, DateTime startUtc, DateTime endUtc)
		{
            return await HttpUtil.RetryAsync(async () => 
            {
			    var pair = NormalizeProduct(productId); /* pair */
			    var gran = minutes * 60; /* seconds */
			    var url = Rest + "/products/" + pair + "/candles?granularity=" + gran + "&start=" + startUtc.ToString("o") + "&end=" + endUtc.ToString("o"); /* url */
			    var json = await HttpUtil.GetAsync(url); /* get */
			    var arr = UtilCompat.JsonDeserialize<object[]>(json); /* parse */
			    var res = new List<Candle>(); if (arr != null) foreach (var o in arr)
				    {
					    var row = o as object[]; if (row == null || row.Length < 6) continue; /* check */
					    res.Add(new Candle { Time = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(Convert.ToInt64(row[0])), Low = Convert.ToDecimal(row[1]), High = Convert.ToDecimal(row[2]), Open = Convert.ToDecimal(row[3]), Close = Convert.ToDecimal(row[4]), Volume = Convert.ToDecimal(row[5]) }); /* add */
				    }
			    res.Sort((a, b) => a.Time.CompareTo(b.Time)); /* sort */
			    return res; /* return */
            });
		}

		public async Task<Ticker> GetTickerAsync(string productId)
		{
            return await HttpUtil.RetryAsync(async () => 
            {
			    var pair = NormalizeProduct(productId); /* pair */
			    var url = Rest + "/products/" + pair + "/ticker"; /* url */
			    var json = await HttpUtil.GetAsync(url); /* get */
			    var obj = UtilCompat.JsonDeserialize<Dictionary<string, object>>(json); /* parse */
			    return new Ticker { Bid = Convert.ToDecimal(obj["bid"]), Ask = Convert.ToDecimal(obj["ask"]), Last = Convert.ToDecimal(obj["price"]), Time = DateTime.Parse(obj["time"].ToString(), null, DateTimeStyles.RoundtripKind) }; /* ticker */
            });
		}

		public async Task<FeeSchedule> GetFeesAsync()
		{
			var json = await PrivateRequestAsync("GET", "/fees"); /* call */
			var obj = UtilCompat.JsonDeserialize<Dictionary<string, object>>(json); /* parse */
			return new FeeSchedule { MakerRate = Convert.ToDecimal(obj["maker_fee_rate"]), TakerRate = Convert.ToDecimal(obj["taker_fee_rate"]), Notes = "from fees endpoint" }; /* return */
		}

		public async Task<Dictionary<string, decimal>> GetBalancesAsync()
		{
			var json = await PrivateRequestAsync("GET", "/accounts"); /* call */
			var arr = UtilCompat.JsonDeserialize<List<Dictionary<string, object>>>(json); /* parse */
			var d = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase); /* dict */
			foreach (var a in arr) d[a["currency"].ToString()] = Convert.ToDecimal(a["balance"]); /* add */
			return d; /* return */
		}

		public async Task<OrderResult> PlaceOrderAsync(OrderRequest req)
		{
			var body = new Dictionary<string, object>(); /* body */
			body["product_id"] = NormalizeProduct(req.ProductId); /* pair */
			body["side"] = req.Side == OrderSide.Buy ? "buy" : "sell"; /* side */
			body["type"] = req.Type == OrderType.Market ? "market" : "limit"; /* type */
			if (req.Type == OrderType.Limit)
			{
				body["price"] = req.Price.Value.ToString(CultureInfo.InvariantCulture); /* price */
				body["size"] = req.Quantity.ToString(CultureInfo.InvariantCulture); /* qty */
			}
			else
			{
				body["size"] = req.Quantity.ToString(CultureInfo.InvariantCulture); /* market qty is base currency */
			}
			var json = await PrivateRequestAsync("POST", "/orders", UtilCompat.JsonSerialize(body)); /* post */
			var obj = UtilCompat.JsonDeserialize<Dictionary<string, object>>(json); /* parse */
			var accepted = obj.ContainsKey("id"); var id = accepted ? obj["id"].ToString() : ""; /* id */
			return new OrderResult { OrderId = id, Accepted = accepted, Filled = false, FilledQty = 0m, AvgFillPrice = 0m, Message = accepted ? "accepted" : "error" }; /* result */
		}

		public async Task<bool> CancelOrderAsync(string orderId)
		{
			var json = await PrivateRequestAsync("DELETE", "/orders/" + orderId); /* delete */
			return json.Contains(orderId); /* naive */
		}

		public async Task<List<Dictionary<string, object>>> GetOpenOrdersAsync()
		{
			var json = await PrivateRequestAsync("GET", "/orders");
			return UtilCompat.JsonDeserialize<List<Dictionary<string, object>>>(json);
		}
	}
}