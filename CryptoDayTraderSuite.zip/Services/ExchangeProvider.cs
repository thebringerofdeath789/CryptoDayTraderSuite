using System;
using System.Collections.Generic;
using CryptoDayTraderSuite.Exchanges;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Services;

namespace CryptoDayTraderSuite.Services
{
    public interface IExchangeProvider
    {
        IExchangeClient CreateAuthenticatedClient(string brokerName);
        IExchangeClient CreatePublicClient(string brokerName);
    }

    public class ExchangeProvider : IExchangeProvider
    {
        private readonly IKeyService _keyService;

        /* Cache hash of encrypted credentials -> instantiated client to avoid repeated DPAPI decryption */
        private readonly Dictionary<string, (string hash, IExchangeClient client)> _clientCache 
            = new Dictionary<string, (string, IExchangeClient)>();

        public ExchangeProvider(IKeyService keyService)
        {
            _keyService = keyService;
        }

        public IExchangeClient CreateAuthenticatedClient(string brokerName)
        {
            if (string.IsNullOrEmpty(brokerName)) brokerName = "Coinbase";

            var activeKeyId = _keyService.GetActiveId(brokerName);
            if (string.IsNullOrEmpty(activeKeyId))
            {
                throw new InvalidOperationException($"No active API key found for {brokerName}. Please set one in the API Keys tab.");
            }

            var keyEntry = _keyService.Get(activeKeyId);
            if (keyEntry == null)
            {
                throw new InvalidOperationException($"Active API key {activeKeyId} not found in the registry.");
            }
            
            // Generate a state hash of the encrypted blobs
            var k = keyEntry.ApiKey ?? "";
            var s = keyEntry.Secret ?? "";
            var p = keyEntry.Passphrase ?? "";
            var stateHash = $"{activeKeyId}|{k}|{s}|{p}";

            // Check cache
            if (_clientCache.TryGetValue(activeKeyId, out var cached))
            {
                if (cached.hash == stateHash)
                {
                    return cached.client;
                }
            }

            // Fallback: Decrypt and Instantiate
            string apiKey = _keyService.Unprotect(k);
            string apiSecret = _keyService.Unprotect(s);
            string passphrase = _keyService.Unprotect(p);

            var client = Factory(brokerName, apiKey, apiSecret, passphrase);
            
            // Update cache
            _clientCache[activeKeyId] = (stateHash, client);
            return client;
        }

        public IExchangeClient CreatePublicClient(string brokerName)
        {
            if (string.IsNullOrEmpty(brokerName)) brokerName = "Coinbase";
            return Factory(brokerName, null, null, null);
        }

        private IExchangeClient Factory(string brokerName, string key, string secret, string pass)
        {
            IExchangeClient client;
            switch (brokerName.ToLowerInvariant())
            {
                case "coinbase":
                    client = new CoinbaseExchangeClient(key, secret, pass);
                    break;
                case "kraken":
                    client = new KrakenClient(key, secret);
                    break;
                case "bitstamp":
                    client = new BitstampClient(key, secret, pass);
                    break;
                default:
                    throw new NotSupportedException($"The exchange {brokerName} is not supported.");
            }

            // Wrap in resilience policy (Retries on Network Error)
            return new ResilientExchangeClient(client);
        }
    }
}
