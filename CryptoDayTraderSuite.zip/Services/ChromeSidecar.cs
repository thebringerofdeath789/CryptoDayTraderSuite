using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using CryptoDayTraderSuite.Util;

namespace CryptoDayTraderSuite.Services
{
    public enum SidecarStatus
    {
        Disconnected,
        Connecting,
        Connected,
        Error
    }

    public class ChromeSidecar : IDisposable
    {
        private const string DebugUrl = "http://localhost:9222/json";
        private ClientWebSocket _ws;
        private readonly HttpClient _http;
        private readonly JavaScriptSerializer _json;
        private int _msgId = 0;
        private string _attachedSessionId;

        public event Action<string> OnLog;
        public event Action<SidecarStatus> StatusChanged;

        public bool IsConnected => _ws != null && _ws.State == WebSocketState.Open;

        public SidecarStatus Status { get; private set; } = SidecarStatus.Disconnected;

        public ChromeSidecar()
        {
            _http = new HttpClient();
            _json = new JavaScriptSerializer();
        }

        private void SetStatus(SidecarStatus status)
        {
            if (Status != status)
            {
                Status = status;
                StatusChanged?.Invoke(Status);
            }
        }

        public async Task<bool> ConnectAsync()
        {
            SetStatus(SidecarStatus.Connecting);
            try
            {
                /* 1. Discover Tabs */
                var json = await _http.GetStringAsync(DebugUrl);
                var tabs = _json.Deserialize<List<dynamic>>(json);

                /* Look for AI tabs */
                var target = tabs.FirstOrDefault(t => 
                    (t["title"] as string ?? "").Contains("ChatGPT") || 
                    (t["title"] as string ?? "").Contains("Gemini") || 
                    (t["url"] as string ?? "").Contains("chatgpt.com"));

                if (target == null)
                {
                    Log("No AI tab found. Please open ChatGPT or Gemini in Chrome (started with --remote-debugging-port=9222).");
                    return false;
                }

                var wsUrl = target["webSocketDebuggerUrl"] as string;
                if (string.IsNullOrEmpty(wsUrl))
                {
                    Log("Target tab does not have a WebSocket URL.");
                    return false;
                }

                Log($"Connecting to {target["title"]}...");

                /* 2. Connect WebSocket */
                _ws = new ClientWebSocket();
                await _ws.ConnectAsync(new Uri(wsUrl), CancellationToken.None);
                
                Log("Connected via CDP.");
                SetStatus(SidecarStatus.Connected);
                return true;
            }
            catch (Exception ex)
            {
                Log($"Connection failed: {ex.Message}");
                SetStatus(SidecarStatus.Error);
                return false;
            }
        }

        public async Task<string> EvaluateJsAsync(string script)
        {
            if (!IsConnected) return null;

            int id = Interlocked.Increment(ref _msgId);
            
            /* CDP Runtime.evaluate command */
            var cmd = new
            {
                id = id,
                method = "Runtime.evaluate",
                @params = new
                {
                    expression = script,
                    returnByValue = true,
                    awaitPromise = true
                }
            };

            var request = _json.Serialize(cmd);
            await SendAsync(request);

            /* Very naive response wait - in production use a dictionary of pending tasks */
            var responseJson = await ReceiveAsync();
            
            /* Parse CDP Response to get actual value */
            try 
            {
                var dict = _json.Deserialize<Dictionary<string, object>>(responseJson);
                if (dict.ContainsKey("result"))
                {
                    var res = dict["result"] as Dictionary<string, object>;
                    if (res != null && res.ContainsKey("result"))
                    {
                        var inner = res["result"] as Dictionary<string, object>;
                        if (inner != null && inner.ContainsKey("value"))
                        {
                            return inner["value"]?.ToString();
                        }
                    }
                }
            }
            catch { }

            return responseJson; /* Fallback to raw if parsing fails */
        }

        public async Task<string> QueryAIAsync(string prompt)
        {
            /* 1. Inject Prompt into Textarea */
            var escapePrompt = prompt.Replace("\"", "\\\"").Replace("\n", "\\n");
            var script = $@"
                (function() {{
                    var ta = document.querySelector('#prompt-textarea');
                    if(!ta) return 'error: textarea not found';
                    ta.value = ""{escapePrompt}"";
                    ta.dispatchEvent(new Event('input', {{ bubbles: true }}));
                    
                    /* Click Send */
                    setTimeout(() => {{
                        var btn = document.querySelector('[data-testid=""send-button""]');
                        if(btn) btn.click();
                    }}, 200);
                    return 'ok';
                }})();
            ";
            
            await EvaluateJsAsync(script);

            /* 2. Wait for response (Naive: wait fixed time then poll) */
            await Task.Delay(5000); // Wait for generation to start/finish
            
            /* 3. Read Last Message */
            // Current ChatGPT selectors (subject to change)
            var readScript = @"
                (function() {
                    var msgs = document.querySelectorAll('.markdown');
                    if(msgs.length === 0) return '';
                    return msgs[msgs.length - 1].innerText;
                })();
            ";

            return await EvaluateJsAsync(readScript);
        }

        private async Task SendAsync(string msg)
        {
            var bytes = Encoding.UTF8.GetBytes(msg);
            await _ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
        }

        private async Task<string> ReceiveAsync()
        {
            var buffer = new byte[8192];
            var sb = new StringBuilder();
            WebSocketReceiveResult result;
            do
            {
                result = await _ws.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                sb.Append(Encoding.UTF8.GetString(buffer, 0, result.Count));
            }
            while (!result.EndOfMessage);

            return sb.ToString();
        }

        private void Log(string msg)
        {
            var fullMsg = $"[ChromeSidecar] {msg}";
            Util.Log.Debug(fullMsg);
            OnLog?.Invoke(fullMsg);
        }

        public void Dispose()
        {
            SetStatus(SidecarStatus.Disconnected);
            try { _ws?.Dispose(); } catch { }
            try { _http?.Dispose(); } catch { }
        }
    }
}
