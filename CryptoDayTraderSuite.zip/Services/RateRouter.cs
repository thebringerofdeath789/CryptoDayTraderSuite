using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;
using CryptoDayTraderSuite.Exchanges;

namespace CryptoDayTraderSuite.Services
{
    public class RateRouter : IRateRouter
    {
        private readonly IExchangeProvider _provider;
        private readonly ConcurrentDictionary<string, CachedRate> _mid = new ConcurrentDictionary<string, CachedRate>(StringComparer.OrdinalIgnoreCase);
        private readonly TimeSpan _ttl = TimeSpan.FromSeconds(15); /* AUDIT-0011 Fix: Lower TTL to 15s (was 5s in audit, but 15s is reasonable cache) */

        private struct CachedRate { public decimal Rate; public DateTime Time; }

        public RateRouter(IExchangeProvider provider)
        {
             _provider = provider ?? throw new ArgumentNullException(nameof(provider));
        }

        public decimal Mid(string baseAsset, string quoteAsset)
        {
            /* Sync-over-async Wrapper: Use with caution. Ideally migrate to Async. */
            return MidAsync(baseAsset, quoteAsset).GetAwaiter().GetResult();
        }

        public async Task<decimal> MidAsync(string baseAsset, string quoteAsset)
        {
            var pid = $"{baseAsset}-{quoteAsset}";
            
            if (_mid.TryGetValue(pid, out CachedRate c))
            {
                if ((DateTime.UtcNow - c.Time) < _ttl) return c.Rate;
            }

            try 
            {
                /* Use Coinbase Public for global rates */
                var client = _provider.CreatePublicClient("Coinbase"); 
                /* Note: GetTickerAsync is standard, GetTickerMidAsync specific to CoinbasePublicClient? 
                   IExchangeClient has GetTickerAsync returning Ticker object. 
                   Ticker.Price is the last trade. Use that. */
                
                var ticker = await client.GetTickerAsync(pid).ConfigureAwait(false);
                if (ticker != null && ticker.Last > 0)
                {
                    var rate = ticker.Last;
                    _mid[pid] = new CachedRate { Rate = rate, Time = DateTime.UtcNow };
                    return rate;
                }
            }
            catch 
            {
                /* Swallowing here implies we just return 0 if rate unavailable */
            }
            
            return 0m;
        }

        public decimal Convert(string fromAsset, string toAsset, decimal amount)
        {
            return ConvertAsync(fromAsset, toAsset, amount).GetAwaiter().GetResult();
        }

        public async Task<decimal> ConvertAsync(string fromAsset, string toAsset, decimal amount)
        {
            if (string.Equals(fromAsset, toAsset, StringComparison.OrdinalIgnoreCase)) return amount;

            /* Direct */
            var d = await MidAsync(fromAsset, toAsset).ConfigureAwait(false);
            if (d > 0m) return amount * d;
            
            /* Reverse */
            var r = await MidAsync(toAsset, fromAsset).ConfigureAwait(false);
            if (r > 0m) return amount / r;

            /* Hops via Stablecoins/Majors */
            string[] hubs = new string[] { "USD", "USDC", "USDT", "BTC" };
            foreach (var hub in hubs)
            {
                if (hub == fromAsset || hub == toAsset) continue;

                /* Try FROM -> HUB */
                var rate1 = await GetRateOrInverse(fromAsset, hub).ConfigureAwait(false);
                if (rate1 == 0) continue;

                /* Try HUB -> TO */
                var rate2 = await GetRateOrInverse(hub, toAsset).ConfigureAwait(false);
                if (rate2 == 0) continue;

                return amount * rate1 * rate2;
            }
            
            return 0m;
        }

        private async Task<decimal> GetRateOrInverse(string a, string b)
        {
            var d = await MidAsync(a, b).ConfigureAwait(false);
            if (d > 0) return d;
            var r = await MidAsync(b, a).ConfigureAwait(false);
            if (r > 0) return 1m / r;
            return 0m;
        }
    }
}
