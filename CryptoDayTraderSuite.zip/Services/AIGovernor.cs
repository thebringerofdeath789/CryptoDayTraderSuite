using System;
using System.Linq;
using System.Threading.Tasks;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Models.AI;
using CryptoDayTraderSuite.Strategy;
using CryptoDayTraderSuite.Util;
using CryptoDayTraderSuite.Services.Messaging;
using CryptoDayTraderSuite.Services.Messaging.Events;

namespace CryptoDayTraderSuite.Services
{
    public class AIGovernor
    {
        private readonly ChromeSidecar _sidecar;
        private readonly StrategyEngine _engine;
        private readonly IExchangeProvider _provider;
        private readonly IEventBus _bus;
        private bool _running;

        public event Action<MarketBias, string> BiasUpdated;
        public event Action<string> StatusChanged;

        public AIGovernor(ChromeSidecar sidecar, StrategyEngine engine, IExchangeProvider provider, IEventBus bus)
        {
            _sidecar = sidecar;
            _engine = engine;
            _provider = provider;
            _bus = bus;

            // Subscribe to sidecar status updates
            if (_sidecar != null)
            {
                _sidecar.StatusChanged += OnSidecarStatus;
            }
        }

        private void OnSidecarStatus(SidecarStatus status)
        {
            // Only propagate sidecar status if the governor is actually trying to run
            if (_running)
            {
                StatusChanged?.Invoke(status.ToString());
            }
        }

        public void Start()
        {
            if (_running) return;
            _running = true;
            
            Log("AI Governor Started.");
            StatusChanged?.Invoke("Starting...");
            
            Task.Run(LoopAsync);
        }

        public void Stop()
        {
            _running = false;
            Log("AI Governor Stopped.");
            StatusChanged?.Invoke("Stopped");
        }

        private async Task LoopAsync()
        {
            // Initial grace period
            await Task.Delay(5000); 

            while (_running)
            {
                try
                {
                    if (_sidecar != null && _sidecar.IsConnected)
                    {
                        StatusChanged?.Invoke("Analyzing...");
                        await RunCycleAsync();
                        StatusChanged?.Invoke("Idle (Next: 15m)");
                    }
                    else
                    {
                        StatusChanged?.Invoke("Offline (Waiting for Browser)");
                        
                        // Fail Safe: If AI is offline, ensure we don't stick to a stale bias.
                        if (_engine.GlobalBias != MarketBias.Neutral)
                        {
                            _engine.GlobalBias = MarketBias.Neutral;
                            Log("AI Governor Disconnected - Reverting Market Bias to NEUTRAL (Fail Safe)");
                            BiasUpdated?.Invoke(MarketBias.Neutral, "AI Offline");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log($"AI Governor Error: {ex.Message}");
                    StatusChanged?.Invoke("Error");
                }

                // Poll interval: 15 minutes with fast exit check
                for (int i = 0; i < 900; i++) 
                {
                    if (!_running) break;
                    await Task.Delay(1000);
                }
            }
        }

        private async Task RunCycleAsync()
        {
            // 1. Fetch Market Context (BTC)
            var client = _provider.CreatePublicClient("Coinbase");
            var end = DateTime.UtcNow;
            var start = end.AddHours(-4);
            var candles = await client.GetCandlesAsync("BTC-USD", 15, start, end); // 15m candles for H4 context

            if (candles == null || candles.Count < 10) return;

            // 2. Build Context
            var ctx = new MarketContext
            {
                Symbol = "BTC-USD",
                Interval = "15m",
                CurrentPrice = candles.Last().Close,
                VWAP = Indicators.VWAP(candles),
                TimestampUtc = end,
                // Simple summary
                RecentStructure = candles.Skip(Math.Max(0, candles.Count() - 5)).Select(c => new SimpleCandle 
                { 
                    Time = c.Time, Open = c.Open, High = c.High, Low = c.Low, Close = c.Close 
                }).ToList()
            };

            // 3. Prompt
            var json = UtilCompat.JsonSerialize(ctx);
            var prompt = $"Analyze this bitcoin market structure (15m candles over 4h). JSON Data: {json}. Determine global bias. Return JSON: {{ \"bias\": \"Bullish\"|\"Bearish\"|\"Neutral\", \"reason\": \"...\" }}";

            // 4. Query
            var raw = await _sidecar.QueryAIAsync(prompt);
            if (string.IsNullOrEmpty(raw)) return;

            var clean = raw.Replace("```json", "").Replace("```", "").Trim();
            
            var resp = UtilCompat.JsonDeserialize<AIResponse>(clean);
            if (resp != null)
            {
                if (Enum.TryParse(resp.Bias, true, out MarketBias bias))
                {
                    if (_engine.GlobalBias != bias)
                    {
                        var old = _engine.GlobalBias;
                        _engine.GlobalBias = bias;
                        Log($"Market Bias changed from {old} to {bias}. Reason: {resp.Reason}");
                        BiasUpdated?.Invoke(bias, resp.Reason);
                    }
                    else
                    {
                         Log($"Market Bias remains {bias}. Reason: {resp.Reason}");
                         BiasUpdated?.Invoke(bias, resp.Reason);
                    }
                }
            }
        }

        private void Log(string msg)
        {
            Util.Log.Info($"[AIGovernor] {msg}");
            _bus?.Publish(new LogEvent(msg));
        }
    }
}