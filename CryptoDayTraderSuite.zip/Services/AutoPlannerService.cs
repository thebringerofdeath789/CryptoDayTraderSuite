using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Models.AI;
using CryptoDayTraderSuite.Util;
using CryptoDayTraderSuite.Exchanges;
using CryptoDayTraderSuite.Strategy;

namespace CryptoDayTraderSuite.Services
{
    public class AutoPlannerService
    {
        private readonly IExchangeClient _client;
        private readonly IEnumerable<IStrategy> _strategies;
        private readonly ChromeSidecar _sidecar;
        private readonly StrategyEngine _engine;

        public AutoPlannerService(IExchangeClient client, IEnumerable<IStrategy> strategies, ChromeSidecar sidecar = null, StrategyEngine engine = null)
        {
            _client = client ?? throw new ArgumentNullException(nameof(client));
            _strategies = strategies ?? throw new ArgumentNullException(nameof(strategies));
            _sidecar = sidecar;
            _engine = engine;
        }

        public async Task<List<ProjectionRow>> ProjectAsync(string productId, int granMinutes, int lookbackMinutes, decimal takerRate, decimal makerRate)
        {
            var end = DateTime.UtcNow;
            var start = end.AddMinutes(-Math.Max(lookbackMinutes, 60));

            var candles = await _client.GetCandlesAsync(productId, granMinutes, start, end) ?? new List<Candle>();

            return await Task.Run(() =>
            {
                var outRows = new List<ProjectionRow>();
                if (candles.Count < 40) return outRows;

                foreach (var strategy in _strategies)
                {
                    int wins = 0, total = 0;
                    decimal rsum = 0m;
                    decimal rWinSum = 0m;
                    decimal rLossSum = 0m;

                    /* simulation loop: walk forward */
                    for (int i = 20; i < candles.Count - 1; i++)
                    {
                        var result = strategy.GetSignal(candles, i);

                        if (result.IsSignal)
                        {
                            total++;
                            var entry = result.EntryPrice;
                            var stop = result.StopLoss;
                            var next = candles[i + 1].Close;

                            /* calculate R multiple realized on next bar close (simplified approximation) */
                            /* in reality we would check low/high against stop, but for projection close-to-close is distinct */
                            decimal r = 0m;
                            var risk = Math.Abs(entry - stop);
                            
                            if (risk > 0.00000001m)
                            {
                                if (result.Side == OrderSide.Buy) r = (next - entry) / risk;
                                else r = (entry - next) / risk;
                            }

                            /* naive win check */
                            if (r > 0) 
                            {
                                wins++;
                                rWinSum += r;
                            }
                            else
                            {
                                rLossSum += r;
                            }
                            
                            rsum += r;
                        }
                    }

                    if (total > 0)
                    {
                        var losses = total - wins;
                        outRows.Add(new ProjectionRow
                        {
                            Strategy = strategy.Name,
                            Symbol = productId,
                            GranMinutes = granMinutes,
                            Expectancy = (double)((rsum / total) - (takerRate + makerRate)),
                            WinRate = (double)(100m * wins / total),
                            AvgWin = wins > 0 ? (double)(rWinSum / wins) : 0,
                            AvgLoss = losses > 0 ? (double)(rLossSum / losses) : 0,
                            SharpeApprox = 0, /* Need variance for Sharpe, skip for now */
                            Samples = total
                        });
                    }
                }

                return outRows.OrderByDescending(r => r.Expectancy).ToList();
            });
        }

        public async Task<List<TradePlan>> ProposeAsync(string accountId, string productId, int granMinutes, decimal equityUsd, decimal riskPct, List<ProjectionRow> rows)
        {
            var best = rows?.OrderByDescending(r => r.Expectancy).FirstOrDefault();
            if (best == null) return new List<TradePlan>();

            /* Find the actual strategy instance that performed best */
            var strategy = _strategies.FirstOrDefault(s => s.Name == best.Strategy);
            if (strategy == null) return new List<TradePlan>();

            var end = DateTime.UtcNow;
            var start = end.Subtract(TimeSpan.FromMinutes(granMinutes * 100)); /* need enough lookback */

            var candlesList = await _client.GetCandlesAsync(productId, granMinutes, start, end);
            if (candlesList == null || candlesList.Count == 0) return new List<TradePlan>();
            
            /* Get live signal */
            var result = strategy.GetSignal(candlesList);
            if (!result.IsSignal) return new List<TradePlan>();

            /* Check Global Bias (AIGovernor) */
            if (_engine != null)
            {
                if (_engine.GlobalBias == MarketBias.Bearish && result.Side == OrderSide.Buy) return new List<TradePlan>();
                if (_engine.GlobalBias == MarketBias.Bullish && result.Side == OrderSide.Sell) return new List<TradePlan>();
            }

            /* Calculate Position Size */
            var riskDollars = equityUsd * (riskPct / 100m);
            var distance = Math.Abs(result.EntryPrice - result.StopLoss);
            
            var qty = 0m;
            if (distance > 0)
            {
                qty = Math.Round(riskDollars / distance, 6);
            }

            var plan = new TradePlan {
                AccountId = accountId ?? "sim-acct",
                Symbol = productId.Replace("-", "/"),
                Strategy = strategy.Name,
                Direction = (int)result.Side,
                Entry = result.EntryPrice,
                Stop = result.StopLoss,
                Target = result.TakeProfit,
                Qty = qty,
                Note = $"AutoPlanner {strategy.Name} exp={best.Expectancy:0.00} wr={best.WinRate:0.0}%"
            };

            /* AI Review Hook */
            if (_sidecar != null && _sidecar.IsConnected)
            {
                try
                {
                    var preview = new TradePreview
                    {
                        Symbol = productId,
                        Strategy = strategy.Name,
                        Side = result.Side.ToString(),
                        Entry = result.EntryPrice,
                        Stop = result.StopLoss,
                        Target = result.TakeProfit,
                        Rationale = $"Expectancy {best.Expectancy:0.00}, recent signals count {best.Samples}"
                    };

                    var json = UtilCompat.JsonSerialize(preview);
                    var prompt = $"You are a crypto risk manager. Review this trade:\\n{json}\\nReturn standard JSON only: {{ \"bias\": \"Bullish\", \"approve\": true, \"reason\": \"...\", \"confidence\": 0.9, \"SuggestedLimit\": 0.0 }}";
                    
                    var aiRaw = await _sidecar.QueryAIAsync(prompt);
                    
                    /* Sanitize */
                    var cleanJson = aiRaw.Replace("```json", "").Replace("```", "").Trim();
                    var aiResp = UtilCompat.JsonDeserialize<AIResponse>(cleanJson);
                    
                    if (aiResp != null)
                    {
                        if (!aiResp.Approve)
                        {
                            return new List<TradePlan>(); /* AI Veto */
                        }
                        plan.Note += $" [AI Approved: {aiResp.Reason}]";
                        
                        if (aiResp.SuggestedLimit.HasValue && aiResp.SuggestedLimit.Value > 0)
                        {
                            plan.Entry = aiResp.SuggestedLimit.Value;
                            plan.Note += $" [SmartLimit: {plan.Entry}]";
                        }
                    }
                }
                catch (Exception ex)
                {
                    plan.Note += $" [AI Failed: {ex.Message}]";
                }
            }

            return new List<TradePlan> { plan };
        }
    }
}
