/* File: Util/HttpUtil.cs */
/* fixes: no Content-Type on DefaultRequestHeaders to avoid 'Misused header name' */
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace CryptoDayTraderSuite.Util
{
    public static class HttpUtil
    {
        private static readonly HttpClient _http = new HttpClient(); /* shared */

        public static void ClearDefaultHeaders()
        {
            _http.DefaultRequestHeaders.Clear();
        }

        public static void AddDefaultHeader(string name, string value)
        {
            _http.DefaultRequestHeaders.Remove(name);
            _http.DefaultRequestHeaders.Add(name, value);
        }

        public static async Task<string> GetAsync(string url)
        {
            Log.Trace($"GET {url}");
            try 
            {
                using (var r = await _http.GetAsync(url))
                {
                    var body = await r.Content.ReadAsStringAsync();
                    if (!r.IsSuccessStatusCode) 
                    {
                        var msg = $"HTTP {(int)r.StatusCode}: {body}";
                        Log.Debug($"GET {url} FAILED: {msg}");
                        throw new Exception(msg);
                    }
                    Log.Trace($"GET {url} OK ({body.Length} bytes)");
                    return body;
                }
            }
            catch (Exception ex)
            {
                Log.Error($"GET {url} EXCEPTION", ex);
                throw;
            }
        }

        public static async Task<string> SendAsync(HttpRequestMessage req)
        {
            var r = await _http.SendAsync(req);
            var body = await r.Content.ReadAsStringAsync();
            if (!r.IsSuccessStatusCode) throw new Exception("http error " + (int)r.StatusCode + " " + body);
            return body;
        }

        public static async Task<T> RetryAsync<T>(Func<Task<T>> operation, int maxAttempts = 3, int initialDelayMs = 500)
        {
            int attempt = 0;
            while (true)
            {
                attempt++;
                try
                {
                    return await operation();
                }
                catch (Exception ex)
                {
                    if (attempt >= maxAttempts || !IsTransient(ex)) throw;
                    
                    /* Exponential Backoff */
                    int delay = initialDelayMs * (int)Math.Pow(2, attempt - 1);
                    await Task.Delay(delay);
                }
            }
        }

        private static bool IsTransient(Exception ex)
        {
            /* Check for timeouts, 5xx errors, or network issues */
            /* Simplified check for now */
            var msg = ex.Message.ToLowerInvariant();
            if (msg.Contains("timeout")) return true;
            if (msg.Contains("500") || msg.Contains("502") || msg.Contains("503") || msg.Contains("504")) return true;
            /* request exception / socket exception usually implies network */
            if (ex is HttpRequestException) return true;
            return false;
        }
    }
}