namespace CryptoDayTraderSuite.UI
{
    partial class PlannerControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.mainLayout = new System.Windows.Forms.TableLayoutPanel();
            this.leftPanel = new System.Windows.Forms.Panel();
            this.gridPlanned = new System.Windows.Forms.DataGridView();
            this.colEnabled = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.colExchange = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colProduct = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStrategy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSide = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEstEdge = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNotes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ctxMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.miEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.miDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.topBar = new System.Windows.Forms.FlowLayoutPanel();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblProduct = new System.Windows.Forms.Label();
            this.cmbFilterProduct = new System.Windows.Forms.ComboBox();
            this.lblStrategy = new System.Windows.Forms.Label();
            this.cmbFilterStrategy = new System.Windows.Forms.ComboBox();
            this.gridPreds = new System.Windows.Forms.DataGridView();
            this.colPredProduct = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPredTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPredHorizon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPredDir = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPredProb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPredExpRet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPredExpVol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPredKnown = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPredRDir = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPredRRet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mainLayout.SuspendLayout();
            this.leftPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridPlanned)).BeginInit();
            this.ctxMenu.SuspendLayout();
            this.topBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridPreds)).BeginInit();
            this.SuspendLayout();
            // 
            // mainLayout
            // 
            this.mainLayout.ColumnCount = 2;
            this.mainLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55F));
            this.mainLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.mainLayout.Controls.Add(this.leftPanel, 0, 0);
            this.mainLayout.Controls.Add(this.gridPreds, 1, 0);
            this.mainLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainLayout.Location = new System.Drawing.Point(0, 0);
            this.mainLayout.Name = "mainLayout";
            this.mainLayout.RowCount = 1;
            this.mainLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mainLayout.Size = new System.Drawing.Size(1200, 800);
            this.mainLayout.TabIndex = 0;
            // 
            // leftPanel
            // 
            this.leftPanel.Controls.Add(this.gridPlanned);
            this.leftPanel.Controls.Add(this.topBar);
            this.leftPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.leftPanel.Location = new System.Drawing.Point(3, 3);
            this.leftPanel.Name = "leftPanel";
            this.leftPanel.Size = new System.Drawing.Size(654, 794);
            this.leftPanel.TabIndex = 0;
            // 
            // gridPlanned
            // 
            this.gridPlanned.AllowUserToAddRows = false;
            this.gridPlanned.AllowUserToDeleteRows = false;
            this.gridPlanned.AutoGenerateColumns = false;
            this.gridPlanned.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridPlanned.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridPlanned.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colEnabled,
            this.colExchange,
            this.colProduct,
            this.colStrategy,
            this.colSide,
            this.colQty,
            this.colPrice,
            this.colEstEdge,
            this.colNotes});
            this.gridPlanned.ContextMenuStrip = this.ctxMenu;
            this.gridPlanned.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridPlanned.Location = new System.Drawing.Point(0, 35);
            this.gridPlanned.MultiSelect = false;
            this.gridPlanned.Name = "gridPlanned";
            this.gridPlanned.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridPlanned.Size = new System.Drawing.Size(654, 759);
            this.gridPlanned.TabIndex = 1;
            // 
            // colEnabled
            // 
            this.colEnabled.DataPropertyName = "Enabled";
            this.colEnabled.HeaderText = "Enabled";
            this.colEnabled.Name = "colEnabled";
            this.colEnabled.Width = 60;
            // 
            // colExchange
            // 
            this.colExchange.DataPropertyName = "Exchange";
            this.colExchange.HeaderText = "Exchange";
            this.colExchange.Name = "colExchange";
            this.colExchange.ReadOnly = true;
            this.colExchange.Width = 80;
            // 
            // colProduct
            // 
            this.colProduct.DataPropertyName = "ProductId";
            this.colProduct.HeaderText = "Product";
            this.colProduct.Name = "colProduct";
            this.colProduct.ReadOnly = true;
            this.colProduct.Width = 80;
            // 
            // colStrategy
            // 
            this.colStrategy.DataPropertyName = "Strategy";
            this.colStrategy.HeaderText = "Strategy";
            this.colStrategy.Name = "colStrategy";
            this.colStrategy.ReadOnly = true;
            this.colStrategy.Width = 80;
            // 
            // colSide
            // 
            this.colSide.DataPropertyName = "Side";
            this.colSide.HeaderText = "Side";
            this.colSide.Name = "colSide";
            this.colSide.ReadOnly = true;
            this.colSide.Width = 60;
            // 
            // colQty
            // 
            this.colQty.DataPropertyName = "Quantity";
            this.colQty.HeaderText = "Qty";
            this.colQty.Name = "colQty";
            this.colQty.Width = 60;
            // 
            // colPrice
            // 
            this.colPrice.DataPropertyName = "Price";
            this.colPrice.HeaderText = "Price";
            this.colPrice.Name = "colPrice";
            this.colPrice.Width = 80;
            // 
            // colEstEdge
            // 
            this.colEstEdge.DataPropertyName = "EstEdge";
            this.colEstEdge.HeaderText = "Est. Edge";
            this.colEstEdge.Name = "colEstEdge";
            this.colEstEdge.ReadOnly = true;
            this.colEstEdge.Width = 80;
            // 
            // colNotes
            // 
            this.colNotes.DataPropertyName = "Notes";
            this.colNotes.HeaderText = "Notes";
            this.colNotes.Name = "colNotes";
            this.colNotes.Width = 120;
            // 
            // ctxMenu
            // 
            this.ctxMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miEdit,
            this.miDelete});
            this.ctxMenu.Name = "ctxMenu";
            this.ctxMenu.Size = new System.Drawing.Size(108, 48);
            // 
            // miEdit
            // 
            this.miEdit.Name = "miEdit";
            this.miEdit.Size = new System.Drawing.Size(107, 22);
            this.miEdit.Text = "Edit";
            // 
            // miDelete
            // 
            this.miDelete.Name = "miDelete";
            this.miDelete.Size = new System.Drawing.Size(107, 22);
            this.miDelete.Text = "Delete";
            // 
            // topBar
            // 
            this.topBar.AutoSize = true;
            this.topBar.Controls.Add(this.btnRefresh);
            this.topBar.Controls.Add(this.btnSave);
            this.topBar.Controls.Add(this.btnAdd);
            this.topBar.Controls.Add(this.lblProduct);
            this.topBar.Controls.Add(this.cmbFilterProduct);
            this.topBar.Controls.Add(this.lblStrategy);
            this.topBar.Controls.Add(this.cmbFilterStrategy);
            this.topBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.topBar.Location = new System.Drawing.Point(0, 0);
            this.topBar.Name = "topBar";
            this.topBar.Padding = new System.Windows.Forms.Padding(4);
            this.topBar.Size = new System.Drawing.Size(654, 35);
            this.topBar.TabIndex = 0;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(7, 7);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 23);
            this.btnRefresh.TabIndex = 0;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(88, 7);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(169, 7);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Add Trade";
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Location = new System.Drawing.Point(250, 4);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.lblProduct.Size = new System.Drawing.Size(47, 18);
            this.lblProduct.TabIndex = 3;
            this.lblProduct.Text = "Product:";
            // 
            // cmbFilterProduct
            // 
            this.cmbFilterProduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFilterProduct.FormattingEnabled = true;
            this.cmbFilterProduct.Location = new System.Drawing.Point(303, 7);
            this.cmbFilterProduct.Name = "cmbFilterProduct";
            this.cmbFilterProduct.Size = new System.Drawing.Size(120, 21);
            this.cmbFilterProduct.TabIndex = 4;
            // 
            // lblStrategy
            // 
            this.lblStrategy.AutoSize = true;
            this.lblStrategy.Location = new System.Drawing.Point(429, 4);
            this.lblStrategy.Name = "lblStrategy";
            this.lblStrategy.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.lblStrategy.Size = new System.Drawing.Size(49, 18);
            this.lblStrategy.TabIndex = 5;
            this.lblStrategy.Text = "Strategy:";
            // 
            // cmbFilterStrategy
            // 
            this.cmbFilterStrategy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFilterStrategy.FormattingEnabled = true;
            this.cmbFilterStrategy.Location = new System.Drawing.Point(484, 7);
            this.cmbFilterStrategy.Name = "cmbFilterStrategy";
            this.cmbFilterStrategy.Size = new System.Drawing.Size(120, 21);
            this.cmbFilterStrategy.TabIndex = 6;
            // 
            // gridPreds
            // 
            this.gridPreds.AllowUserToAddRows = false;
            this.gridPreds.AllowUserToDeleteRows = false;
            this.gridPreds.AutoGenerateColumns = false;
            this.gridPreds.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridPreds.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridPreds.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colPredProduct,
            this.colPredTime,
            this.colPredHorizon,
            this.colPredDir,
            this.colPredProb,
            this.colPredExpRet,
            this.colPredExpVol,
            this.colPredKnown,
            this.colPredRDir,
            this.colPredRRet});
            this.gridPreds.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridPreds.Location = new System.Drawing.Point(663, 3);
            this.gridPreds.Name = "gridPreds";
            this.gridPreds.ReadOnly = true;
            this.gridPreds.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridPreds.Size = new System.Drawing.Size(534, 794);
            this.gridPreds.TabIndex = 1;
            // 
            // colPredProduct
            // 
            this.colPredProduct.DataPropertyName = "ProductId";
            this.colPredProduct.HeaderText = "Product";
            this.colPredProduct.Name = "colPredProduct";
            this.colPredProduct.ReadOnly = true;
            this.colPredProduct.Width = 80;
            // 
            // colPredTime
            // 
            this.colPredTime.DataPropertyName = "AtUtc";
            this.colPredTime.HeaderText = "Time";
            this.colPredTime.Name = "colPredTime";
            this.colPredTime.ReadOnly = true;
            this.colPredTime.Width = 120;
            // 
            // colPredHorizon
            // 
            this.colPredHorizon.DataPropertyName = "HorizonMinutes";
            this.colPredHorizon.HeaderText = "Horizon";
            this.colPredHorizon.Name = "colPredHorizon";
            this.colPredHorizon.ReadOnly = true;
            this.colPredHorizon.Width = 60;
            // 
            // colPredDir
            // 
            this.colPredDir.DataPropertyName = "Direction";
            this.colPredDir.HeaderText = "Dir";
            this.colPredDir.Name = "colPredDir";
            this.colPredDir.ReadOnly = true;
            this.colPredDir.Width = 40;
            // 
            // colPredProb
            // 
            this.colPredProb.DataPropertyName = "Probability";
            this.colPredProb.HeaderText = "Prob";
            this.colPredProb.Name = "colPredProb";
            this.colPredProb.ReadOnly = true;
            this.colPredProb.Width = 60;
            // 
            // colPredExpRet
            // 
            this.colPredExpRet.DataPropertyName = "ExpectedReturn";
            this.colPredExpRet.HeaderText = "ExpRet";
            this.colPredExpRet.Name = "colPredExpRet";
            this.colPredExpRet.ReadOnly = true;
            this.colPredExpRet.Width = 60;
            // 
            // colPredExpVol
            // 
            this.colPredExpVol.DataPropertyName = "ExpectedVol";
            this.colPredExpVol.HeaderText = "ExpVol";
            this.colPredExpVol.Name = "colPredExpVol";
            this.colPredExpVol.ReadOnly = true;
            this.colPredExpVol.Width = 60;
            // 
            // colPredKnown
            // 
            this.colPredKnown.DataPropertyName = "RealizedKnown";
            this.colPredKnown.HeaderText = "Known";
            this.colPredKnown.Name = "colPredKnown";
            this.colPredKnown.ReadOnly = true;
            this.colPredKnown.Width = 50;
            // 
            // colPredRDir
            // 
            this.colPredRDir.DataPropertyName = "RealizedDirection";
            this.colPredRDir.HeaderText = "RDir";
            this.colPredRDir.Name = "colPredRDir";
            this.colPredRDir.ReadOnly = true;
            this.colPredRDir.Width = 40;
            // 
            // colPredRRet
            // 
            this.colPredRRet.DataPropertyName = "RealizedReturn";
            this.colPredRRet.HeaderText = "RRet";
            this.colPredRRet.Name = "colPredRRet";
            this.colPredRRet.ReadOnly = true;
            this.colPredRRet.Width = 60;
            // 
            // PlannerControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.mainLayout);
            this.Name = "PlannerControl";
            this.Size = new System.Drawing.Size(1200, 800);
            this.mainLayout.ResumeLayout(false);
            this.leftPanel.ResumeLayout(false);
            this.leftPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridPlanned)).EndInit();
            this.ctxMenu.ResumeLayout(false);
            this.topBar.ResumeLayout(false);
            this.topBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridPreds)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel mainLayout;
        private System.Windows.Forms.Panel leftPanel;
        private System.Windows.Forms.FlowLayoutPanel topBar;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.ComboBox cmbFilterProduct;
        private System.Windows.Forms.Label lblStrategy;
        private System.Windows.Forms.ComboBox cmbFilterStrategy;
        private System.Windows.Forms.DataGridView gridPlanned;
        private System.Windows.Forms.DataGridView gridPreds;
        private System.Windows.Forms.ContextMenuStrip ctxMenu;
        private System.Windows.Forms.ToolStripMenuItem miEdit;
        private System.Windows.Forms.ToolStripMenuItem miDelete;
        
        // Columns
        private System.Windows.Forms.DataGridViewCheckBoxColumn colEnabled;
        private System.Windows.Forms.DataGridViewTextBoxColumn colExchange;
        private System.Windows.Forms.DataGridViewTextBoxColumn colProduct;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStrategy;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSide;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEstEdge;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNotes;

        private System.Windows.Forms.DataGridViewTextBoxColumn colPredProduct;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPredTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPredHorizon;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPredDir;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPredProb;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPredExpRet;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPredExpVol;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPredKnown;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPredRDir;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPredRRet;
    }
}