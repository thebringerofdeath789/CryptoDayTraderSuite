using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Services;
using CryptoDayTraderSuite.Util;

namespace CryptoDayTraderSuite.UI
{
    public partial class AccountsControl : UserControl
    {
        private BindingSource _bs = new BindingSource();
        private IAccountService _service;

        public AccountsControl()
        {
            InitializeComponent();
            ConfigureGrid();
            WireEvents();
        }

        public void Initialize(IAccountService service)
        {
            _service = service;
            LoadData();
        }

        private void ConfigureGrid()
        {
            gridAccounts.AutoGenerateColumns = false;
            
            // Map columns to properties on AccountProfile
            colLabel.DataPropertyName = "Label";
            colService.DataPropertyName = "Service";
            colMode.DataPropertyName = "Mode";
            colRisk.DataPropertyName = "RiskPerTradePct";
            colMaxOpen.DataPropertyName = "MaxConcurrentTrades";
            colKeyId.DataPropertyName = "KeyEntryId";
            colEnabled.DataPropertyName = "Enabled";

            // Allow editing only for checkboxes
            gridAccounts.ReadOnly = false;
            foreach (DataGridViewColumn col in gridAccounts.Columns)
            {
                col.ReadOnly = true;
            }
            colEnabled.ReadOnly = false;
        }

        private void WireEvents()
        {
            btnAdd.Click += (s, e) => AddAccount();
            btnEdit.Click += (s, e) => EditSelected();
            btnDelete.Click += (s, e) => DeleteSelected();
            btnRefresh.Click += (s, e) => LoadData();
            btnSave.Click += (s, e) => SaveChanges();

            gridAccounts.DoubleClick += (s, e) => EditSelected();
            gridAccounts.CurrentCellDirtyStateChanged += GridAccounts_CurrentCellDirtyStateChanged;
        }

        private void GridAccounts_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (gridAccounts.IsCurrentCellDirty)
            {
                gridAccounts.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        public void LoadData()
        {
            if (_service == null) return;
            var accountInfos = _service.GetAll();
            var profiles = accountInfos.Select(info => (AccountProfile)info).ToList();
            
            // Use SortableBindingList to support column sorting
            _bs.DataSource = new SortableBindingList<AccountProfile>(profiles);
            gridAccounts.DataSource = _bs;
        }

        private AccountProfile Selected()
        {
            return gridAccounts.CurrentRow != null ? gridAccounts.CurrentRow.DataBoundItem as AccountProfile : null;
        }

        private void AddAccount()
        {
             if (_service == null) return;
            var dlg = new AccountEditDialog(null, _service);
            if (dlg.ShowDialog(this) == DialogResult.OK)
                LoadData();
        }

        private void EditSelected()
        {
            if (_service == null) return;
            var cur = Selected();
            if (cur == null) return;
            
            var dlg = new AccountEditDialog(cur.Id, _service);
            if (dlg.ShowDialog(this) == DialogResult.OK)
                LoadData();
        }

        private void DeleteSelected()
        {
            if (_service == null) return;
            var cur = Selected();
            if (cur == null) return;

            if (MessageBox.Show("Delete account " + cur.Label + "?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                _service.Delete(cur.Id);
                LoadData();
            }
        }

        private void SaveChanges()
        {
            if (_service == null) return;
            var data = _bs.DataSource as SortableBindingList<AccountProfile>;
            if (data == null) return;

            // Convert profiles back to Info (preserves IDs and updates Enabled/formatted fields)
            var accountInfos = data.Select(profile => (AccountInfo)profile).ToList();
            _service.ReplaceAll(accountInfos);

            MessageBox.Show("Accounts saved.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
