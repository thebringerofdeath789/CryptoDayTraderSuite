using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.UI
{
    public partial class TradingControl : UserControl
    {
        private Control chartDisplay;

        public event EventHandler LoadProductsClicked;
        public event EventHandler FeesClicked;
        public event EventHandler BacktestClicked;
        public event EventHandler PaperClicked;
        public event EventHandler LiveClicked;

        public string Exchange => cmbExchange.SelectedItem?.ToString();
        public string Product => cmbProduct.SelectedItem?.ToString();
        public string Strategy => cmbStrategy.SelectedItem?.ToString();
        public decimal Risk => numRisk.Value;
        public decimal Equity => numEquity.Value;

        public TradingControl()
        {
            InitializeComponent();
            InitializeChart();
        }

        private void InitializeChart()
        {
#if NETFRAMEWORK
            var chart = new System.Windows.Forms.DataVisualization.Charting.Chart 
            { 
                Dock = DockStyle.Fill, 
                BackColor = Color.FromArgb(32, 34, 40) 
            };
            var area = new System.Windows.Forms.DataVisualization.Charting.ChartArea("Main");
            area.BackColor = Color.FromArgb(32, 34, 40);
            area.AxisX.LabelStyle.ForeColor = Color.WhiteSmoke;
            area.AxisY.LabelStyle.ForeColor = Color.WhiteSmoke;
            area.AxisX.LineColor = Color.Gray;
            area.AxisY.LineColor = Color.Gray;
            area.AxisX.MajorGrid.LineColor = Color.FromArgb(64,64,64);
            area.AxisY.MajorGrid.LineColor = Color.FromArgb(64,64,64);
            chart.ChartAreas.Add(area);

            var series = new System.Windows.Forms.DataVisualization.Charting.Series("Candles") 
            { 
                ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Candlestick 
            };
            series["PriceUpColor"] = "Green";
            series["PriceDownColor"] = "Red";
            chart.Series.Add(series);

            chartDisplay = chart;
            this.tlMain.Controls.Add(chartDisplay, 0, 1);
#else
            var chartPanel = new Panel { Dock = DockStyle.Fill, BackColor = System.Drawing.Color.FromArgb(32, 34, 40) };
            this.tlMain.Controls.Add(chartPanel, 0, 1);
#endif
        }

        public void Log(string msg) { txtLog.AppendText(DateTime.Now.ToString("HH:mm:ss") + " " + msg + Environment.NewLine); }
        
        public void SetExchanges(IEnumerable<string> exchanges)
        {
            cmbExchange.Items.Clear();
            foreach (var e in exchanges) cmbExchange.Items.Add(e);
            if (cmbExchange.Items.Count > 0) cmbExchange.SelectedIndex = 0;
        }

        public void SetStrategies(IEnumerable<string> strategies)
        {
            cmbStrategy.Items.Clear();
            foreach (var s in strategies) cmbStrategy.Items.Add(s);
            if (cmbStrategy.Items.Count > 0) cmbStrategy.SelectedIndex = 0;
        }

        public void SetProducts(IEnumerable<string> products)
        {
            cmbProduct.Items.Clear();
            foreach (var p in products) cmbProduct.Items.Add(p);
            if (cmbProduct.Items.Count > 0) cmbProduct.SelectedIndex = 0;
        }
        
        public void SetProjections(string p100, string p1000)
        {
            lblProj100.Text = p100;
            lblProj1000.Text = p1000;
        }

        public void SetCandles(List<Candle> candles)
        {
#if NETFRAMEWORK
            var chart = chartDisplay as System.Windows.Forms.DataVisualization.Charting.Chart;
            if (chart != null)
            {
                var s = chart.Series["Candles"];
                s.Points.Clear();
                foreach (var c in candles)
                {
                    // High, Low, Open, Close
                    int i = s.Points.AddXY(c.Time.ToLocalTime(), (double)c.High);
                    s.Points[i].YValues[1] = (double)c.Low;
                    s.Points[i].YValues[2] = (double)c.Open;
                    s.Points[i].YValues[3] = (double)c.Close;
                }
                chart.ChartAreas[0].RecalculateAxesScale();
            }
#endif
        }

        /* Event Handlers linked in Designer */
        private void BtnLoadProducts_Click(object sender, EventArgs e) => LoadProductsClicked?.Invoke(this, EventArgs.Empty);
        private void BtnFees_Click(object sender, EventArgs e) => FeesClicked?.Invoke(this, EventArgs.Empty);
        private void BtnBacktest_Click(object sender, EventArgs e) => BacktestClicked?.Invoke(this, EventArgs.Empty);
        private void BtnPaper_Click(object sender, EventArgs e) => PaperClicked?.Invoke(this, EventArgs.Empty);
        private void BtnLive_Click(object sender, EventArgs e) => LiveClicked?.Invoke(this, EventArgs.Empty);
    }
}
