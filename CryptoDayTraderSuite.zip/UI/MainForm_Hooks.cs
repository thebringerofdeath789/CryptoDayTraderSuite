using System;
using System.Windows.Forms;
using CryptoDayTraderSuite.UI;

namespace CryptoDayTraderSuite
{
    public partial class MainForm : Form
    {
        public void OnShown_Hooks(object sender, EventArgs e)
        {
            try { MainFormExtraButtons.Add(this); } catch { }
        }
    }
}