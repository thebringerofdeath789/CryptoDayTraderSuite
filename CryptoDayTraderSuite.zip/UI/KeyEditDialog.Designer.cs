namespace CryptoDayTraderSuite.UI
{
    partial class KeyEditDialog
    {
        private void InitializeComponent() { }
    }
}