namespace CryptoDayTraderSuite.UI
{
    partial class AutoModeControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.topPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.lblAccount = new System.Windows.Forms.Label();
            this.cmbAccount = new System.Windows.Forms.ComboBox();
            this.lblProduct = new System.Windows.Forms.Label();
            this.cmbProduct = new System.Windows.Forms.ComboBox();
            this.lblGran = new System.Windows.Forms.Label();
            this.cmbGran = new System.Windows.Forms.ComboBox();
            this.lblLookback = new System.Windows.Forms.Label();
            this.numLookback = new System.Windows.Forms.NumericUpDown();
            this.lblEquity = new System.Windows.Forms.Label();
            this.numEquity = new System.Windows.Forms.NumericUpDown();
            this.btnScan = new System.Windows.Forms.Button();
            this.btnPropose = new System.Windows.Forms.Button();
            this.btnExecute = new System.Windows.Forms.Button();
            this.grid = new System.Windows.Forms.DataGridView();
            this.colStrategy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSymbol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGran = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colExpectancy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colWinRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAvgWin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAvgLoss = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSharpe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSamples = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayout.SuspendLayout();
            this.topPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLookback)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numEquity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayout
            // 
            this.tableLayout.ColumnCount = 1;
            this.tableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayout.Controls.Add(this.topPanel, 0, 0);
            this.tableLayout.Controls.Add(this.grid, 0, 1);
            this.tableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayout.Location = new System.Drawing.Point(0, 0);
            this.tableLayout.Name = "tableLayout";
            this.tableLayout.RowCount = 2;
            this.tableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayout.Size = new System.Drawing.Size(1200, 800);
            this.tableLayout.TabIndex = 0;
            // 
            // topPanel
            // 
            this.topPanel.AutoSize = true;
            this.topPanel.Controls.Add(this.lblAccount);
            this.topPanel.Controls.Add(this.cmbAccount);
            this.topPanel.Controls.Add(this.lblProduct);
            this.topPanel.Controls.Add(this.cmbProduct);
            this.topPanel.Controls.Add(this.lblGran);
            this.topPanel.Controls.Add(this.cmbGran);
            this.topPanel.Controls.Add(this.lblLookback);
            this.topPanel.Controls.Add(this.numLookback);
            this.topPanel.Controls.Add(this.lblEquity);
            this.topPanel.Controls.Add(this.numEquity);
            this.topPanel.Controls.Add(this.btnScan);
            this.topPanel.Controls.Add(this.btnPropose);
            this.topPanel.Controls.Add(this.btnExecute);
            this.topPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.topPanel.Location = new System.Drawing.Point(3, 3);
            this.topPanel.Name = "topPanel";
            this.topPanel.Padding = new System.Windows.Forms.Padding(8);
            this.topPanel.Size = new System.Drawing.Size(1194, 46);
            this.topPanel.TabIndex = 0;
            // 
            // lblAccount
            // 
            this.lblAccount.AutoSize = true;
            this.lblAccount.Location = new System.Drawing.Point(11, 14);
            this.lblAccount.Margin = new System.Windows.Forms.Padding(3, 6, 0, 0);
            this.lblAccount.Name = "lblAccount";
            this.lblAccount.Size = new System.Drawing.Size(50, 13);
            this.lblAccount.TabIndex = 0;
            this.lblAccount.Text = "Account:";
            // 
            // cmbAccount
            // 
            this.cmbAccount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAccount.FormattingEnabled = true;
            this.cmbAccount.Location = new System.Drawing.Point(64, 11);
            this.cmbAccount.Name = "cmbAccount";
            this.cmbAccount.Size = new System.Drawing.Size(200, 21);
            this.cmbAccount.TabIndex = 1;
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Location = new System.Drawing.Point(279, 14);
            this.lblProduct.Margin = new System.Windows.Forms.Padding(12, 6, 0, 0);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(47, 13);
            this.lblProduct.TabIndex = 2;
            this.lblProduct.Text = "Product:";
            // 
            // cmbProduct
            // 
            this.cmbProduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProduct.FormattingEnabled = true;
            this.cmbProduct.Location = new System.Drawing.Point(329, 11);
            this.cmbProduct.Name = "cmbProduct";
            this.cmbProduct.Size = new System.Drawing.Size(150, 21);
            this.cmbProduct.TabIndex = 3;
            // 
            // lblGran
            // 
            this.lblGran.AutoSize = true;
            this.lblGran.Location = new System.Drawing.Point(494, 14);
            this.lblGran.Margin = new System.Windows.Forms.Padding(12, 6, 0, 0);
            this.lblGran.Name = "lblGran";
            this.lblGran.Size = new System.Drawing.Size(57, 13);
            this.lblGran.TabIndex = 4;
            this.lblGran.Text = "Gran (min):";
            // 
            // cmbGran
            // 
            this.cmbGran.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGran.FormattingEnabled = true;
            this.cmbGran.Items.AddRange(new object[] {
            "1",
            "5",
            "15",
            "30",
            "60",
            "240"});
            this.cmbGran.Location = new System.Drawing.Point(554, 11);
            this.cmbGran.Name = "cmbGran";
            this.cmbGran.Size = new System.Drawing.Size(50, 21);
            this.cmbGran.TabIndex = 5;
            // 
            // lblLookback
            // 
            this.lblLookback.AutoSize = true;
            this.lblLookback.Location = new System.Drawing.Point(619, 14);
            this.lblLookback.Margin = new System.Windows.Forms.Padding(12, 6, 0, 0);
            this.lblLookback.Name = "lblLookback";
            this.lblLookback.Size = new System.Drawing.Size(87, 13);
            this.lblLookback.TabIndex = 6;
            this.lblLookback.Text = "Lookback (days):";
            // 
            // numLookback
            // 
            this.numLookback.Location = new System.Drawing.Point(709, 11);
            this.numLookback.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.numLookback.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numLookback.Name = "numLookback";
            this.numLookback.Size = new System.Drawing.Size(60, 20);
            this.numLookback.TabIndex = 7;
            this.numLookback.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // lblEquity
            // 
            this.lblEquity.AutoSize = true;
            this.lblEquity.Location = new System.Drawing.Point(784, 14);
            this.lblEquity.Margin = new System.Windows.Forms.Padding(12, 6, 0, 0);
            this.lblEquity.Name = "lblEquity";
            this.lblEquity.Size = new System.Drawing.Size(53, 13);
            this.lblEquity.TabIndex = 8;
            this.lblEquity.Text = "Equity ($):";
            // 
            // numEquity
            // 
            this.numEquity.Location = new System.Drawing.Point(840, 11);
            this.numEquity.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numEquity.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numEquity.Name = "numEquity";
            this.numEquity.Size = new System.Drawing.Size(80, 20);
            this.numEquity.TabIndex = 9;
            this.numEquity.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // btnScan
            // 
            this.btnScan.Location = new System.Drawing.Point(926, 11);
            this.btnScan.Name = "btnScan";
            this.btnScan.Size = new System.Drawing.Size(75, 23);
            this.btnScan.TabIndex = 10;
            this.btnScan.Text = "Scan";
            this.btnScan.UseVisualStyleBackColor = true;
            // 
            // btnPropose
            // 
            this.btnPropose.Location = new System.Drawing.Point(1007, 11);
            this.btnPropose.Name = "btnPropose";
            this.btnPropose.Size = new System.Drawing.Size(75, 23);
            this.btnPropose.TabIndex = 11;
            this.btnPropose.Text = "Propose";
            this.btnPropose.UseVisualStyleBackColor = true;
            // 
            // btnExecute
            // 
            this.btnExecute.Location = new System.Drawing.Point(1088, 11);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(75, 23);
            this.btnExecute.TabIndex = 12;
            this.btnExecute.Text = "Execute";
            this.btnExecute.UseVisualStyleBackColor = true;
            // 
            // grid
            // 
            this.grid.AllowUserToAddRows = false;
            this.grid.AllowUserToDeleteRows = false;
            this.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colStrategy,
            this.colSymbol,
            this.colGran,
            this.colExpectancy,
            this.colWinRate,
            this.colAvgWin,
            this.colAvgLoss,
            this.colSharpe,
            this.colSamples});
            this.grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid.Location = new System.Drawing.Point(3, 55);
            this.grid.Name = "grid";
            this.grid.ReadOnly = true;
            this.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid.Size = new System.Drawing.Size(1194, 742);
            this.grid.TabIndex = 1;
            // 
            // colStrategy
            // 
            this.colStrategy.DataPropertyName = "Strategy";
            this.colStrategy.FillWeight = 200F;
            this.colStrategy.HeaderText = "Strategy";
            this.colStrategy.Name = "colStrategy";
            this.colStrategy.ReadOnly = true;
            this.colStrategy.Width = 200;
            // 
            // colSymbol
            // 
            this.colSymbol.DataPropertyName = "Symbol";
            this.colSymbol.HeaderText = "Symbol";
            this.colSymbol.Name = "colSymbol";
            this.colSymbol.ReadOnly = true;
            this.colSymbol.Width = 120;
            // 
            // colGran
            // 
            this.colGran.DataPropertyName = "GranMinutes";
            this.colGran.HeaderText = "Granularity";
            this.colGran.Name = "colGran";
            this.colGran.ReadOnly = true;
            this.colGran.Width = 80;
            // 
            // colExpectancy
            // 
            this.colExpectancy.DataPropertyName = "Expectancy";
            this.colExpectancy.HeaderText = "Expectancy";
            this.colExpectancy.Name = "colExpectancy";
            this.colExpectancy.ReadOnly = true;
            this.colExpectancy.Width = 110;
            // 
            // colWinRate
            // 
            this.colWinRate.DataPropertyName = "WinRate";
            this.colWinRate.HeaderText = "Win%";
            this.colWinRate.Name = "colWinRate";
            this.colWinRate.ReadOnly = true;
            this.colWinRate.Width = 80;
            // 
            // colAvgWin
            // 
            this.colAvgWin.DataPropertyName = "AvgWin";
            this.colAvgWin.HeaderText = "AvgWin";
            this.colAvgWin.Name = "colAvgWin";
            this.colAvgWin.ReadOnly = true;
            this.colAvgWin.Width = 90;
            // 
            // colAvgLoss
            // 
            this.colAvgLoss.DataPropertyName = "AvgLoss";
            this.colAvgLoss.HeaderText = "AvgLoss";
            this.colAvgLoss.Name = "colAvgLoss";
            this.colAvgLoss.ReadOnly = true;
            this.colAvgLoss.Width = 90;
            // 
            // colSharpe
            // 
            this.colSharpe.DataPropertyName = "SharpeApprox";
            this.colSharpe.HeaderText = "Sharpe";
            this.colSharpe.Name = "colSharpe";
            this.colSharpe.ReadOnly = true;
            this.colSharpe.Width = 80;
            // 
            // colSamples
            // 
            this.colSamples.DataPropertyName = "Samples";
            this.colSamples.HeaderText = "Samples";
            this.colSamples.Name = "colSamples";
            this.colSamples.ReadOnly = true;
            this.colSamples.Width = 80;
            // 
            // AutoModeControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayout);
            this.Name = "AutoModeControl";
            this.Size = new System.Drawing.Size(1200, 800);
            this.tableLayout.ResumeLayout(false);
            this.tableLayout.PerformLayout();
            this.topPanel.ResumeLayout(false);
            this.topPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLookback)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numEquity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayout;
        private System.Windows.Forms.FlowLayoutPanel topPanel;
        private System.Windows.Forms.Label lblAccount;
        private System.Windows.Forms.ComboBox cmbAccount;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.ComboBox cmbProduct;
        private System.Windows.Forms.Label lblGran;
        private System.Windows.Forms.ComboBox cmbGran;
        private System.Windows.Forms.Label lblLookback;
        private System.Windows.Forms.NumericUpDown numLookback;
        private System.Windows.Forms.Label lblEquity;
        private System.Windows.Forms.NumericUpDown numEquity;
        private System.Windows.Forms.Button btnScan;
        private System.Windows.Forms.Button btnPropose;
        private System.Windows.Forms.Button btnExecute;
        private System.Windows.Forms.DataGridView grid;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStrategy;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSymbol;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGran;
        private System.Windows.Forms.DataGridViewTextBoxColumn colExpectancy;
        private System.Windows.Forms.DataGridViewTextBoxColumn colWinRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAvgWin;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAvgLoss;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSharpe;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSamples;
    }
}