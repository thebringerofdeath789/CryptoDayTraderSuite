using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Services;

namespace CryptoDayTraderSuite.UI
{
    public partial class PlannerControl : UserControl
    {
        private IHistoryService _historyService;
        private List<TradeRecord> _planned = new List<TradeRecord>();
        private List<PredictionRecord> _preds = new List<PredictionRecord>();

        public PlannerControl()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            
            // Wire events
            if (btnRefresh != null) btnRefresh.Click += (s, e) => LoadData();
            if (btnSave != null) btnSave.Click += (s, e) => SaveData();
            if (btnAdd != null) btnAdd.Click += (s, e) => AddTrade();
            
            if (cmbFilterProduct != null) cmbFilterProduct.SelectedIndexChanged += (s, e) => ApplyFilters();
            if (cmbFilterStrategy != null) cmbFilterStrategy.SelectedIndexChanged += (s, e) => ApplyFilters();
            
            if (gridPlanned != null)
            {
                gridPlanned.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) EditSelectedTrade(); };
            }
                
            // Context menu wiring
            if (miEdit != null) miEdit.Click += (s, e) => EditSelectedTrade();
            if (miDelete != null) miDelete.Click += (s, e) => DeleteSelectedTrade();
        }

        public void Initialize(IHistoryService historyService)
        {
            _historyService = historyService;
            LoadData();
        }

        private void LoadData()
        {
            if (_historyService == null) return;

            _planned = _historyService.LoadPlannedTrades() ?? new List<TradeRecord>();
            _preds = _historyService.LoadPredictions() ?? new List<PredictionRecord>();

            // Populate filters
            var products = _planned.Select(p => p.ProductId).Distinct().OrderBy(x => x).ToList();
            
            string currentProd = cmbFilterProduct.SelectedItem as string;
            cmbFilterProduct.Items.Clear();
            cmbFilterProduct.Items.Add("All");
            cmbFilterProduct.Items.AddRange(products.ToArray());
            if (currentProd != null && cmbFilterProduct.Items.Contains(currentProd))
                cmbFilterProduct.SelectedItem = currentProd;
            else
                cmbFilterProduct.SelectedIndex = 0;

            var strategies = _planned.Select(p => p.Strategy).Distinct().OrderBy(x => x).ToList();
            string currentStrat = cmbFilterStrategy.SelectedItem as string;
            cmbFilterStrategy.Items.Clear();
            cmbFilterStrategy.Items.Add("All");
            cmbFilterStrategy.Items.AddRange(strategies.ToArray());
            if (currentStrat != null && cmbFilterStrategy.Items.Contains(currentStrat))
                cmbFilterStrategy.SelectedItem = currentStrat;
            else
                cmbFilterStrategy.SelectedIndex = 0;

            ApplyFilters();

            gridPreds.Rows.Clear();
            foreach (var r in _preds.OrderByDescending(x => x.AtUtc).Take(500))
            {
                gridPreds.Rows.Add(r.ProductId, r.AtUtc.ToLocalTime(), r.HorizonMinutes, r.Direction, r.Probability, r.ExpectedReturn, r.ExpectedVol, r.RealizedKnown, r.RealizedDirection, r.RealizedReturn);
            }
        }
        
        private List<TradeRecord> GetFilteredPlanned()
        {
            string prod = cmbFilterProduct.SelectedItem?.ToString();
            string strat = cmbFilterStrategy.SelectedItem?.ToString();
            return _planned.Where(p =>
                (prod == "All" || string.IsNullOrEmpty(prod) || p.ProductId == prod) &&
                (strat == "All" || string.IsNullOrEmpty(strat) || p.Strategy == strat)).OrderByDescending(x => x.AtUtc).ToList();
        }

        private void ApplyFilters()
        {
            if (_planned == null) return;
            
            var filtered = GetFilteredPlanned();
            gridPlanned.Rows.Clear();
            foreach (var p in filtered)
            {
                gridPlanned.Rows.Add(p.Enabled, p.Exchange, p.ProductId, p.Strategy, p.Side, p.Quantity, p.Price, p.EstEdge, p.Notes);
            }
        }

        private void SaveData()
        {
            if (_historyService == null) return;

            var filtered = GetFilteredPlanned();

            if (gridPlanned.Rows.Count != filtered.Count)
            {
                // Simple safeguard: If filter mismatches grid rows, abort save to avoid corruption
                 MessageBox.Show("Filter mismatch error. Reloading.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                LoadData();
                return;
            }

            for (int i = 0; i < gridPlanned.Rows.Count; i++)
            {
                var row = gridPlanned.Rows[i];
                var p = filtered[i];
                p.Enabled = Convert.ToBoolean(row.Cells[0].Value ?? false);
                p.Quantity = Convert.ToDecimal(row.Cells[5].Value ?? 0m);
                p.Price = Convert.ToDecimal(row.Cells[6].Value ?? 0m);
                p.Notes = row.Cells[8].Value?.ToString();
            }
            
            _historyService.SavePlannedTrades(_planned);
            MessageBox.Show("Planner updated", "Planner", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void AddTrade()
        {
            var dlg = new TradeEditDialog();
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                _planned.Add(dlg.Result);
                SaveData();
                LoadData();
            }
        }

        private void EditSelectedTrade()
        {
            if (gridPlanned.SelectedRows.Count == 0) return;
            var idx = gridPlanned.SelectedRows[0].Index;
            var filtered = GetFilteredPlanned();
            if (idx < 0 || idx >= filtered.Count) return;
            var rec = filtered[idx];
            
            var dlg = new TradeEditDialog(rec);
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                // Update the original record in _planned
                // Since rec is a reference from _planned (via LINQ), updating it updates the list reference.
                // However, let's just create a new one to be safe if TradeRecord is struct (it's class though).
                // Actually assuming TradeRecord is a class.
                
                rec.Enabled = dlg.Result.Enabled;
                rec.Quantity = dlg.Result.Quantity;
                rec.Price = dlg.Result.Price;
                rec.Notes = dlg.Result.Notes;
                
                SaveData();
                LoadData();
            }
        }

        private void DeleteSelectedTrade()
        {
            if (gridPlanned.SelectedRows.Count == 0) return;
            var idx = gridPlanned.SelectedRows[0].Index;
            var filtered = GetFilteredPlanned();
            if (idx < 0 || idx >= filtered.Count) return;
            var rec = filtered[idx];
            
            if (MessageBox.Show($"Delete planned trade for {rec.ProductId} ({rec.Strategy})?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                _planned.Remove(rec);
                SaveData();
                LoadData();
            }
        }
    }
}
