using System;
using System.Windows.Forms;

namespace CryptoDayTraderSuite.UI
{
    public partial class SettingsForm : Form
    {
        public SettingsForm()
        {
            InitializeComponent();
        }
    }
}