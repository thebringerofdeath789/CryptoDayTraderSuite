using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Threading.Tasks;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Exchanges;
using CryptoDayTraderSuite.Services;
using CryptoDayTraderSuite.Brokers;

namespace CryptoDayTraderSuite.UI
{
    public partial class AutoModeControl : UserControl
    {
        private List<ProjectionRow> _last;
        private List<AccountInfo> _accounts;
        private List<TradePlan> _queued;
        
        private AutoPlannerService _planner;
        private IExchangeClient _client;
        private IAccountService _accountService;

        public AutoModeControl()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            
            // Wire events
            if (btnScan != null) btnScan.Click += (s, e) => DoScan();
            if (btnPropose != null) btnPropose.Click += (s, e) => DoPropose();
            if (btnExecute != null) btnExecute.Click += (s, e) => DoExecute();
            
            // Set defaults if designer didn't
            if (cmbGran != null && cmbGran.Items.Count > 0 && cmbGran.SelectedIndex < 0) 
                cmbGran.SelectedIndex = 2; // Default to 15m
        }

        public void Initialize(AutoPlannerService planner, IExchangeClient client, IAccountService accountService)
        {
            _planner = planner;
            _client = client;
            _accountService = accountService;
            
            if (_client != null) LoadProducts();
            LoadAccounts();
        }

        private void LoadAccounts()
        {
            if (_accountService == null) return;
            _accounts = _accountService.GetAll()
                .Where(a => a.Enabled)
                .ToList();
            
            if (cmbAccount == null) return;
            cmbAccount.Items.Clear();
            foreach (var a in _accounts)
                cmbAccount.Items.Add($"{a.Label} [{a.Service}]");
            if (cmbAccount.Items.Count > 0)
                cmbAccount.SelectedIndex = 0;
        }

        private async void LoadProducts()
        {
            try
            {
                // Prefer injected client, fallback to public
                List<string> prods;
                if (_client != null) prods = await _client.ListProductsAsync();
                else prods = await new CoinbasePublicClient().GetProductsAsync();

                if (cmbProduct == null) return;
                cmbProduct.Items.Clear();
                foreach (var p in prods.Where(p => p.Contains("USD")))
                    cmbProduct.Items.Add(p);
                    
                if (cmbProduct.Items.Count > 0)
                    cmbProduct.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                if (!this.IsDisposed)
                    MessageBox.Show("Failed to load products: " + ex.Message, "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void DoScan()
        {
            if (cmbProduct.SelectedItem == null) return;
            var symbol = cmbProduct.SelectedItem.ToString();
            
            if (!int.TryParse(cmbGran.SelectedItem?.ToString(), out int gran)) gran = 60;
            
            btnScan.Enabled = false;
            try
            {
                if (_planner == null) throw new InvalidOperationException("AutoPlannerService not initialized");

                var lookbackMins = (int)numLookback.Value * 1440; // days -> mins
                // Assuming maker=0.004, taker=0.006 hardcoded for estimates
                var rows = await _planner.ProjectAsync(symbol, gran, lookbackMins, 0.006m, 0.004m);
                _last = rows;
                grid.DataSource = rows;
                
                if (rows.Count == 0)
                     MessageBox.Show("No profitable strategies found or not enough data.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Scan error: " + ex.Message);
            }
            finally
            {
                if (!this.IsDisposed) btnScan.Enabled = true;
            }
        }

        private async void DoPropose()
        {
             if (_last == null || _last.Count == 0 || cmbAccount.SelectedIndex < 0) return;
             // Ensure _accounts index is valid
             if (cmbAccount.SelectedIndex >= _accounts.Count) return;
             
             var acc = _accounts[cmbAccount.SelectedIndex];
             var symbol = cmbProduct.SelectedItem.ToString();
             if (!int.TryParse(cmbGran.SelectedItem?.ToString(), out int gran)) gran = 60;

             btnPropose.Enabled = false;
             try
             {
                 if (_planner == null) throw new InvalidOperationException("AutoPlannerService not initialized");

                 _queued = await _planner.ProposeAsync(acc.Id, symbol, gran, numEquity.Value, acc.RiskPerTradePct, _last);
                 
                 if (_queued.Count > 0)
                 {
                     var msg = string.Join(Environment.NewLine, _queued.Select(p => $"{p.Strategy} {p.Direction} {p.Qty} @ {p.Entry} (Note: {p.Note})"));
                     MessageBox.Show("Proposed:\n" + msg);
                 }
                 else
                 {
                     MessageBox.Show("No valid trades proposed (Check risk limits or AI veto).");
                 }
             }
             catch (Exception ex)
             {
                 MessageBox.Show("Proposal error: " + ex.Message);
             }
             finally
             {
                 if (!this.IsDisposed) btnPropose.Enabled = true;
             }
        }

        private async void DoExecute()
        {
             // ... placeholder ...
             MessageBox.Show("Execution logic placeholder. Not implemented yet.");
             await Task.CompletedTask;
        }
    }
}
