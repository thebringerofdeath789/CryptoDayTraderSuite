namespace CryptoDayTraderSuite.UI
{
    partial class TradingControl
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        private void InitializeComponent()
        {
            this.tlMain = new System.Windows.Forms.TableLayoutPanel();
            this.pnlTop = new System.Windows.Forms.FlowLayoutPanel();
            this.lblExchange = new System.Windows.Forms.Label();
            this.cmbExchange = new System.Windows.Forms.ComboBox();
            this.lblProduct = new System.Windows.Forms.Label();
            this.cmbProduct = new System.Windows.Forms.ComboBox();
            this.btnLoadProducts = new System.Windows.Forms.Button();
            this.btnFees = new System.Windows.Forms.Button();
            this.lblStrategy = new System.Windows.Forms.Label();
            this.cmbStrategy = new System.Windows.Forms.ComboBox();
            this.lblRisk = new System.Windows.Forms.Label();
            this.numRisk = new System.Windows.Forms.NumericUpDown();
            this.lblEquity = new System.Windows.Forms.Label();
            this.numEquity = new System.Windows.Forms.NumericUpDown();
            this.btnBacktest = new System.Windows.Forms.Button();
            this.btnPaper = new System.Windows.Forms.Button();
            this.btnLive = new System.Windows.Forms.Button();
            this.lblProj100 = new System.Windows.Forms.Label();
            this.lblProj1000 = new System.Windows.Forms.Label();
            this.txtLog = new System.Windows.Forms.TextBox();
            
            this.tlMain.SuspendLayout();
            this.pnlTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRisk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numEquity)).BeginInit();
            this.SuspendLayout();

            /* tlMain */
            this.tlMain.ColumnCount = 1;
            this.tlMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlMain.Controls.Add(this.pnlTop, 0, 0);
            this.tlMain.Controls.Add(this.txtLog, 0, 2);
            this.tlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlMain.RowCount = 3;
            this.tlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.AutoSize));
            this.tlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tlMain.Name = "tlMain";

            /* pnlTop */
            this.pnlTop.AutoSize = true;
            this.pnlTop.Controls.Add(this.lblExchange);
            this.pnlTop.Controls.Add(this.cmbExchange);
            this.pnlTop.Controls.Add(this.lblProduct);
            this.pnlTop.Controls.Add(this.cmbProduct);
            this.pnlTop.Controls.Add(this.btnLoadProducts);
            this.pnlTop.Controls.Add(this.btnFees);
            this.pnlTop.Controls.Add(this.lblStrategy);
            this.pnlTop.Controls.Add(this.cmbStrategy);
            this.pnlTop.Controls.Add(this.lblRisk);
            this.pnlTop.Controls.Add(this.numRisk);
            this.pnlTop.Controls.Add(this.lblEquity);
            this.pnlTop.Controls.Add(this.numEquity);
            this.pnlTop.Controls.Add(this.btnBacktest);
            this.pnlTop.Controls.Add(this.btnPaper);
            this.pnlTop.Controls.Add(this.btnLive);
            this.pnlTop.Controls.Add(this.lblProj100);
            this.pnlTop.Controls.Add(this.lblProj1000);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Padding = new System.Windows.Forms.Padding(8);
            this.pnlTop.Name = "pnlTop";

            /* Controls Config */
            this.lblExchange.AutoSize = true;
            this.lblExchange.Padding = new System.Windows.Forms.Padding(0, 6, 8, 0);
            this.lblExchange.Text = "Exchange";
            
            this.cmbExchange.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbExchange.Width = 120;
            
            this.lblProduct.AutoSize = true;
            this.lblProduct.Padding = new System.Windows.Forms.Padding(12, 6, 8, 0);
            this.lblProduct.Text = "Product";
            
            this.cmbProduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProduct.Width = 120;
            
            this.btnLoadProducts.Text = "Load Products";
            this.btnLoadProducts.Click += new System.EventHandler(this.BtnLoadProducts_Click);
            
            this.btnFees.Text = "Get Fees";
            this.btnFees.Click += new System.EventHandler(this.BtnFees_Click);
            
            this.lblStrategy.AutoSize = true;
            this.lblStrategy.Padding = new System.Windows.Forms.Padding(12, 6, 8, 0);
            this.lblStrategy.Text = "Strategy";

            this.cmbStrategy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStrategy.Width = 120;
            
            this.lblRisk.AutoSize = true;
            this.lblRisk.Padding = new System.Windows.Forms.Padding(12, 6, 8, 0);
            this.lblRisk.Text = "Risk %";

            this.numRisk.Minimum = 1;
            this.numRisk.Maximum = 100;
            this.numRisk.Value = 2;
            this.numRisk.Width = 60;
            
            this.lblEquity.AutoSize = true;
            this.lblEquity.Padding = new System.Windows.Forms.Padding(12, 6, 8, 0);
            this.lblEquity.Text = "Equity $";

            this.numEquity.Minimum = 10;
            this.numEquity.Maximum = 1000000;
            this.numEquity.Value = 1000;
            this.numEquity.Width = 80;
            
            this.btnBacktest.Text = "Backtest";
            this.btnBacktest.Click += new System.EventHandler(this.BtnBacktest_Click);
            
            this.btnPaper.Text = "Paper Trade";
            this.btnPaper.Click += new System.EventHandler(this.BtnPaper_Click);
            
            this.btnLive.Text = "Live Trade";
            this.btnLive.Click += new System.EventHandler(this.BtnLive_Click);

            this.lblProj100.AutoSize = true;
            this.lblProj100.Padding = new System.Windows.Forms.Padding(8, 6, 0, 0);
            this.lblProj100.Text = " projection: ";

            this.lblProj1000.AutoSize = true;
            this.lblProj1000.Padding = new System.Windows.Forms.Padding(8, 6, 0, 0);
            this.lblProj1000.Text = " projection: ";

            /* txtLog */
            this.txtLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLog.Font = new System.Drawing.Font("Consolas", 9F);
            this.txtLog.Multiline = true;
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLog.Name = "txtLog";

            /* this */
            this.Controls.Add(this.tlMain);
            this.Name = "TradingControl";
            this.Size = new System.Drawing.Size(900, 600);
            
            this.tlMain.ResumeLayout(false);
            this.tlMain.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRisk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numEquity)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tlMain;
        private System.Windows.Forms.FlowLayoutPanel pnlTop;
        private System.Windows.Forms.Label lblExchange;
        private System.Windows.Forms.ComboBox cmbExchange;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.ComboBox cmbProduct;
        private System.Windows.Forms.Button btnLoadProducts;
        private System.Windows.Forms.Button btnFees;
        private System.Windows.Forms.Label lblStrategy;
        private System.Windows.Forms.ComboBox cmbStrategy;
        private System.Windows.Forms.Label lblRisk;
        private System.Windows.Forms.NumericUpDown numRisk;
        private System.Windows.Forms.Label lblEquity;
        private System.Windows.Forms.NumericUpDown numEquity;
        private System.Windows.Forms.Button btnBacktest;
        private System.Windows.Forms.Button btnPaper;
        private System.Windows.Forms.Button btnLive;
        private System.Windows.Forms.Label lblProj100;
        private System.Windows.Forms.Label lblProj1000;
        private System.Windows.Forms.TextBox txtLog;
    }
}