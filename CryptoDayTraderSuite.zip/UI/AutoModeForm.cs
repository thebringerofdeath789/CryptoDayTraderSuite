using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using CryptoDayTraderSuite.Models;
using CryptoDayTraderSuite.Exchanges;
using CryptoDayTraderSuite.Services;
using CryptoDayTraderSuite.Brokers;

namespace CryptoDayTraderSuite.UI
{
    public partial class AutoModeForm : Form
    {
        protected ComboBox cmbProduct, cmbGran, cmbAccount;
        protected NumericUpDown numLookback, numEquity;
        protected DataGridView grid;
        protected Button btnScan, btnPropose, btnExecute;

        private List<ProjectionRow> _last;
        private List<AccountInfo> _accounts;
        private List<TradePlan> _queued;
        
        private readonly AutoPlannerService _planner;
        private readonly IExchangeClient _client; /* injected */
        private readonly IKeyService _keyService;
        private readonly IAccountService _accountService;

        public AutoModeForm(AutoPlannerService planner, IExchangeClient client, IKeyService keyService, IAccountService accountService)
        {
            _planner = planner ?? throw new ArgumentNullException(nameof(planner));
            _client = client; 
            _keyService = keyService ?? throw new ArgumentNullException(nameof(keyService));
            _accountService = accountService ?? throw new ArgumentNullException(nameof(accountService));
            
            InitializeComponent();
            BuildUi();
            LoadAccounts();
            LoadProducts();
        }

        private void BuildUi()
        {
            this.Text = "Automatic Mode";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Width = 980;
            this.Height = 640;

            var tl = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
            tl.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            tl.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            this.Controls.Add(tl);

            var top = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(8) };
            tl.Controls.Add(top, 0, 0);

            top.Controls.Add(new Label { Text = "Account", AutoSize = true, Padding = new Padding(0, 6, 8, 0) });
            cmbAccount = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 200 };
            top.Controls.Add(cmbAccount);

            top.Controls.Add(new Label { Text = "Product", AutoSize = true, Padding = new Padding(12, 6, 8, 0) });
            cmbProduct = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 180 };
            top.Controls.Add(cmbProduct);

            top.Controls.Add(new Label { Text = "Gran (min)", AutoSize = true, Padding = new Padding(12, 6, 8, 0) });
            cmbGran = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbGran.Items.AddRange(new object[] { "1", "5", "15", "30", "60", "240" });
            cmbGran.SelectedIndex = 2;
            top.Controls.Add(cmbGran);

            top.Controls.Add(new Label { Text = "Lookback (days)", AutoSize = true, Padding = new Padding(12, 6, 8, 0) });
            numLookback = new NumericUpDown { Minimum = 5, Maximum = 120, Value = 30 };
            top.Controls.Add(numLookback);

            top.Controls.Add(new Label { Text = "Equity ($)", AutoSize = true, Padding = new Padding(12, 6, 8, 0) });
            numEquity = new NumericUpDown { Minimum = 10, Maximum = 1000000, Value = 1000 };
            top.Controls.Add(numEquity);

            btnScan = new Button { Text = "Scan" };
            btnScan.Click += (s, e) => DoScan();
            top.Controls.Add(btnScan);

            btnPropose = new Button { Text = "Propose" };
            btnPropose.Click += (s, e) => DoPropose();
            top.Controls.Add(btnPropose);

            btnExecute = new Button { Text = "Execute" };
            btnExecute.Click += (s, e) => DoExecute();
            top.Controls.Add(btnExecute);

            grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AutoGenerateColumns = false,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Strategy", HeaderText = "Strategy", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill, FillWeight = 200 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Symbol", HeaderText = "Symbol", Width = 120 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "GranMinutes", HeaderText = "Granularity", Width = 80 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Expectancy", HeaderText = "Expectancy", Width = 110 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "WinRate", HeaderText = "Win%", Width = 80 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "AvgWin", HeaderText = "AvgWin", Width = 90 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "AvgLoss", HeaderText = "AvgLoss", Width = 90 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "SharpeApprox", HeaderText = "Sharpe", Width = 80 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Samples", HeaderText = "Samples", Width = 80 });
            tl.Controls.Add(grid, 0, 1);

            AfterBuildUi();
        }

        private void LoadAccounts()
        {
            _accounts = _accountService.GetAll()
                .Where(a => a.Enabled)
                .ToList();
            cmbAccount.Items.Clear();
            foreach (var a in _accounts)
                cmbAccount.Items.Add($"{a.Label} [{a.Service}]");
            if (cmbAccount.Items.Count > 0)
                cmbAccount.SelectedIndex = 0;
        }

        private async void LoadProducts()
        {
            try
            {
                List<string> prods;
                if (_client != null) prods = await _client.ListProductsAsync();
                else prods = await new CoinbasePublicClient().GetProductsAsync();

                cmbProduct.Items.Clear();
                foreach (var p in prods)
                    cmbProduct.Items.Add(p);
                if (cmbProduct.Items.Count > 0)
                    cmbProduct.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                if (!this.IsDisposed)
                    MessageBox.Show("Failed to load products: " + ex.Message, "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void DoScan()
        {
            if (cmbProduct.SelectedItem == null)
            {
                MessageBox.Show("Select a product.", "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var symbol = cmbProduct.SelectedItem.ToString();
            var gran = int.Parse(cmbGran.SelectedItem.ToString());
            btnScan.Enabled = false;
            try
            {
                if (_planner != null)
                {
                    var lookbackMins = (int)numLookback.Value * 1440;
                    var rows = await _planner.ProjectAsync(symbol, gran, lookbackMins, 0.006m, 0.004m);
                    _last = rows;
                    grid.DataSource = rows;
                }
                else
                {
                   throw new InvalidOperationException("AutoPlannerService not initialized. Please restart via Program.cs composition root.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Scan error: " + ex.Message, "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally 
            {
                btnScan.Enabled = true;
            }
        }

        private async void DoPropose()
        {
            if (_last == null || _last.Count == 0)
            {
                MessageBox.Show("Scan first.", "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (cmbAccount.SelectedIndex < 0)
            {
                MessageBox.Show("Select account.", "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var acc = _accounts[cmbAccount.SelectedIndex];
            var symbol = cmbProduct.SelectedItem.ToString();
            var gran = int.Parse(cmbGran.SelectedItem.ToString());
            
            btnPropose.Enabled = false;
            try
            {
                if (_planner != null)
                {
                    var plans = await _planner.ProposeAsync(acc.Id, symbol, gran, numEquity.Value, acc.RiskPerTradePct, _last);
                     if (plans.Count == 0)
                    {
                        MessageBox.Show("No trades proposed.", "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    var msg = string.Join(Environment.NewLine, plans.Select(p =>
                        $"{p.Strategy} {p.Symbol} dir={(p.Direction > 0 ? "LONG" : "SHORT")} qty={p.Qty} entry={p.Entry} stop={p.Stop} target={p.Target} Note={p.Note}"));
                    MessageBox.Show("Proposed:\n" + msg, "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    _queued = plans;
                }
                else
                {
                   throw new InvalidOperationException("AutoPlannerService not initialized.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Propose error: " + ex.Message, "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnPropose.Enabled = true;
            }
        }

        private async void DoExecute()
        {
            if (_queued == null || _queued.Count == 0)
            {
                MessageBox.Show("Nothing to execute.", "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (cmbAccount.SelectedIndex < 0)
            {
                MessageBox.Show("Select account.", "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var acc = _accounts[cmbAccount.SelectedIndex];

            if (acc.Mode != AccountMode.Paper)
            {
                var keyId = acc.KeyEntryId;
                if (string.IsNullOrEmpty(keyId) || _keyService.Get(keyId) == null)
                {
                    MessageBox.Show("No valid API key for selected account.", "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            IBroker broker = BrokerFactory.GetBroker(acc.Service, acc.Mode, _keyService, _accountService);

            if (broker == null)
            {
                MessageBox.Show("Unsupported broker: " + acc.Service, "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            btnExecute.Enabled = false;
            try
            {
                foreach (var p in _queued)
                {
                    if (p.AccountId != acc.Id) continue;
                    var r = await broker.PlaceOrderAsync(p);
                    MessageBox.Show((r.ok ? "ok: " : "err: ") + r.message, "Auto Mode", MessageBoxButtons.OK, r.ok ? MessageBoxIcon.Information : MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Execution error: " + ex.Message, "Auto Mode", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnExecute.Enabled = true;
            }
        }
        partial void AfterBuildUi();
    }

    public static class BrokerFactory
    {
        public static IBroker GetBroker(string service, AccountMode mode, IKeyService keyService, IAccountService accountService)
        {
            if (string.IsNullOrEmpty(service))
                throw new ArgumentNullException(nameof(service));

            if (mode == AccountMode.Paper || service.Equals("paper", StringComparison.OrdinalIgnoreCase))
                return new PaperBroker();

            switch (service.ToLowerInvariant())
            {
                case "coinbase-exchange":
                    return new CoinbaseExchangeBroker(keyService, accountService);
                default:
                    return null;
            }
        }
    }
}
