
using System;

namespace CryptoDayTraderSuite.Models
{
    public class Candle
    {
        public DateTime Time { get; set; } /* candle time */
        public decimal Open { get; set; } /* o */
        public decimal High { get; set; } /* h */
        public decimal Low { get; set; } /* l */
        public decimal Close { get; set; } /* c */
        public decimal Volume { get; set; } /* v */
    }

    public class Ticker
    {
        public decimal Bid { get; set; } /* bid */
        public decimal Ask { get; set; } /* ask */
        public decimal Last { get; set; } /* last */
        public DateTime Time { get; set; } /* time */
    }
}
