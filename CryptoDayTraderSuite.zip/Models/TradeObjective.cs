namespace CryptoDayTraderSuite.Models
{
    public enum TradeObjective { USDGrowth = 0, CoinAccumulation = 1 }
}