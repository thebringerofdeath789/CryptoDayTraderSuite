# CryptoDayTraderSuite Documentation Index

## Overview
*   [**Trading Principles**](overview/TradingPrinciples.md): The core philosophy and design principles (Edges, Risk, Modularity).

## Architecture
*   [**System Map**](architecture/SystemMap.md): The core architectural definition. Defines the "Modular Service-Oriented Kernel" pattern, layer responsibilities, and coding standards. **READ THIS FIRST**.
*   [**AI Integration Plan**](architecture/AI_Integration_Plan.md): Technical specification for the "Chrome Sidecar" AI integration.
*   [**Architecture Audit 2026**](architecture/Architecture_Audit_2026.md): Analysis of the legacy monolithic state and the plan for refactoring.
*   [**Startup Flow**](architecture/StartupFlow.md): Detailed sequence of the application initialization process.
*   [**Data Flow**](architecture/DataFlow.md): Map of how market data propagates through the system.

## Features
*   [**Feature Index**](features/FeatureIndex.md): Index of functional features.
*   [**Trading Playbook**](features/trading/Regime_Playbook.md): Regime Analysis, Examples, and Scenarios.
*   [**Strategies**](features/trading/Strategies.md): Detailed logic for ORB, VWAP, Donchian, etc.
*   [**Governance**](features/trading/Governance.md): Rules for strategy enabling/disabling.
*   [**Auto Planner**](features/trading/AutoPlanner.md): Automated scanning and ranking.
*   [**Risk Management**](features/trading/RiskManagement.md): Sizing, Stops, and Guards.
*   [**Backtesting**](features/trading/Backtesting.md): Simulation engine details.
*   [**Machine Learning**](features/trading/MachineLearning.md): The Logistic Regression Prediction Engine.
*   [**Exchanges**](features/trading/Exchanges.md): API Client details.
*   [**Brokers**](features/trading/Brokers.md): Execution brokers.
*   [**AI Workflow**](features/ai/AI_Workflow.md): Guide to using the Chrome Sidecar AI integration.
*   [**Theming**](features/ui/Theming.md): Customizing the UI look and feel.

## UI & Experience
*   [**Refactor Plan**](ui/UI_Refactor_Plan.md): Modernization roadmap (Sidebar, Dark Theme).
*   [**Usage Guide**](ui/UsageGuide.md): User guide for the application shell.

## Operations
*   [**Changelog**](CHANGELOG.md): Project history and version tracking.
*   [**Configuration**](ops/Configuration.md): Guide to application settings and secrets management.
*   [**Roadmap**](../ROADMAP.md): High-level project goals and phase tracking.
*   [**Progress Tracker**](../PROGRESS_TRACKER.md): Granular task tracking.

## Development
*   [**Contributing Guide**](contributing/Contributing.md): Code standards and how to contribute.
*   [**Issue Templates**](contributing/IssueTemplates.md): Formats for bug reports.
*   [**Copilot Instructions**](../.github/copilot-instructions.md): Rules and guidelines for AI assistants working on this repo.
