# Changelog

## [Phase 15] - Logging & Reliability - 2026-02-15

### Enhanced
- **Logging System**: Upgraded `Util/Log.cs` to output to both Console (for development) and Debug listeners (for Visual Studio).
- **Network Tracing**: Added detailed Request/Response tracing to `Util/HttpUtil.cs`.
- **Service Integration**: Instrumented `Services/ChromeSidecar.cs` and `Services/AIGovernor.cs` to utilize the central logging infrastructure.
- **Startup**: Configured `Program.cs` to initialize logging at `Debug` level for better visibility.
- **Profile Service**: Added logging to Import/Export operations.

## [Phase 14] - Deep Clean & Quality Assurance - 2026-02-14

### Fixed
- **Critical Architecture**: Discovered and fixed `UI/PlannerControl.cs` referencing the decommissioned `HistoryStore` static class. Refactored to use injected `IHistoryService`.
- **UI Policy Violation**: Refactored `UI/PlannerControl.cs`, `UI/AutoModeControl.cs`, and `UI/TradeEditDialog.cs` to use proper `.Designer.cs` files, adhering to "No Programmatic Layouts" policy.
- **Dead Code**: Removed `UI/MainFormPlannerButton.cs` which used Reflection and programmatic UI injection, violating multiple standards.
- **MainForm**: Updated `MainForm.cs` to inject dependencies into `PlannerControl` properly during navigation.
- **Data Binding**: Converted public fields to Properties in `Models/AccountModels.cs` (`TradePlan`) and `Models/PredictionModels.cs` to enable Windows Forms DataBinding.
- **Bug Fix**: Fixed `Services/RateRouter.cs` accessing non-existent property `Ticker.Price` (changed to `Ticker.Last`).
- **Audit**: Verified `Services/AutoPlannerService.cs` complies with Dependency Injection standards.

## [Phase 13] - AI Integration - 2026-02-13

### Added
- **Chrome Sidecar**: Full implementation of `Services/ChromeSidecar.cs` using WebSocket CDP for Gemini/ChatGPT integration.
- **AI Governor**: Implemented `Services/AIGovernor.cs` to poll market bias every 15 minutes.
- **Governor UI**: Added `UI/GovernorWidget.cs` to visualize AI status.

## [Phase 12] - UI Refactor & Modernization - 2026-02-12

### Added
- **Backend Events**: `ChromeSidecar` and `AIGovernor` now expose `StatusChanged` and `BiasUpdated` C# events for UI binding.
- **GovernorWidget**: New `UserControl` component (`UI/GovernorWidget.cs`) for visualizing AI Market Bias and connection status.
- **SidebarControl**: New navigation component (`UI/SidebarControl.cs`) to replace legacy TabControl menu.
- **ProfilesControl**: New feature (`UI/ProfilesControl.cs`) for full Import/Export management of encrypted user profiles.
- **Strategy Config**: Added `UI/StrategyConfigDialog.cs` using generic PropertyGrid for runtime strategy tuning.
- **Theme**: Added "Dark Graphite" palette (`#151717`, `#1E2026`) to `Themes/Theme.cs`.

## [Phase 11] - Refinement & Tuning - 2026-02-12

### Added
- **Indicators**: Added `ChoppinessIndex` (CHOP) implementation to `Strategy/Indicators.cs`.
- **Strategy Optimization**: Integrated "Chop-Block" filter into `VWAPTrendStrategy` to filter out execution during ranging markets (CHOP > 61.8).

### Changed
- **Logging**: Upgraded `Util/Log.cs` to capture CallerMemberName, CallerFilePath, and CallerLineNumber for detailed debugging.
- **Theming**: Centralized Theme logic to support `UserControl` and `Chart` components automatically.
- **UI**: Wired `DashboardControl` to use the centralized Theme engine instead of hardcoded colors.
- **Cleanup**: Removed unused `HttpUtil.PostAsync` and `HttpUtil.DeleteAsync` methods.
- **Cleanup**: Removed dead reference `Util/KeyStore.cs` from project file.
- **Resilience**: Verified `CoinbaseExchangeClient` uses proper Retry logic via `HttpUtil`.
- **Fix**: Replaced broken `JsonUtil` usage in `CoinbaseExchangeClient` with `UtilCompat`.

## [Phase 10] - Operational & Feature Expansion - 2026-02-12

### Added
- **New Strategy**: Deployed `RSIReversionStrategy` (RSI Mean Reversion logic).
- **Strategy Engine**: Updated `StrategyEngine` to support RSIReversion in Backtest/Paper/Live modes.
- **Indicators**: Added `RSI` to `Indicators.cs`.
- **AI Strategy Enforcement**: `StrategyEngine` now respects `GlobalBias` from AIGovernor (Bullish/Bearish/Neutral).
- **Smart Limits**: `AutoPlannerService` accepts `SuggestedLimit` from AI response for price improvement.
- **Dashboard**: Added Real-time PnL Equity Curve chart to `DashboardControl`.

### Fixed
- **Build**: Resolved broken references to deleted `JsonUtil.cs` by migrating to `UtilCompat.cs`.
- **Project Structure**: Cleaned up stale files from `.csproj`.

## [Phase 9] - Modernization - 2026-02-11

### Changed
- **Architecture**: Completed Audit and Refactor of "Static Registry" antipatterns.
- **Service Migration**: Refactored static `KeyRegistry`, `AccountRegistry`, `TimeFilters`, `ProfileStore` to injected Services.
- **Service Migration**: Refactored `EventBus` from Singleton to Injected Service in `Program.cs`.
- **Refactoring**: Updated `Brokers` (Coinbase) to use injected `IKeyService` and `IAccountService`.
- **UI**: Updated `AutoModeForm`, `KeysControl`, `AccountsControl`, and `MainForm` to use proper Dependency Injection.
- **Composition Root**: Updated `Program.cs` to explicitly compose the object graph.

### Removed
- **Legacy Brokers**: Deleted `Brokers/KrakenBroker.cs` and `Brokers/BitstampBroker.cs` (Legacy / Unmaintained).
- **Legacy Static Code**: Deleted `HistoryStore.cs`, `KeyRegistry.cs`, `AccountRegistry.cs`, `ProfileStore.cs`, `TimeFilters.cs`.
- **Redundant Utilities**: Deleted `KeyStore.cs`, `JsonUtil.cs`.

## [Phase 8] - Remediation & Hardening - 2025-08-27

### Added
- **ResilientExchangeClient**: Added a wrapper around exchange clients to handle HTTP 429/500 errors with exponential backoff.
- **KeyService / AccountService**: Added formal DI services to replace static Registries.
- **Designer Support**: Added `*.Designer.cs` files for `KeysControl`, `AccountsControl`, and `TradingControl` to enable Visual Studio Designer support.

### Changed
- **Strategy Optimization**: 
    - `Indicators.VWAP` optimized from O(N^2) to O(N) by caching session values.
    - `AutoPlannerService` simulation loop optimized to reduce allocation overhead.
- **Architecture**:
    - Migrated from Static Singletons (`KeyRegistry`, `AccountRegistry`) to Dependency Injection.
    - Standardized all UI Forms to use `Partial Class` + `Designer.cs` pattern.
- **Exports**: `ProfileService` now decrypts DPAPI blobs before export and re-encrypts on import, making `.cdtp` files portable between machines.

### Fixed
- **KrakenClient**: Repaired corrupted file content and verified `IExchangeClient` implementation.
- **Data Persistence**: Fixed bug where CheckBox changes in Accounts/Keys grids were not persisting to disk.
- **Infinite Loops**: Fixed potential infinite loop conditions in Backtester logic.

### Removed
- **Legacy Static Code**: Deleted `HistoryStore.cs`, `KeyRegistry.cs`, `AccountRegistry.cs`, `ProfileStore.cs`, `TimeFilters.cs`.
- **Redundant Utilities**: Deleted `KeyStore.cs`, `JsonUtil.cs`.

