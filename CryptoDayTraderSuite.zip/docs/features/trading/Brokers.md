# Brokers & Execution

The system abstracts order execution via the `IBroker` interface, supporting both simulated (Paper) and live exchange trading.

## Broker Interface
**Source**: `Brokers/IBroker.cs`

All brokers must implement:

```csharp
public interface IBroker
{
    string Service { get; }
    Task<(bool ok, string message)> PlaceOrderAsync(TradePlan plan);
    Task<(bool ok, string message)> CancelAllAsync(string symbol);
}
```

## Implementations

### 1. Paper Broker
**Source**: `Brokers/PaperBroker.cs`
- **Service Name**: `"paper"`
- **Behavior**: Simulates an instant fill at the requested price.
- **Logging**: Writes "paper fill..." to the centralized log.

### 2. Coinbase Exchange Broker
**Source**: `Brokers/CoinbaseExchangeBroker.cs`
- **Service Name**: `"coinbase-exchange"`
- **Architecture**:
  - Uses **Reflection** to load `CryptoDayTraderSuite.Exchanges.CoinbaseExchangeClient`.
  - This allows the broker to remain decoupled from the specific API library version or implementation details in the `Exchanges` namespace.
- **Key Management**:
  - Retrieves the "Active" key for `coinbase-exchange` from `KeyRegistry`.
  - Decrypts ApiKey, Secret, and Passphrase using DPAPI (`KeyRegistry.Unprotect`).

## Broker Factory
**Source**: `UI/AutoModeForm.cs` (Class: `BrokerFactory`)

*Note: The factory logic is currently embedded in `AutoModeForm.cs`.*

```csharp
public static IBroker GetBroker(string service, AccountMode mode)
{
    if (mode == AccountMode.Paper) return new PaperBroker();
    switch (service.ToLowerInvariant()) {
        case "coinbase-exchange": return new CoinbaseExchangeBroker();
        case "kraken": return new KrakenBroker();
        case "bitstamp": return new BitstampBroker();
    }
}
```

## Adding a New Broker
1.  Create a class implementing `IBroker` (e.g., `Brokers/IncredibleBroker.cs`).
2.  Implement the API connection logic (preferring the `Exchanges/` namespace for the client).
3.  Update the `BrokerFactory` switch statement to recognize your service string.
4.  Ensure your `KeyRegistry` entries match the service name.
