# AI Integration: The Chrome Sidecar

## Overview
The **Chrome Sidecar** is a feature that allows CryptoDayTraderSuite to leverage "Free Tier" Generative AI models (like ChatGPT or Gemini) running in your local browser to assist with trading decisions.

Instead of paying for API keys, the application connects to a specific Chrome window via the **Chrome DevTools Protocol (CDP)** and automates the process of asking for analysis.

## Core Capabilities

### 1. The Global Governor (Strategy Layer)
*   **What it does:** Runs every 15 minutes to analyze the 4-hour market structure of Bitcoin (BTC).
*   **Goal:** Determine the global "Market Bias" (Bullish, Bearish, or Neutral).
*   **Effect:** 
    *   If **Bearish**: The system blocks new High-Risk Long entries.
    *   If **Bullish**: The system blocks new High-Risk Short entries.
    *   **Neutral**: All strategies run normally.

### 2. The Trade Reviewer (AutoPlanner)
*   **What it does:** Before the `AutoPlanner` suggests a trade plan, it sends the specific parameters (Entry, Stop, Target, Reason) to the AI.
*   **Goal:** Sanity check the trade logic.
*   **Effect:** 
    *   If the AI says **"No"**, the trade is discarded.
    *   If the AI says **"Yes"**, the trade is generated with an approval note attached.

## How to Use (Step-by-Step)

### Step 1: Prepare Chrome
The application cannot open Chrome for you; you must start it in "Remote Debugging" mode.

1.  Close all open Chrome windows.
2.  Open **Run** (Win+R) or a Terminal.
3.  Execute the following command:
    ```powershell
    chrome.exe --remote-debugging-port=9222 --user-data-dir="%LOCALAPPDATA%\CryptoSidecar"
    ```
    *(Note: This launches a **separate** Chrome profile to keep your main browsing data safe. It will not show your existing history or logins initially, but it **will save** your login state for future sessions once you sign in.)*

### Step 2: Connect to AI
1.  In the new Chrome window, navigate to your preferred AI provider:
    *   [ChatGPT](https://chatgpt.com) (Recommended)
    *   [Gemini](https://gemini.google.com)
2.  **Log in** to your account manually.
3.  Keep this tab open. You can minimize the window, but do not close it.

### Step 3: Launch the Suite
1.  Start `CryptoDayTraderSuite.exe`.
2.  Watch the **Logs** tab or the Dashboard Status area.
3.  You should see:
    > `[ChromeSidecar] Connecting to ChatGPT...`
    > `[ChromeSidecar] Connected via CDP.`
    > `[AIGovernor] AI Governor Started.`

### Step 4: Verification
To verify it is working:
1.  Wait ~15 minutes for the Governor loop to trigger, or check the logs for "Market Bias".
2.  Go to the **Planner** tab and run a generation. If valid trades are found, you will see a flash of activity in the Chrome window as the prompt is injected.

## Troubleshooting

### "Chrome Sidecar: Not Found"
*   **Cause**: Chrome was not started with `--remote-debugging-port=9222`.
*   **Fix**: Close all Chrome instances (check Task Manager) and run the specific command above.

### "No AI tab found"
*   **Cause**: You have Chrome open, but are not on `chatgpt.com` or `gemini.google.com`.
*   **Fix**: Navigate to one of these sites in the debugging window.

### "Connection failed"
*   **Cause**: Port 9222 is blocked or another app is using it.
*   **Fix**: Ensure no other debuggers are running. Restart the PC if necessary.

## Security Note
*   The application runs **locally**.
*   It does **not** send your credentials to any server.
*   It uses your **existing** browser session, so no API keys are stored in the app.
