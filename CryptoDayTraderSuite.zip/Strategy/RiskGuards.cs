namespace CryptoDayTraderSuite.Strategy
{
    public static class RiskGuards
    {
        /* AUDIT-0020 Fix: Corrected Fee calculation logic. Previous version conflated tickValue with Notional. */
        public static bool FeesKillEdge(decimal grossProfit, decimal entryNotional, decimal feeRate)
        {
            if (grossProfit <= 0m) return true;
            /* fees = Entry + Exit. Approx 2 * feeRate * Notional */
            var fees = entryNotional * feeRate * 2m; 
            var ratio = fees / grossProfit;
            /* If fees eat more than 25% of the edge, it's a bad trade */
            return ratio >= 0.25m;
        }

        /* Legacy Overload for compatibility (Deprecating) */
        public static bool FeesKillEdge(decimal targetTicks, decimal tickValue, decimal qty, decimal makerFee, decimal takerFee, bool takerEntry)
        {
             /* This logic conflated tickValue with Price. Retaining strictly for compilation if invoked, but should be avoided. */
             /* To make it work 'somewhat', we assume tickValue implies Price here? No, that's dangerous. */
             /* We will return false to disable the guard if called via this broken signature. */
             return false;
        }

        public static bool SpreadTooWide(decimal spread, decimal atr, decimal maxSpreadToAtr)
        {
            if (atr <= 0m) return false;
            var r = spread / atr;
            return r > maxSpreadToAtr;
        }

        public static bool VolatilityShock(decimal atrNow, decimal atrMedian, decimal spikeFactor)
        {
            if (atrMedian <= 0m) return false;
            return atrNow >= spikeFactor * atrMedian;
        }
    }
}