
using System;
using System.Collections.Generic;
using System.Globalization;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.Strategy
{
    public class StrategyEngine
    {
        public StrategyKind Active { get; set; } /* active strategy */
        public ORBStrategy Orb { get; private set; } = new ORBStrategy(); /* orb */
        public VWAPTrendStrategy VwapTrend { get; private set; } = new VWAPTrendStrategy(); /* vwap */
        public RSIReversionStrategy RsiReversion { get; private set; } = new RSIReversionStrategy(); /* rsi */
        
        /* 
           AI Governor: Blocks trades that contradict the global market bias. 
           Updated by background service.
        */
        public MarketBias GlobalBias { get; set; } = MarketBias.Neutral;

        public void SetStrategy(string name)
        {
            if (string.IsNullOrEmpty(name)) return;

            if (name.Equals("ORB", StringComparison.OrdinalIgnoreCase) || name.Equals("ORB Strategy", StringComparison.OrdinalIgnoreCase))
                Active = StrategyKind.ORB;
            else if (name.Equals("VWAPTrend", StringComparison.OrdinalIgnoreCase) || name.Equals("VWAP Trend", StringComparison.OrdinalIgnoreCase))
                Active = StrategyKind.VWAPTrend;
            else if (name.Equals("RSIReversion", StringComparison.OrdinalIgnoreCase) || name.Equals("RSI Reversion", StringComparison.OrdinalIgnoreCase))
                Active = StrategyKind.RSIReversion;
        }

        public OrderRequest Evaluate(string productId, List<Candle> candles, FeeSchedule fees, decimal equityUsd, decimal riskFraction, decimal price, out CostBreakdown costs, int index = -1)
        {
            /* choose strategy */
            costs = new CostBreakdown(); /* init */
            IStrategy strategy = Active == StrategyKind.ORB ? (IStrategy)Orb : (Active == StrategyKind.VWAPTrend ? (IStrategy)VwapTrend : RsiReversion);
            
            int idx = index == -1 ? candles.Count - 1 : index;

            var result = strategy.GetSignal(candles, idx);
            if (!result.IsSignal) return null; /* no trade */

            /* Governor Check */
            if (GlobalBias == MarketBias.Bearish && result.Side == OrderSide.Buy) return null;
            if (GlobalBias == MarketBias.Bullish && result.Side == OrderSide.Sell) return null;

            var side = result.Side;
            var entry = result.EntryPrice;
            var stop = result.StopLoss;
            // tp not used in OrderRequest here directly but could be? 
            // The OrderRequest doesn't seem to have Stop/TP params?
            // Ah, OrderRequest is for the ENTRY order.
            
            /* compute costs */
            var feeRate = fees.TakerRate; /* assume taker for entry */
            costs.FeeRateUsed = feeRate; /* set */
            /* estimate spread from bid ask will be filled in UI layer, default 0.0005 = 5 bps */
            costs.EstimatedSpreadRate = 0.0005m; /* spread */
            costs.TotalRoundTripRate = feeRate + fees.MakerRate + costs.EstimatedSpreadRate; /* approx */

            /* risk sizing */
            var riskPerTrade = equityUsd * riskFraction; /* $ risk */
            var stopDistance = Math.Abs(entry - stop); 
            
            // Fallback for VWAP if entry == stop (though new strategy guarantees valid stop)
            if (stopDistance <= 0m) stopDistance = entry * 0.01m; 
            
            var qty = riskPerTrade / stopDistance; /* qty */
            qty = Math.Round(qty, 6); if (qty <= 0m) return null; /* round */

            return new OrderRequest { ProductId = productId, Side = side, Type = OrderType.Market, Quantity = qty, Tif = TimeInForce.GTC, Price = null, ClientOrderId = "cdts-" + Guid.NewGuid().ToString("N") }; /* order */
        }
    }
}
