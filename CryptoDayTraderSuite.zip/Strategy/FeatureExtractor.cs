/* File: Strategy/FeatureExtractor.cs */
/* Author: Gregory King */
/* Date: 2025-08-10 */
/* Description: compute features from candles for prediction */
/* Functions: ComputeFeatures */

using System;
using System.Collections.Generic;
using CryptoDayTraderSuite.Models;

namespace CryptoDayTraderSuite.Strategy
{
    public static class FeatureExtractor
    {
        /* compute rolling features from recent candles */
        public static Dictionary<string, decimal> ComputeFeatures(List<Candle> candles, int smaShort = 5, int smaLong = 20, int rsiPeriod = 14, int vwapPeriod = 20)
        {
            var f = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase);

            if (candles == null || candles.Count < Math.Max(smaLong, vwapPeriod))
            {
                f["error"] = -1; // Indicate insufficient data
                return f;
            }

            int n = candles.Count;
            decimal last = candles[n - 1].Close;
            decimal prev = candles[n - 2].Close;
            f["ret_1"] = SafeDiv(last - prev, prev);

            /* simple moving averages */
            f["sma_short"] = SMA(candles, smaShort); /* sma5 */
            f["sma_long"] = SMA(candles, smaLong); /* sma20 */
            f["sma_gap"] = SafeDiv(f["sma_short"] - f["sma_long"], f["sma_long"]); /* gap */

            /* rsi 14 */
            f["rsi"] = RSI(candles, rsiPeriod); /* rsi */

            /* vwap distance approximation using hlc3 */
            f["vwap_gap"] = VWAPGap(candles, vwapPeriod); /* vwap gap */

            return f; /* return */
        }

        private static decimal SafeDiv(decimal a, decimal b) { return b == 0m ? 0m : a / b; } /* safe */

        private static decimal SMA(List<Candle> c, int win)
        {
            int n = c.Count; if (n < win) return 0m; /* guard */
            decimal s = 0m; for (int i = n - win; i < n; i++) s += c[i].Close; /* sum */
            return s / win; /* avg */
        }

        private static decimal ATR(List<Candle> c, int win)
        {
            int n = c.Count; if (n < win + 1) return 0m; /* guard */
            decimal s = 0m;
            for (int i = n - win; i < n; i++)
            {
                var tr = TrueRange(c[i - 1], c[i]); /* tr */
                s += tr;
            }
            return s / win; /* avg */
        }

        private static decimal TrueRange(Candle prev, Candle cur)
        {
            var a = Math.Abs((double)(cur.High - cur.Low));
            var b = Math.Abs((double)(cur.High - prev.Close));
            var c = Math.Abs((double)(cur.Low - prev.Close));
            return (decimal)Math.Max(a, Math.Max(b, c)); /* max */
        }

        private static decimal RSI(List<Candle> c, int period)
        {
            int n = c.Count; if (n < period + 1) return 50m; /* neutral */
            decimal gain = 0m, loss = 0m;
            for (int i = n - period; i < n; i++)
            {
                var ch = c[i].Close - c[i - 1].Close; /* change */
                if (ch > 0m) gain += ch; else loss -= ch;
            }
            if (loss == 0m) return 100m;
            var rs = gain / loss; var rsi = 100m - (100m / (1m + rs));
            return rsi;
        }

        private static decimal VWAPGap(List<Candle> c, int win)
        {
            int n = c.Count; if (n < win) return 0m; /* guard */
            decimal pv = 0m, vol = 0m;
            for (int i = n - win; i < n; i++)
            {
                var hlc3 = (c[i].High + c[i].Low + c[i].Close) / 3m; /* hlc3 */
                pv += hlc3 * c[i].Volume; vol += c[i].Volume;
            }
            if (vol == 0m) return 0m;
            var vwap = pv / vol;
            var last = c[n - 1].Close;
            return (last - vwap) / vwap;
        }
    }
}